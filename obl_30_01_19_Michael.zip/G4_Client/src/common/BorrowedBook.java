package common;
import java.io.Serializable;

public class BorrowedBook  implements Serializable{

	private static final long serialVersionUID = 511837015879654821L;
	public String isbn;
	public String borrowerID;		
	public String borrowDate;
	public String returnDate;
	public String borrowStatus;
	
	public BorrowedBook(String ISBN) {		
		this.isbn = ISBN;
	}
	
	public BorrowedBook( String ISBN ,String  BorrowerID ,  String BorrowDate, String ReturnDate,String BorrowStatus) {		
		
		this.isbn = ISBN;
		this.borrowerID = BorrowerID;	
		this.borrowDate = BorrowDate;
		this.returnDate = ReturnDate;
		this.borrowStatus = BorrowStatus;

	}
	

	
	public String getISBN() {
		return isbn;
	}
	public void setISBN(String ISBN) {
		this.isbn = ISBN;
	}
	public String getBorrowerID() {
		return borrowerID;
	}
	public void setBorrowerID(String BorrowerID) {
		this.borrowerID = BorrowerID;
	}
	public String getBorrowDate() {
		return borrowDate;
	}
	public void setBorrowDate(String borrowDate) {
		this.borrowDate = borrowDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getBorrowStatus() {
		return borrowStatus;
	}
	public void setBorrowStatus(String borrowStatus) {
		this.borrowStatus = borrowStatus;
	}

	@Override
	public String toString() {
		return borrowerID;
	}
	
} 
