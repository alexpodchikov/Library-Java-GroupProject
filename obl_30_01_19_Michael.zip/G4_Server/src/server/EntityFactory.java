package server;

import java.sql.ResultSet;
import java.util.ArrayList;

import common.*;

/**
 * Create object entity by string type name.
 *
 */
public class EntityFactory {

	
	public static Object getEntity(String entityName, ResultSet rs) throws Exception {
		Object objectToReturn = null;
		//System.out.println(" "+ entityName);
		try {
		switch(entityName.toLowerCase().trim()) {
		case "borrow_info":		
			rs.next();		
			ArrayList<String> info = new ArrayList<String>();		
			info.add(rs.getString(1));		
			info.add(rs.getString(2));
			info.add(rs.getString(3));
			objectToReturn = (Object)info;		
					break;
		case "student":
			rs.next();
			objectToReturn = new Student(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
		break;
		case "num_of_students":
			rs.next();
			objectToReturn = rs.getString(1); 
					//new ArrayList<String>() ;
					break;
		case "borrowedbookhistory":
			ArrayList<BorrowedBook> borrowedBooksHistory = new ArrayList<BorrowedBook>();
			while(rs.next()) {
				borrowedBooksHistory.add( new BorrowedBook(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
			}
			for (int i = 0; i <borrowedBooksHistory.size(); i++) {
			System.out.println(entityName + borrowedBooksHistory.get(i));	
			}
			objectToReturn=(Object)borrowedBooksHistory; 
			break;	
		
		case "book":
			ArrayList<Book> books = new ArrayList<Book>(); 
			while(rs.next()) {
			books.add( new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getBoolean(4)));
			}
			for (int i = 0; i <books.size(); i++) {
			System.out.println(books.get(i));	
			}
			objectToReturn=(Object)books; 
			break;
		case "borrowedbook":
			//System.out.println("ninja1");
			ArrayList<BorrowedBook> borrowedbooks = new ArrayList<BorrowedBook>();
			while(rs.next()) {
			borrowedbooks.add( new BorrowedBook(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
			}
			for (int i = 0; i <borrowedbooks.size(); i++) {
			System.out.println(entityName + borrowedbooks.get(i));	
			}
			objectToReturn=(Object)borrowedbooks; 
			break;	
		case "user":
			rs.next();		
			objectToReturn = new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
			break;
		case "borrower_id":
			rs.next();		
			ArrayList<String> borrowerID = new ArrayList<String>();		
			borrowerID.add(rs.getString(1));
			objectToReturn = (Object)borrowerID;
			System.out.println("ninja2");
			break;
		default:
			System.out.println("its an update");
			return true;
		
		}
		return objectToReturn;
		}
		catch(Exception e) {
			return null;
		}
	}
}
