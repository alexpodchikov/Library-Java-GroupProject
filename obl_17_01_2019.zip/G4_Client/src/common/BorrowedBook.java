package common;
import java.io.Serializable;

public class BorrowedBook  implements Serializable{

	private static final long serialVersionUID =  -687991492884005033L;
	public String userID;
	public String bookID;		
	public String borrowDate;
	public String returnDate;
	public String borrowStatus;
	public Boolean prolongationRequest;
	
	public BorrowedBook() {
		// TODO Auto-generated constructor stub
	}
	public BorrowedBook( String  UserID ,String BookID ,  String BorrowDate,String ReturnDate,String BorrowStatus,Boolean  ProlongationRequest) {		
	
		this.userID = UserID;
		this.bookID = BookID;
		this.borrowDate = BorrowDate;
		this.returnDate = ReturnDate;
		this.borrowStatus = BorrowStatus;
		this.prolongationRequest = ProlongationRequest;
	}
	
	public String getBookID() {
		return bookID;
	}
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getBorrowDate() {
		return borrowDate;
	}
	public void setBorrowDate(String borrowDate) {
		this.borrowDate = borrowDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getBorrowStatus() {
		return borrowStatus;
	}
	public void setBorrowStatus(String borrowStatus) {
		this.borrowStatus = borrowStatus;
	}
	public Boolean getProlongationRequest() {
		return prolongationRequest;
	}
	public void setProlongationRequest(Boolean prolongationRequest) {
		this.prolongationRequest = prolongationRequest;
	}
	
	
} 
