package common;

import java.io.Serializable;

public class ProblematicStudent implements Serializable {


	
	private static final long serialVersionUID = -5771868018338713759L;
	public String subscriberID;
	public String subscriberName;
	public String subscriberStatus;
	
	public ProblematicStudent(String subscriberID, String subscriberName, String subscriberStatus) {
	
		this.subscriberID = subscriberID;
		this.subscriberName = subscriberName;
		this.subscriberStatus = subscriberStatus;
	}
	public String getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getSubscriberStatus() {
		return subscriberStatus;
	}

	public void setSubscriberStatus(String subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}
	
	@Override
	public String toString() {
		return subscriberID;
	}
}
