package client;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Program main entry point.
 *
 */
public class Main extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
        try 
        {
        	MainSystemMenuController mainSystemMenu = new MainSystemMenuController();
        	mainSystemMenu.start(primaryStage);	
        } 
        catch (IOException e) {
            e.printStackTrace(); 
        }
	}

	public static void main(String[] args) {
		launch(args);
	}

}

