package client;

import java.io.IOException;
import java.util.ArrayList;
import common.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
/**
 * 
 * Controller responsible for user profile
 *
 */
public class UserProfileController implements ChatIF, FeedbackIF{
		
	private ConnectionController client;
	
	@FXML
	private TextField emailID;
	@FXML
	private TextField phoneID;
	@FXML
	private TextField SubscriberNumID;
	@FXML
	private TextField StudentID;
	@FXML
	private TextField StudentNameID;
	
	public void setUserInfo(String userID) {
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(userID);

		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_STUDENT_INFO, SetParameters,"student");
		    client.handleMessageFromClientUI(messageToSend);
		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}
		
	/**
	 * 	 	 
	 * @param event button clicked
	 * Back to previous screen
	 */
	@FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Subscriber Main Menu");	 
	}
	
	 /**
	  * 
	  * @param event button clicked
	  * @throws Exception
	  * The method send new email and phone to server 
	  */
	 @FXML
	 void SaveClick(ActionEvent event) throws Exception  {
		 String email = emailID.getText();
		 String phone = phoneID.getText();
		 ArrayList<String> SetParameters = new ArrayList<String>();

			try {
				client = ConnectionController.getConnectionController();
				client.clientF = this;
				client.clientUI = null;
			
				SetParameters.add(client.getUserID());
				SetParameters.add(email);
				SetParameters.add(phone);
				}
			catch (IOException e) {
				e.printStackTrace();
			}

		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SAVE_STUDENT_INFO, SetParameters,null);
		    client.handleMessageFromClientUI(messageToSend); 
		 
	}
	 
	 /**
	  * 
	  * @param event button clicked
	  * @throws Exception
	  * The method open history of student controller (fxml) and sends to it user id
	  */
	 @FXML
	 void viewHistoryClicked(ActionEvent event) throws Exception  {
			
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
		 try {
	        	FXMLLoader loader= new FXMLLoader();	
	        	client = ConnectionController.getConnectionController();
		    	client.setPrevScene(curr);
    			Stage stage = client.getStage();
            	Parent root = loader.load(Main.class.getResource("/client/ReaderBorrowHistoryWindow.fxml").openStream());	        				
            	ReaderBorrowHistoryWindowController controller = loader.getController();
        		controller.setUserBorrowHistory(client.getUserID());
        		Scene scene = new Scene(root);	
    			stage.setTitle("Borrow History");
    			stage.setScene(scene);
    			stage.show();
		} catch(IOException e) {
        			e.printStackTrace();
		}
		 
	}
	
		/**
		 * @param message - server response
		 * the method gets response message from server about email and phone changes and set it to controller text fields
		 * 
		 */
	@Override
	public void display(Object message) {
		if (message == null) {
			System.out.println("> Server returned null");
			return;
		}
		System.out.println("> Server returned: "+message.toString());
 
		if (message instanceof Student) {
			Student student = (Student) message;
	      	emailID.setText(student.getStudentEmail());
	      	phoneID.setText(student.getStudentPhone());
	      	SubscriberNumID.setText(student.getStudentSubscriberNumber()); 
	      	StudentID.setText(student.getStudentID());
	      	StudentNameID.setText(student.getStudentName()); 		 
		}	
		 
	}
/**
 * @param msg from server ("Success" or "Failure")
 * The method gets message from server and send it to get corresponding answer
 */
	@Override
	public void feedback(Object msg)
	{
		Screens.singleFeedback(msg);
						
	}
	
}
