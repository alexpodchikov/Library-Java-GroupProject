package client;


import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
/**
 * 
 * Main Menu Controller 
 *
 */
public class MainSystemMenuController{ 
	
	private ConnectionController client;	
	@FXML
	private Label ConnectionStatus;	  
	@FXML
	private TextField ServerIPAddressTextField;
/**
 * 
 * @param event button clicked
 * The Method is connecting to server
 */
	public void EstablishConnection(ActionEvent event) {
    	Stage curr = (Stage)((Node)event.getSource()).getScene().getWindow();
		try {
			String ServerIPAddress = ServerIPAddressTextField.getText();
			client.setHostIP(ServerIPAddress);
				client = ConnectionController.getConnectionController();
			
				
				client.setStage(curr);
				
				ConnectionStatus.setText("Connected");
				ConnectionStatus.setTextFill(Color.GREEN);
		}
		catch (IOException e) {
			System.out.println(e+" got you");
			ConnectionStatus.setText("Disconnected");
			ConnectionStatus.setTextFill(Color.RED);
		}
	}
	
	/**
	 * 
	 * @param primaryStage 
	 * @throws Exception
	 */
	
	public void start(Stage primaryStage) throws Exception 
	{	
		Parent root = FXMLLoader.load(getClass().getResource("/client/MainSystemMenu.fxml"));				
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/client/MainSystemMenu.css").toExternalForm());
		primaryStage.setTitle("Main System Menu");
		primaryStage.setResizable(true);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	/**
	 * 
	 * @param event button clicked
	 * The method Quit from application 
	 */
	@FXML
	public void QuitApplicationClick(ActionEvent event) {
    	try {
    		if (client != null && client.isConnected())
    			client.closeConnection();
		} 
    	catch (IOException e) {
			e.printStackTrace();
		}
		
		 Platform.exit();
	     System.exit(0);
	}
	
	/**
	 * 
	 * @param event button clicked
	 * The Method open new controlled for login
	 * 
	 */
		@FXML
		private void LoginClick(ActionEvent event) {
			Scene curr = (Scene)((Node)event.getSource()).getScene();
			if (client == null || !client.isConnected()) { 
	    		ConnectionStatus.setText("Disconnected");             
				ConnectionStatus.setTextFill(Color.RED);
				Screens.showErrorDialog("Error","Server disconnected", "Please first connect to server.");
	    		return;
	    	}
			
			// Login window displayed separately
			Stage stage = new Stage();
			FXMLLoader loader = new FXMLLoader();
			Parent root;
			try {
				root = loader.load(getClass().getResource("/client/LoginScreen.fxml").openStream());
				client.setPrevScene(curr);
				Scene scene = new Scene(root);			
				stage.setTitle("Login");
				stage.setScene(scene);
				stage.show();
				}  
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		/**
		 * 
		 * @param event button clicked
		 * The Method open new controller for book search
		 */
		@FXML
		private void SearchBookClick(ActionEvent event){
			Scene curr = (Scene)((Node)event.getSource()).getScene();
	    	if (client == null || !client.isConnected()) { 
	    		ConnectionStatus.setText("Disconnected");             
				ConnectionStatus.setTextFill(Color.RED);
				Screens.showErrorDialog("Error","Server disconnected", "Please first connect to server.");
	    		return;
	    	}
	    	
	    	client.setPrevScene(curr);
	    	Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
		}
		
}
