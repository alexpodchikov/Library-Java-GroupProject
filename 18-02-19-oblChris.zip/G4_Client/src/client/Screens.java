package client;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

import java.io.IOException;
import java.util.*;
import javafx.stage.*;

/**
 * 
 * Class for fast access to alert message to user
 *
 */
public class Screens {
	
	private static ConnectionController client;

	//~~~~~~~~~~~~~~~~~~~~~~~~~ Screen Manipulation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	/**
	 * 
	 * @param stageName title of previous scene
	 * The method to open previous fxmlController scene
	 */
	public static void showPrevScreen(String stageName) {
		
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle(stageName);
			stage.setScene(scene);		
			stage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 * @param fxmlPath kind of fxml
	 * @param stylesheetPath style of fxml file
	 * @param stageName title of new scene
	 * method to open new fxmlController in new stage
	 */
	public static void showNewScreen(String fxmlPath, String stylesheetPath, String stageName)
	{
		FXMLLoader loader = new FXMLLoader();
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource(fxmlPath).openStream());
			Scene scene = new Scene(root);	
			if(stylesheetPath != null)
				scene.getStylesheets().add(Main.class.getResource(stylesheetPath).toExternalForm());
			stage.setTitle(stageName);
			stage.setScene(scene);
			stage.show();
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~ Feedback Handling ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/**
	 * 
	 * @param msg from server
	 * The function get message from server from any controller and show pop ups windows accordingly to it
	 */
	public static void singleFeedback(Object msg)
	{
		
		System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
		Platform.runLater(new Runnable() {                          
		            @Override
		            public void run() {
		            	String status = (String)msg;
		            	
		    			if(status.equals("Success"))
		    				Screens.showSuccessDialog("Notification", "Successful update", "Database was updated successfully");
		    			else 
		    				Screens.showErrorDialog("Error","Faild to update", "Could not update database");
		            }
		            
			 });
		
	}
	
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~ Alert Factory ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	/**
	 * 
	 * @param title of error dialog
	 * @param header of error dialog
	 * @param content of error dialog
	 * pop ups dialog (Alert) to user responds 
	 */
	public static void showErrorDialog(String title, String header, String content) 
	{
		Alert alert = new Alert(AlertType.ERROR);
		alert.getDialogPane();
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.show();
	}
	
	
	/**
	 * 
	 * @param title of success dialog
	 * @param header of success dialog
	 * @param content of success dialog
	 * pop ups dialog (Alert) to user responds 
	 */
	public static void showSuccessDialog(String title, String header, String content) 
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.getDialogPane();
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.show();
	}
	/**
	 * 
	 * @param title of success dialog
	 * @param header of success dialog
	 * @param content of success dialog
	 * @return pressing the user on the ok button
	 * pop ups confirmation dialog (Alert) to user responds 
	 */
	public static boolean showConfirmationDialog(String title, String header, String content) 
	{
	    Alert alert = new Alert(AlertType.CONFIRMATION); 
	    alert.setTitle(title);
	    alert.setHeaderText(header);
	    alert.setContentText(content);
	    Optional<ButtonType> result = alert.showAndWait();
	    return result.get() == ButtonType.OK;
	}

}
