package client;


import java.io.IOException;
import java.util.ArrayList;

import common.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * 
 * Controller responsible for reader borrow history
 *
 */
public class ReaderBorrowHistoryWindowController implements ChatIF, FeedbackIF{
	
    private ConnectionController client;
    private ArrayList<BorrowedBook> borrowedBooks;
    private ObservableList<BorrowedBook> observableBooks;
    
	@FXML
	private TextField prolongationTextFieldID;
	@FXML
    private TableView<BorrowedBook> BorrowHistoryViewID;	 
	@FXML
    private TableColumn<BorrowedBook, String> ISBNID;
    @FXML
    private TableColumn<BorrowedBook, String> BorrowerID;
    @FXML
    private TableColumn<BorrowedBook, String> BorrowDateID;
    @FXML
    private TableColumn<BorrowedBook, String> ReturnDateID;   
    @FXML
    private TableColumn<BorrowedBook, String> ReturnStatusID;
    
    
/**
 * 
 * @param userID get userID from previous controller
 * The method send userId to server to get borrow history
 *  
 */
	public void setUserBorrowHistory(String userID) {
		
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(userID);

		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;		
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BOOK_BORROW_HISTORY, SetParameters,"borrowedbookhistory");
		    client.handleMessageFromClientUI(messageToSend);

		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 * @param event button clicked
	 * @throws IOException
	 * The method send isbn to server according to user
	 * 
	 */
    @FXML
	private void SubmitClicked(ActionEvent event) throws IOException {
    
    	String prolongationISBN = prolongationTextFieldID.getText();
    	client = ConnectionController.getConnectionController();
    	client.clientUI = null;
    	client.clientF = this;			
    	
    	ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(prolongationISBN);	
  	    if(prolongationISBN.isEmpty()) {
  	    	Screens.showErrorDialog("Error","Cannot be empty for prolongation ISBN", "Please check your info!");
  	    	return;
  	    }
  	    switch (client.getUserKind().toLowerCase().trim()) {
		case "student":							
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SUBSCRIBER_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend);
			break;
		case "librarian":
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend2);
			break;
		case "librarymanager":
			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend3);
			break;
		default:
			System.out.println("There is no such user");
		}			
  	}
	 /**
	  * 
	  * @param event button clicked
	  * Back to previous screen
	  */
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("User Profile");	 
	}
	 /**
	  *  @param message server response 
	  *  the method gets response message from server and sets it to text fields
	  *  
	  */
	 @Override
	 public void display(Object message) {
		 if (message == null) 
			System.out.println("> Server returned null");
		else 
			System.out.println("> Server returned: "+message.toString());
			
		borrowedBooks = (ArrayList<BorrowedBook>)message;	
		observableBooks = FXCollections.observableArrayList(borrowedBooks); 
		BorrowHistoryViewID.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		ISBNID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("ISBN"));
		BorrowerID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowerID"));	
		BorrowDateID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowDate"));
		ReturnDateID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("returnDate"));
		ReturnStatusID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowStatus"));
		BorrowHistoryViewID.setItems(observableBooks);
					
	}
		

	@Override
	public void feedback(Object msg) 
	{			
		Screens.singleFeedback(msg);
	}
		
}
