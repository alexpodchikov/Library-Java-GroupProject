package client;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;

import common.Book;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class LibraryManagerMainScreenController implements ChatIF {
	
//	 private String connectedUserID= null;
//	 private String connectedUserAccount= null;
//	 private User localUser= null;
//	 private ConnectionController connectionController;
	

	private ConnectionController client;

	
	@FXML
	private void BookSearchClick(ActionEvent event) {			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	@FXML	
	 public void LogoutClick(ActionEvent event) {
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle("Main System Menu");
			stage.setScene(scene);		
			stage.show();
			} 
		catch (IOException e)
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}
	
	
	@FXML
	private void InventoryManagementClick(ActionEvent event) {		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		client.setPrevScene(curr);
    	Screens.showNewScreen("/client/InventoryManagementWindow.fxml", null, "InventoryManagement");   
	}
	
	
	 @FXML
	 private TextField UserIDTextField;
	 @FXML
	 private TextField BookIDTextField;
	 
	 
	/**
	 * Login button pressed. validate login info.
	 * @param event login button pressed.
	 */
    @FXML	
    private void BorrowClick(ActionEvent event) throws IOException{
    	Scene curr = (Scene)((Node)event.getSource()).getScene();
    	
		String userID = UserIDTextField.getText();
    	String bookID = BookIDTextField.getText();
    	if (userID.isEmpty() || bookID.isEmpty()) {
    		Screens.showErrorDialog("Error","Cannot be empty for book borrow", "Please check your info!");
    		return;
    	}
	
    	/*
   		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(userID);
		SetParameters.add(bookID);
		SetParameters.add(borrowDate);
		SetParameters.add(returnDate);

		client = ConnectionController.getConnectionController();
		client.clientUI = this;
		client.setPrevScene(curr);
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_BORROWED_BOOK, SetParameters, "BorrowedBook");
	    client.handleMessageFromClientUI(messageToSend); 
	    */
    	
   		ArrayList<String> SetParameters = new ArrayList<String>();		
		SetParameters.add(userID);
		client = ConnectionController.getConnectionController();
		client.clientUI = this;
		client.setPrevScene(curr);
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_STUDENT_NAME, SetParameters, "user");		//"User"
	    client.handleMessageFromClientUI(messageToSend); 
    	
    	try {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/client/ConfirmBookBorrowController.fxml"));
    		Parent root = (Parent) loader.load();
    		
    		ConfirmBookBorrowController confirmBorrowController = loader.getController();
    		//confirmBorrowController.setBorrowingInfo(UserIDTextField.getText(),BookIDTextField.getText());
    		Stage stage = new Stage();
    		stage.setScene(new Scene(root));
    		stage.show();
    		
    	} catch (IOException e) {
        	//System.out.println("Invoke later failed..");
           	e.printStackTrace();
        }
	}
    
    
	@Override
	public void display(Object msg) {
		// TODO Auto-generated method stub
		if (msg == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+msg.toString());
			

		Platform.runLater(new Runnable() {                          
			@Override
			public void run() {
	            try{
	            	if (msg == null) 
	            	{
		          		Screens.showErrorDialog("Error","Entry not found", "Server didn't find the entry requested!");
		           		return;
		           	}    	
                	showStage(msg);
	            }
	            catch(Exception e) {
	            	System.out.println("Invoke later failed..");
		           	e.printStackTrace();
	            }
			}
		            

		    private void showStage(Object object) throws Exception {
		    	String confirmBookBorrowOrder = null;
		    	String stylesheetPath = null;
		    	String stageTitle = null;
		    	//Book bookInfo = (Book)object;
		    	//User studentInfo = (User)object;
		        //if(object instanceof User)		
	        	confirmBookBorrowOrder = "/client/ConfirmBookBorrow.fxml";
	        	stageTitle = "Confirm Book Borrow";	
		        Screens.showNewScreen(confirmBookBorrowOrder, stylesheetPath, stageTitle);
		    }
		});
	}
}