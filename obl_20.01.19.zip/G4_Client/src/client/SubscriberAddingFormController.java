package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class SubscriberAddingFormController implements ChatIF {
	
	 @FXML
	 private TextField studentNameTextField;
	 @FXML
	 private TextField studentIDTextField;
	 @FXML
	 private TextField studentEmailAddressTextField;
	 @FXML
	 private TextField studentPhoneNumberTextField;
	 
	 @FXML
	 private TextField studentPasswordTextField;
	 
	 private ConnectionController client;
	 
	 @FXML	
	    private void SaveClick(ActionEvent event) throws IOException {
			String studentName = studentNameTextField.getText();
	    	String studentID = studentIDTextField.getText();
	    	String studentEmailAddress = studentEmailAddressTextField.getText();
	    	String studentPhoneNumber = studentPhoneNumberTextField.getText();
	    	String studentPassword = studentPasswordTextField.getText();
	    	
	    	if (studentName.isEmpty() || studentID.isEmpty() || studentEmailAddress.isEmpty() || studentPhoneNumber.isEmpty() || studentPassword.isEmpty()) {
	    		Screens.showErrorDialog("Invalid information","Text Field cannot be empty", "Please check info");
	    		return;
	    	}
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(studentName);
			SetParameters.add(studentID);
			SetParameters.add(studentEmailAddress);
			SetParameters.add(studentPhoneNumber);
			SetParameters.add(studentPassword);
			
			try {
				client = ConnectionController.getConnectionController();
				//client.clientUI = this;
			    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_READER_CARD, SetParameters, "Student");
			    client.handleMessageFromClientUI(messageToSend);
				}
			catch (IOException e) {
				e.printStackTrace();
			}
			
		}

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
}
