package client;


import java.io.IOException;
import java.util.ArrayList;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ReaderBorrowHistoryWindowController {
	
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("User Profile");	 
	}

}
