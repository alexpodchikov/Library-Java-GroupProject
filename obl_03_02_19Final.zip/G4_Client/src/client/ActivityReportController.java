package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.Book;
import common.BookName;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
/**
 * 
 * @author group 4 
 * taking care of activity report.
 *
 */
public class ActivityReportController implements ChatIF,FeedbackIF,Initializable {
	private ConnectionController client;
	
	
	@FXML
	private TextField FromID;
	@FXML
	private TextField ToID;
	@FXML
	private TextField NumberOfActiveSubscribersID;
	@FXML
	private TextField NumberOfFrozenSubscribersID;
	@FXML
	private TextField NumberOfLockedSubscribersID;
	@FXML
	private TextField NumberOfBorrowedSubscribersID;
	@FXML
	private TextField NumberOfLateReturnSubscribersID;
	@FXML
	private ComboBox<String> comboBoxReportsID=new ComboBox<String>();
	ObservableList<String> list;
	int counter = 1;
	boolean comboboxflag=false;
	
	 ArrayList<String> PreviousReports = new ArrayList<String>();
	 /**
	  * going back to previous screen
	  * @param event back button clicked
	  */
	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Report Window");

	}
	 /**
	  * taking care of previous reports. when clicked, it opens a new window with the chosen report
	  * @param event watch button clicked
	  * @throws IOException in case the connection goes wrong
	  */
	 @FXML
	 void onWatchClick(ActionEvent event) throws IOException {
		 
		 client = ConnectionController.getConnectionController();
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
		 client.setPrevScene(curr);
		 String report = comboBoxReportsID.getValue();
		 String from=report.substring(0, 10);
		String to = report.substring(13,23);
		System.out.println("Ninja yomit" + from +" "+ to);
	   	try {
	   		client = ConnectionController.getConnectionController();	   		
		  	FXMLLoader loader= new FXMLLoader();
	   	 
			Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource("/client/SavedActivityReports.fxml").openStream()); 			
        	SavedActivityReportsController controller = loader.getController();
    		controller.initReport(from,to);
        	Scene scene = new Scene(root);				

			stage.setTitle("Saved Activity Report");
			stage.setScene(scene);
			stage.show(); 
		}
		catch (IOException e) { 
			e.printStackTrace();
		}
		 //ArrayList<String> SetParameters2 = new ArrayList<String>();
		// SetParameters2.add(report);
	//	 ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_ACTIVITY_REPORT_INFO, SetParameters2, "activity_report_show");			    
		//client.handleMessageFromClientUI(messageToSend);
	}
	 /**
	  * taki
	  * @param event
	  * @throws IOException
	  */

	 @FXML
	 void submitClicked(ActionEvent event) throws IOException {
		 ArrayList<String> SetParameters = new ArrayList<String>();		

		// client = ConnectionController.getConnectionController();
		  try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
				client.clientF = this;
			
		 String from = FromID.getText();
		 String to  = ToID.getText();
		 if(from.isEmpty()||to.isEmpty()) {
		    	Screens.showErrorDialog("Error","Cannot be empty for activity report view", "Please check your info!");
		    	return;}
		 SetParameters.add(from);
		 SetParameters.add(to);
		 SetParameters.add("Active");
		 ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SUBSCRIBERS_COUNTER_IN_A_STATUS, SetParameters, "active_subscriber_amount");			    
		client.handleMessageFromClientUI(messageToSend);
		SetParameters.add(2,"Frozen");
		SetParameters.remove(3);
		ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.SUBSCRIBERS_COUNTER_IN_A_STATUS, SetParameters, "frozen_subscriber_amount");			    
		client.handleMessageFromClientUI(messageToSend2);
		SetParameters.add(2,"Locked");
		SetParameters.remove(3);
		ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.SUBSCRIBERS_COUNTER_IN_A_STATUS, SetParameters, "locked_subscriber_amount");			    
		client.handleMessageFromClientUI(messageToSend3);
		System.out.println(SetParameters+ "machine1");
		SetParameters.remove(2);
		
		ClientToServerMessage messageToSend4 = new ClientToServerMessage(EQueryOption.DELAYING_BOOK_RETURN_SUBSCRIBER_COUNTER_FROM_TO, SetParameters, "delaying_book_return_subscriber_amount");			    
		client.handleMessageFromClientUI(messageToSend4);
		System.out.println(SetParameters+ "machine2");
		ClientToServerMessage messageToSend5 = new ClientToServerMessage(EQueryOption.BORROWED_BOOK_COUNTER_FROM_TO, SetParameters, "borrowed_book_amount");			    
		client.handleMessageFromClientUI(messageToSend5);
		System.out.println(SetParameters+ "machine3");
		  }catch (IOException e) {
			  
			  System.out.println("do i get here ?");
			e.printStackTrace();
		}
	}
		public void initComboBox() {
			
			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
			//	client.setPrevScene(curr);
				 ArrayList<String> SetParameters = new ArrayList<String>();	
				 SetParameters.add("vasya");
				ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.FILL_ACTIVITY_REPORT_COMBO_BOX, SetParameters, "activity_report_combobox");			    
				client.handleMessageFromClientUI(messageToSend);
						    
				}
			catch (IOException e) {
				e.printStackTrace();
			}		
		}

	@Override
	public void feedback(Object message) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display(Object message) {
		if (message == null) {
			System.out.println("> Server returned null");
		}
		Platform.runLater(new Runnable() {                          
            @Override
            public void run() {
                try{

               	 if (!comboboxflag) {
               		 if( message instanceof ArrayList<?>) {
               		 
               			 ArrayList<String> reports = (ArrayList<String>)message;
               			 list = FXCollections.observableArrayList(reports);
               			comboBoxReportsID.setItems(list);
               		 	        comboboxflag = !comboboxflag;        		 
               		 }
               		 
               	 }  
                	showStage(message);

                }
                catch(Exception e) {
                	System.out.println("Invoke later failed..");
                	e.printStackTrace();
                }
            }
            private void showStage(Object object) throws Exception {
		switch (counter) {
		case 1:
			NumberOfActiveSubscribersID.setText((String)message);
			counter++;
		break;
		case 2:
			NumberOfFrozenSubscribersID.setText((String)message);
			counter++;
			
		break;
		case 3:
			NumberOfLockedSubscribersID.setText((String)message);
			counter++;
			//System.out.println("im the machine!!");
		break;
		case 4:
			NumberOfBorrowedSubscribersID.setText((String)message);
			counter++;
			
		break;
		case 5:
			NumberOfLateReturnSubscribersID.setText((String)message);
			counter=1;
			ArrayList<String> SetParameters2 = new ArrayList<String>();	
			SetParameters2.add(FromID.getText());
			SetParameters2.add(ToID.getText());
			SetParameters2.add(NumberOfActiveSubscribersID.getText());
			SetParameters2.add(NumberOfFrozenSubscribersID.getText());
			SetParameters2.add(NumberOfLockedSubscribersID.getText());
			SetParameters2.add(NumberOfLateReturnSubscribersID.getText());
			SetParameters2.add(NumberOfBorrowedSubscribersID.getText());
			ClientToServerMessage messageToSend6 = new ClientToServerMessage(EQueryOption.ADD_ACTIVITY_REPORT, SetParameters2, null);			    
			client.handleMessageFromClientUI(messageToSend6);
			
		break;
		default: System.out.println("youre gone too far");
		}
	}
		});
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		list = FXCollections.observableArrayList(PreviousReports);
		 comboBoxReportsID.setItems(list);	
	}

	
	
	

}
