package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class SavedActivityReportsController implements  ChatIF {

	@FXML
	private TextField FromID;
	@FXML
	private TextField ToID;
	@FXML
	private TextField NumberOfActiveSubscribersID;
	@FXML
	private TextField NumberOfFrozenSubscribersID;
	@FXML
	private TextField NumberOfLockedSubscribersID;
	@FXML
	private TextField NumberOfBorrowedSubscribersID;
	@FXML
	private TextField NumberOfLateReturnSubscribersID;
	private ConnectionController client;

	
	
	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Report Window");	 
	}
	


	public void initReport(String from, String to) throws IOException {
		client = ConnectionController.getConnectionController();
		client.clientUI = this;
		ArrayList<String> SetParameters2 = new ArrayList<String>();
		SetParameters2.add(from);
		SetParameters2.add(to)	;
		FromID.setText(from);
		ToID.setText(to);
		 ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_ACTIVITY_REPORT_INFO, SetParameters2, "activity_report_show");			    
		 client.handleMessageFromClientUI(messageToSend);
		
	}
	
	
	@Override
	public void display(Object message) {
		ArrayList<String> readyReport = new ArrayList<String>();
		readyReport = (ArrayList<String>)message ;	
		NumberOfActiveSubscribersID.setText(readyReport.get(2));

		NumberOfFrozenSubscribersID.setText(readyReport.get(3));

		NumberOfLockedSubscribersID.setText(readyReport.get(4));

		NumberOfBorrowedSubscribersID.setText(readyReport.get(5));
	
		NumberOfLateReturnSubscribersID.setText(readyReport.get(6));
	}

}
