package client;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import common.ClientToServerMessage;
import common.EQueryOption;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class AddNewBookController implements FeedbackIF {
	
	 private ConnectionController client;

	 private int feedbackCounterPos = 0;
	 private int feedbackCounterNeg = 0;
	 private int feedbackExpected;
	 
	 private final Integer REGULAR_BORROW_PERIOD = 14;
	 private final Integer WANTED_BORROW_PERIOD = 3;
	 private Integer globalISBN;
	 private Integer numberOfCopies;
	 private Integer index;
	 private ArrayList<String> globalBookiInfo;
	 private String globalEditionNumber;	 
	 private String globalPrintDate;
	 
	 @FXML
	 private ChoiceBox<String> WantedTagChoiceBox;
	 @FXML
	 private TextField HeadlineTextField = null, AuthorTextField = null, ISBNTextField = null, CatalogNumberTextField = null, 
	 EditionNumberTextField = null, PrintDateTextField = null, SubjectTextField = null, PurchaseDateTextField = null, 
	 NumberCopiesTextField = null, BorrowPeriodTextField = null, DescriptionTextField = null, ShelfLocationTextField = null;
	 
	 // Add copy	 
	 public void setBookInfo(ArrayList<String> bookiInfo) {
		
		 globalBookiInfo = bookiInfo;
		 globalISBN = Integer.parseInt(bookiInfo.get(2));
		 globalISBN++;
		 numberOfCopies = Integer.parseInt(globalBookiInfo.get(11));
	  		
		 HeadlineTextField.setText(bookiInfo.get(0));
		 AuthorTextField.setText(bookiInfo.get(1));
		 ISBNTextField.setText(globalISBN.toString());
		 CatalogNumberTextField.setText(bookiInfo.get(3));
		 globalEditionNumber = bookiInfo.get(4);
		 EditionNumberTextField.setText(globalEditionNumber);
		 globalPrintDate = bookiInfo.get(5);
		 PrintDateTextField.setText(globalPrintDate);
		 BorrowPeriodTextField.setText(bookiInfo.get(7));
		 
		 SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		 String purchaseDate = dateFormat.format(new Date());
		 
		 PurchaseDateTextField.setText(purchaseDate);
		 SubjectTextField.setText(bookiInfo.get(9));
		 ShelfLocationTextField.setText(bookiInfo.get(10));
		 DescriptionTextField.setText(bookiInfo.get(12));
		 
	 }
	 
	 // Add book
	public void setDefaultInfo(String catalogNumber) {
		
	 	Integer catalog;
		
	 	// Combo-box	
		WantedTagChoiceBox.getItems().removeAll(WantedTagChoiceBox.getItems());
		WantedTagChoiceBox.getItems().addAll("Regular","Wanted");
		WantedTagChoiceBox.getSelectionModel().select("Regular");
		// Purchase date
	  	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	  	String purchaseDate = dateFormat.format(new Date());
	  	PurchaseDateTextField.setText(purchaseDate);
		// Catalog number	 
    	catalog = Integer.parseInt(catalogNumber);
    	catalogNumber = String.format("%04d", catalog);
	  	CatalogNumberTextField.setText(catalogNumber);
	}

	 
	@FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Inventory Management");	 
	}

	 @FXML
	 // Adding new book
	 private void SaveClick(ActionEvent event) throws IOException {
		 
		 	String isbn;
		 
			String bookTitle = HeadlineTextField.getText();
	    	String author = AuthorTextField.getText();
	    	
	    	String catalogNumber = CatalogNumberTextField.getText();
	    	String editionNumber = EditionNumberTextField.getText();
	    	String printDate = PrintDateTextField.getText();
	    	String wantedTag = WantedTagChoiceBox.getValue();
	    	String purchaseDate = PurchaseDateTextField.getText();
			String subject = SubjectTextField.getText();
			String shelfLocation = ShelfLocationTextField.getText();	    	
	    	String numberOfCopies = NumberCopiesTextField.getText();
	    	String description = DescriptionTextField.getText();


	    	
	    	String BorrowPeriod;
			if (wantedTag.equals("Regular"))
	    		BorrowPeriod = REGULAR_BORROW_PERIOD.toString();
			else
				BorrowPeriod = WANTED_BORROW_PERIOD.toString();

	    	if (bookTitle.isEmpty() || author.isEmpty() || catalogNumber.isEmpty() || editionNumber.isEmpty() || printDate.isEmpty() || 
	    			subject.isEmpty() || shelfLocation.isEmpty() || numberOfCopies.isEmpty() || description.isEmpty()) {
	    		Screens.showErrorDialog("Error","Text field cannot be empty", "Please check info");
	    		return;
	    	}
	    	
	    	ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(bookTitle);
			SetParameters.add(author);
			
			isbn = catalogNumber + "00";
			globalISBN = Integer.parseInt(isbn);
			isbn = String.format("%06d", globalISBN);
			SetParameters.add(isbn);	
			
			SetParameters.add(catalogNumber);
			SetParameters.add(editionNumber);
			SetParameters.add(printDate);
			SetParameters.add(subject);
			SetParameters.add(purchaseDate);
			SetParameters.add(numberOfCopies);
			SetParameters.add(wantedTag);
			SetParameters.add(BorrowPeriod);
			SetParameters.add(description);
			SetParameters.add(shelfLocation);
			
		    if (Screens.showConfirmationDialog("Confirmation", "Save details", "Please confirm adding new book")){
			    client = ConnectionController.getConnectionController();
				client.clientUI = null;
				client.clientF = this;
				index = 0;
				feedbackExpected = Integer.parseInt(numberOfCopies);
				
				for(; index < feedbackExpected ; index++)
				{
				    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_NEW_BOOK, SetParameters, null);
				    client.handleMessageFromClientUI(messageToSend);
				    isbn = String.format("%06d", (++globalISBN));
				    SetParameters.set(2, isbn);
				}
				
				Screens.showPrevScreen("Inventory Management");
	    
		   } 
	}
	 

	 @FXML	
	 // Adding new copy
	 private void AddNewCopyClick(ActionEvent event) throws IOException {

		 	String isbn;
		 	ArrayList<String> SetParameters = new ArrayList<String>();

			SetParameters.add(HeadlineTextField.getText());
			SetParameters.add(AuthorTextField.getText());
			
			isbn = String.format("%06d", globalISBN);
			SetParameters.add(isbn);
			globalISBN++;
			
			SetParameters.add(CatalogNumberTextField.getText());
			globalEditionNumber = EditionNumberTextField.getText();
			SetParameters.add(globalEditionNumber);
			globalPrintDate = PrintDateTextField.getText();
			SetParameters.add(globalPrintDate);
			
			if(EditionNumberTextField.getText().isEmpty() || PrintDateTextField.getText().isEmpty()) {
				Screens.showErrorDialog("Invalid information","Text Field cannot be empty", "Please check info");
				return;
			}
			
			SetParameters.add(SubjectTextField.getText());
			SetParameters.add(PurchaseDateTextField.getText());			
			SetParameters.add(numberOfCopies.toString());
			numberOfCopies++;
			String wantedTag = BorrowPeriodTextField.getText();
			SetParameters.add(wantedTag);
			
			if (wantedTag.equals("Regular"))
				SetParameters.add(REGULAR_BORROW_PERIOD.toString());
			else
				SetParameters.add(WANTED_BORROW_PERIOD.toString());	
			
			SetParameters.add(DescriptionTextField.getText());			
			SetParameters.add(ShelfLocationTextField.getText());


			if (Screens.showConfirmationDialog("Confirmation", "Add Book Copy",
							"Please confirm adding new copy \nunder catalog number " + globalBookiInfo.get(3))) {	
				
				client = ConnectionController.getConnectionController();
				client.clientUI = null;
				client.clientF = this;
				feedbackExpected = 2;
				ClientToServerMessage messageToSend1 = new ClientToServerMessage(EQueryOption.ADD_NEW_BOOK, SetParameters, null);
			    client.handleMessageFromClientUI(messageToSend1);
			    			    
			    ArrayList<String> SetParameters2 = new ArrayList<String>();
			    SetParameters2.add(globalBookiInfo.get(3));
			    SetParameters2.add("+1");
			    
				ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.UPDATE_NUMBERS_OF_BOOKS, SetParameters2, null);
			    client.handleMessageFromClientUI(messageToSend2);
			}
	 }

		@Override
		public void feedback(Object msg)
		{
			System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
			
			 Platform.runLater(new Runnable() {                          
		            @Override
		            public void run() {
		            	String status = (String)msg;
		            	
		    			if(status.equals("Success"))
		    				feedbackCounterPos++;
		    			else 
		    				feedbackCounterNeg++;
		    			
		    			int totalCounter = feedbackCounterPos + feedbackCounterNeg;
		    			
		    			if(totalCounter == feedbackExpected)
		    			{
		    				if(feedbackCounterPos == feedbackExpected)
		    					{
		    						Screens.showSuccessDialog("Notification", "Successful update", "Database was updated successfully");
		    						ISBNTextField.setText(globalISBN.toString());
		    						EditionNumberTextField.setText(globalEditionNumber);
		    						PrintDateTextField.setText(globalPrintDate);
		    					}
		    				else
		    					Screens.showErrorDialog("Error","Faild to update", "Could not update database");
		    				
		    				feedbackCounterPos = 0;
		    				feedbackCounterNeg = 0;
		    			}
		    			
		            }
		            
			 });
					
		}
	

}
