package client;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

import java.io.IOException;
import java.util.*;
import javafx.stage.*;



public class Screens {
	
	private static ConnectionController client;

	//~~~~~~~~~~~~~~~~~~~~~~~~~ Screen Manipulation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	public static void showPrevScreen(String stageName) {
		
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle(stageName);
			stage.setScene(scene);		
			stage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void showNewScreen(String fxmlPath, String stylesheetPath, String stageName)
	{
		FXMLLoader loader = new FXMLLoader();
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource(fxmlPath).openStream());
			Scene scene = new Scene(root);	
			if(stylesheetPath != null)
				scene.getStylesheets().add(Main.class.getResource(stylesheetPath).toExternalForm());
			stage.setTitle(stageName);
			stage.setScene(scene);
			stage.show();
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~ Feedback Handling ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	public static void singleFeedback(Object msg)
	{
		
		System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
		Platform.runLater(new Runnable() {                          
		            @Override
		            public void run() {
		            	String status = (String)msg;
		            	
		    			if(status.equals("Success"))
		    				Screens.showSuccessDialog("Notification", "Successful update", "Database was updated successfully");
		    			else 
		    				Screens.showErrorDialog("Error","Faild to update", "Could not update database");
		            }
		            
			 });
		
	}
	
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~ Alert Factory ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	public static void showErrorDialog(String title, String header, String content) 
	{
		Alert alert = new Alert(AlertType.ERROR);
		alert.getDialogPane();
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.show();
	}
	
	public static void showSuccessDialog(String title, String header, String content) 
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.getDialogPane();
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.show();
	}
	
	public static boolean showConfirmationDialog(String title, String header, String content) 
	{
	    Alert alert = new Alert(AlertType.CONFIRMATION); 
	    alert.setTitle(title);
	    alert.setHeaderText(header);
	    alert.setContentText(content);
	    Optional<ButtonType> result = alert.showAndWait();
	    return result.get() == ButtonType.OK;
	}

}
