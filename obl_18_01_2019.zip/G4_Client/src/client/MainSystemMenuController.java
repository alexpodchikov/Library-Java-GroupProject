package client;


import java.io.IOException;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.Optional;
import common.ClientToServerMessage;
import common.ChatIF;
import common.Student;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import common.EQueryOption;

public class MainSystemMenuController implements ChatIF {
	
	private ConnectionController client;	
	@FXML
	private Label ConnectionStatus;	  
	@FXML
	private TextField ServerIPAddressTextField;

	public void EstablishConnection(ActionEvent event) {
    	Stage curr = (Stage)((Node)event.getSource()).getScene().getWindow();
		try {
				//String ServerIPAddress = ServerIPAddressTextField.getText();
				//ConnectionController.Host = ServerIPAddress;
				client = ConnectionController.getConnectionController();
				client.setStage(curr);
				client.clientUI = this;
				ConnectionStatus.setText("Connected");
				ConnectionStatus.setTextFill(Color.GREEN);
		}
		catch (IOException e) {
			System.out.println(e+" got you");
			ConnectionStatus.setText("Disconnected");
			ConnectionStatus.setTextFill(Color.RED);
		}
	}
	
	public void start(Stage primaryStage) throws Exception 
	{	
		Parent root = FXMLLoader.load(getClass().getResource("/client/MainSystemMenu.fxml"));				
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/client/MainSystemMenu.css").toExternalForm());
		primaryStage.setTitle("Main System Menu");
		primaryStage.setResizable(true);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	@FXML
	public void QuitApplicationClick(ActionEvent event) {
    	try {
    		if (client != null && client.isConnected())
    			client.closeConnection();
		} 
    	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 Platform.exit();
	     System.exit(0);
	}
	

//?????????? Never used ?????????????????	
	@Override
	public void display(Object msg) {
		if (msg == null) 
			System.out.println("> Server returned null");			
		else System.out.println("> Server returned: "+msg.toString());
			
		/**
		* Display error dialog is server returned null.
		* TODO: make stage factory.
		*/
		Platform.runLater(new Runnable() {                          
		    @Override
		    public void run() {
		       try{
		    	   if (msg == null) { 
		    		   Screens.showErrorDialog("Error","Entry not found", "Blah blah!");
		    		   //Screens.showErrorDialog("Error","Entry not found", "Server didn't find the entry requested!");
		               return;
		           }
		      }
		      catch(Exception e) {
		           System.out.println("Invoke later failed..");
		           e.printStackTrace();
		      }
		   }
		});
	}	

		@FXML
		private void LoginClick(ActionEvent event) {
			Scene curr = (Scene)((Node)event.getSource()).getScene();
			if (client == null || !client.isConnected()) { 
	    		ConnectionStatus.setText("Disconnected");             
				ConnectionStatus.setTextFill(Color.RED);
				Screens.showErrorDialog("Error","Server disconnected", "Please first connect to server.");
	    		return;
	    	}
			
			// Login window displayed separately
			Stage stage = new Stage();
			FXMLLoader loader = new FXMLLoader();
			Parent root;
			try {
				root = loader.load(getClass().getResource("/client/LoginScreen.fxml").openStream());
				client.setPrevScene(curr);
				Scene scene = new Scene(root);			
				stage.setTitle("Login");
				stage.setScene(scene);
				stage.show();
				}  
			catch (IOException e) {
				// TODO add to error manager
				e.printStackTrace();
			}
		}
		
		@FXML
		private void SearchBookClick(ActionEvent event){
			Scene curr = (Scene)((Node)event.getSource()).getScene();
	    	if (client == null || !client.isConnected()) { 
	    		ConnectionStatus.setText("Disconnected");             
				ConnectionStatus.setTextFill(Color.RED);
				Screens.showErrorDialog("Error","Server disconnected", "Please first connect to server.");
	    		return;
	    	}
	    	
	    	client.setPrevScene(curr);
	    	Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
		}
		
}
