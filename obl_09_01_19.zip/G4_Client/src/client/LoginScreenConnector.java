package client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import common.User;
import common.ClientToServerMessage;
import common.ChatIF;
import common.EQueryOption;
import common.IClient;
import common.Student;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LoginScreenConnector implements ChatIF  {	
	public final static int DEFAULT_PORT = 5555;			// default port to connect.
	public final static String DEFAULT_HOST = "localhost";	// default host to connect.
	 @FXML
	 private TextField UserNameTextField;
	 @FXML
	 private PasswordField PasswordTextField;
	 private ConnectionController connectionController;			// user database handler.
	 private String connectedUserID= null;
	 private String userName= null;
	
    @FXML
    void BackToMainSystemMenuClick(ActionEvent event) {
		((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary window
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/MainSystemMenu.fxml").openStream());		
			Scene scene = new Scene(root);	
			scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
			stage.setTitle("Main System Menu");
			stage.setScene(scene);		
			stage.show();	
			} 
		catch (IOException e)
			{
			// TODO add to error manager
			e.printStackTrace();
			}
    }
    public void EstablishConnection(ActionEvent event) {
		try {
			if (connectionController != null && connectionController.isConnected())
			{connectionController.closeConnection();}
			
				//String ServerIPAddress = ServerIPAddressTextField.getText();
				//Host = ServerIPAddress;
				connectionController = new ConnectionController(DEFAULT_HOST,DEFAULT_PORT,this );
			

				}
	 catch (IOException e) {
			System.out.println(e+" got you");

	}
	}
    
	/**
	 * Login button pressed. validate login info.
	 * @param event login button pressed.
	 */
    @FXML	
    private void LoginClick(ActionEvent event) {
		String UserName = UserNameTextField.getText();
    	String Password = PasswordTextField.getText();
    	if (UserName.isEmpty() || Password.isEmpty()) {
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.getDialogPane();//.getStylesheets().add("/style.css");
    		alert.setTitle("Invalid username or password");
    		alert.setHeaderText("Cannot be empty");
    		alert.setContentText("Please check your info");
    		alert.show();
    		//WindowFactory.showErrorDialog("Invalid username or password","Cannot be empty", "Please check your info");
    		return;
    	}
	
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(UserName);
		SetParameters.add(Password);
		EstablishConnection(null);
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, SetParameters,"User");
	    connectionController.handleMessageFromClientUI(messageToSend); 
	    connectedUserID=UserName;
	    
	}
    
  

	@Override
	public void display(Object msg) {
		if (msg == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+msg.toString());
		
		/**
		 * Display error dialog is server returned null.
		 * TODO: make stage factory.
		 */
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	                try{
	                	if (msg == null) {
	                		Alert alert = new Alert(AlertType.ERROR);
	                		alert.setTitle("Error");
	                		alert.setHeaderText("Entry not found");
	                		alert.setContentText("Server didn't find the entry requested!");
	                		alert.show();
	                		return;
	                	}
	                	
	            		Stage stage = getStage(msg);
	            		if (stage != null) {
	            			System.out.println("stage is not null");
	            		
	            			stage.show();
	            		}
	            		else {
	            			System.out.println("stage is null");
	            			//TODO: add suitable stage
	            		}

	                }
	                catch(Exception e) {
	                	System.out.println("Invoke later failed..");
	                	e.printStackTrace();
	                }
	            }
	            
	        	
	        	/**
	        	 * Get suitable stage for suitable form by object type..
	        	 * @param object
	        	 * @return suitable stage
	        	 * @throws Exception
	        	 */
	        	private Stage getStage(Object object) throws Exception {
	        		Stage stage= new Stage();
	        	  	FXMLLoader loader= new FXMLLoader();
	        		Pane root;
	        		String mainMenuAccount = null;
	        		User loginInfo = (User)object;
	        		
	        		 
	        		// get user stage
	        		if (object instanceof User) {
	        			switch (loginInfo.getAccountType().toLowerCase().trim()) {
	        			case "student":
	        				mainMenuAccount = "/client/SubscriberSystemMenu.fxml";
	        				break;
	        			case "librarian":
	        				
	        				mainMenuAccount = "/client/LibrarianMainScreen.fxml";
	        				break;
	        			case "librarymanager":
	        				mainMenuAccount = "/client/LibrarianManagerMainScreen.fxml";
	        				break;
	        				default:
	        					System.out.println("There is no such user");
	        				}
	        			System.out.println(mainMenuAccount);        		
	        			root = loader.load(getClass().getResource(mainMenuAccount).openStream());
	        			Scene scene = new Scene(root);					
	        			stage.setScene(scene);	
	        			stage.setResizable(false);
	        			
	        		} 
	        		return stage;
	        	}
	        });
		}
	}
	
