package client;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.layout.Pane;

import java.util.*;
import common.*;
import javafx.stage.*;



public class Screens {
	public static Stage stage = null;
	
	/**
	 * Open a new fxml window. The fxmlPath's controller MUST implement IController!
	 * Can pass objects to the next fxml controller.
	 * 
	 * @param fxmlPath new window's fxml path.
	 * @param objects parameters to pass.
	 */
	public static void show(String fxmlPath, Object...objects) {
		FXMLLoader loader = new FXMLLoader();
		try {
			loader.setLocation(Main.class.getResource(fxmlPath));
			Pane root = loader.load();
			DetailsController controller = loader.getController();
			if (objects != null)
				controller.setDetails(objects);	// pass objects.
			root.setId("pane");
			Scene scene = new Scene(root);	
			//scene.getStylesheets().addAll(Screens.class.getResource("/style.css").toExternalForm());
			stage.setScene(scene);
		//	setCenter(stage); ///////Do we need it????????????????????
			stage.show();			
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
