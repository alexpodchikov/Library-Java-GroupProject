package client;

import java.io.IOException;

import common.Book;
import common.ChatIF;
import common.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class SubscriberMainScreenController  implements ChatIF{
	
	 private String connectedUserID= null;
	 private String connectedUserAccount= null;
	 private User localUser= null;
	 private ConnectionController connectionController ;
	 
	
	 public void  saveUserDetails (User user, ConnectionController connectionController) throws Exception{
		 connectedUserID=user.getUserName();
		 connectedUserAccount=user.getAccountType();
		 localUser = (User) user;
			System.out.println(localUser.accountType + "3334");
		 }
	
	@FXML
	private void BookSearchClick(ActionEvent event) throws Exception {
		 
		Stage stage = MainSystemMenuController.stage1;
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/BookSearch.fxml").openStream());
			Scene scene = new Scene(root);	
			//scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
			stage.setTitle("BookSearch");
			stage.setScene(scene);		
			stage.show();
			BookSearchController controller = loader.getController();
			controller.saveDetails(localUser, connectionController); 
			} 
		catch (IOException e) 
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}

}
