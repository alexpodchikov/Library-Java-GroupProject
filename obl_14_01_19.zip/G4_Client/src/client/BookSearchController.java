package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class BookSearchController implements ChatIF {
	
	 private String backScreen;
	
	 @FXML
	 private TextField bookTitleTextField=null;
	 @FXML
	 private TextField authorNameTextField=null;
	 @FXML
	 private TextField subjectTextField=null;
	 @FXML
	 private TextField descriptionTextField=null;
	 @FXML
	 private RadioButton RB1ButtonID;
	 @FXML
	 private RadioButton RB2ButtonID;
	 @FXML
	 private RadioButton RB3ButtonID;
	 @FXML
	 private RadioButton RB4ButtonID;
     // @FXML
     // final ToggleGroup group = new ToggleGroup();
	 //public final static int DEFAULT_PORT = 5555;			// default port to connect.
	 //public final static String DEFAULT_HOST = "localhost";
	 
	 @FXML
	 private TextField catalogNumberTextField;
	 @FXML
	 private TextField bookNameTextField;
	 @FXML
	 private TextField nextReturtDateTextField;
	 
	// private  MainSystemMenuController host = new MainSystemMenuController();
	 
	 private String connectedUserID= null;
	 private String connectedUserAccount= "Main";
	 private ConnectionController connectionController;
	 
	 public void  saveDetails (User user, ConnectionController Controller) throws Exception{
		 connectedUserID=user.getUserName();
		 connectedUserAccount=user.getAccountType();
		 
		System.out.println(connectedUserAccount+"12345");

		 }
	 
	 @FXML
	    void BackClick(ActionEvent event) throws Exception {
		 connectionController = new ConnectionController(MainSystemMenuController.Host,MainSystemMenuController.DEFAULT_PORT,this);
			Stage stage = MainSystemMenuController.stage1;
			FXMLLoader loader = new FXMLLoader();
			Pane root;
			switch (connectedUserAccount.toLowerCase().trim()) {
			case "librarian":
				root = loader.load(getClass().getResource("/client/LibrarianMainScreen.fxml").openStream());		
				Scene scene = new Scene(root);	
				//scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
				stage.setTitle("LibrarianMainScreen");
				stage.setScene(scene);		
				stage.show();	
				break;
			case "student":
				root = loader.load(getClass().getResource("/client/SubscriberSystemMenu.fxml").openStream());		
				Scene scene1 = new Scene(root);	
				//scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
				stage.setTitle("SubscriberSystemMenu");
				stage.setScene(scene1);		
				stage.show();
				break;
			case "librarymanager":
				root = loader.load(getClass().getResource("/client/LibraryManagerMainScreen.fxml").openStream());		
				Scene scene2 = new Scene(root);	
				//scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
				stage.setTitle("LibraryManagerMainScreen");
				stage.setScene(scene2);		
				stage.show();
				break;
			default:
				System.out.println("There is no such user");
				root = loader.load(getClass().getResource("/client/MainSystemMenu.fxml").openStream());		
				Scene scene3 = new Scene(root);	
				scene3.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
				stage.setTitle("MainSystemMenu");
				stage.setScene(scene3);		
				stage.show();
				} 
			
			}
	 @FXML	
	    private void RB1Clicked(ActionEvent event) {

		 bookTitleTextField.setEditable(true);
		 authorNameTextField.setEditable(false);
		 subjectTextField.setEditable(false);
		 descriptionTextField.setEditable(false);
	 }
	 @FXML	
	    private void RB2Clicked(ActionEvent event) {
		 bookTitleTextField.setEditable(false);
		 authorNameTextField.setEditable(true);
		 subjectTextField.setEditable(false);
		 descriptionTextField.setEditable(false);
	 }
	 @FXML	
	    private void RB3Clicked(ActionEvent event) {
		 bookTitleTextField.setEditable(false);
		 authorNameTextField.setEditable(false);
		 subjectTextField.setEditable(true);
		 descriptionTextField.setEditable(false);
	 }
	 @FXML	
	    private void RB4Clicked(ActionEvent event) {
		 bookTitleTextField.setEditable(false);
		 authorNameTextField.setEditable(false);
		 subjectTextField.setEditable(false);
		 descriptionTextField.setEditable(true);
	 }	
	 
	 
	 @FXML	
	    private void SearchClick(ActionEvent event) throws IOException {
			String bookTitle = bookTitleTextField.getText();
	    	String authorName = authorNameTextField.getText();
	    	String subject = subjectTextField.getText();
	    	String description = descriptionTextField.getText();
	    	if (bookTitle.isEmpty() && authorName.isEmpty() && subject.isEmpty() && description.isEmpty()) {
	    		Screens.showErrorDialog("Invalid search information","Cannot be empty", "Please check search info");
	    		return;
	    	}
		
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(bookTitle);
			SetParameters.add(authorName);
			SetParameters.add(subject);
			SetParameters.add(description);
			connectionController = new ConnectionController(MainSystemMenuController.Host,MainSystemMenuController.DEFAULT_PORT,this);
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BOOK_INFO, SetParameters, "Book");
		    connectionController.handleMessageFromClientUI(messageToSend); 
		  
		}


		@Override
		public void display(Object msg) {
			// TODO Auto-generated method stub
			
			if (msg == null) {
				System.out.println("> Server returned null");
			}
			else System.out.println("> Server returned: "+msg.toString());
			
			/**
			 * Display error dialog is server returned null.
			 * TODO: make stage factory.
			 */
			 Platform.runLater(new Runnable() {                          
		            @Override
		            public void run() {
		                try{
		                	if (msg == null) {
		                		Screens.showErrorDialog("Error","Entry not found", "Server didn't find the entry requested!");
		                		return;
		                	}
		                	
		            		Stage stage = getStage(msg);
		            		if (stage != null) {
		            			//System.out.println("stage is not null");
		            			stage.show();
		            		}
		            		else {
		            			//System.out.println("stage is null");
		            			//TODO: add suitable stage
		            		}

		                }
		                catch(Exception e) {
		                	System.out.println("Invoke later failed..");
		                	e.printStackTrace();
		                }
		            }
		            
		        	/**
		        	 * Get suitable stage for suitable form by object type..
		        	 * @param object
		        	 * @return suitable stage
		        	 * @throws Exception
		        	 */
		        	private Stage getStage(Object object) throws Exception {
		        	
		        		Stage stage = MainSystemMenuController.stage1; //MainSystemMenuController.stage1;
		        	  	FXMLLoader loader= new FXMLLoader();
		        		Pane root;
		        		String bookSearchResult = null;
		        		Book bookInfo = (Book)object;
		        		// get user stage
		        		if (object instanceof Book) {
		        			System.out.println( bookInfo.getBookName());
		        			System.out.println( bookInfo.getCatalogNumber());
		        			System.out.println( bookInfo.getNextReturnDate());
		        			System.out.println( bookInfo.getAvailableCopy());
		        			
		        			if( bookInfo.getAvailableCopy()) {
		        				bookSearchResult = "/client/BookSearchInStockResultWindow.fxml";
		        				stage.setTitle("Book Search In Stock");
		        				root = loader.load(getClass().getResource(bookSearchResult).openStream());
			        			Scene scene = new Scene(root);					
			        			stage.setScene(scene);	
			        			stage.setResizable(false);
			        			BookSearchInStockController controller = loader.getController();
			        			controller.setBookDetails((Book)object, connectionController); 
			        				        			
		        			}
		        				else {
		        					
		        					bookSearchResult = "/client/BookSearchNotInStockLogedInResultWindow.fxml";
		        					stage.setTitle("Book Search Not In Stock");
				        			root = loader.load(getClass().getResource(bookSearchResult).openStream());
				        			Scene scene = new Scene(root);					
				        			stage.setScene(scene);	
				        			stage.setResizable(false);
				        			BookSearchNotInStockController controller = loader.getController();
				        			controller.setReturnDetails((Book)object, connectionController); 
		        			
				       
		        				}
		        		
		        		} 
		        		return stage;
		        	}
		        });
			}
	
}
