package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class BookSearchNotInStockController{
	
	@FXML
	private Label nextReturnDateLabel;
	@FXML
	private Label bookNameLabel;	
	
	 public void  setReturnDetails (Book book, ConnectionController Controller) throws Exception{
		 
		bookNameLabel.setText(book.bookName);
		nextReturnDateLabel.setText(book.nextReturnDate);

	 }
	 
	    @FXML
	    void BackClick(ActionEvent event) {
			((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary window
			Stage stage = MainSystemMenuController.stage1;
			FXMLLoader loader = new FXMLLoader();
			Pane root;
			try {
				root = loader.load(getClass().getResource("/client/BookSearch.fxml").openStream());		
				Scene scene = new Scene(root);	
				//scene.getStylesheets().add(getClass().getResource("BookSearch.css").toExternalForm());
				stage.setTitle("Book Search");
				stage.setScene(scene);		
				stage.setResizable(false);
				stage.show();	
				
				} 
			catch (IOException e)
				{
				// TODO add to error manager
				e.printStackTrace();
				}
	    }
	

}
