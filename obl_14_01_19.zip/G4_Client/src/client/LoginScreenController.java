package client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import common.User;
import common.ClientToServerMessage;
import common.Book;
import common.ChatIF;
import common.EQueryOption;
import common.IClient;
import common.Student;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LoginScreenController implements ChatIF  {	
	//public final static int DEFAULT_PORT = 5555;			// default port to connect.
	//public final static String DEFAULT_HOST = "localhost";	// default host to connect.
	 @FXML
	 private TextField UserNameTextField;
	 @FXML
	 private PasswordField PasswordTextField;
	 private ConnectionController connectionController;			// user database handler.
	//private  MainSystemMenuController host = new MainSystemMenuController();
	 
	
    @FXML
    void BackToMainSystemMenuClick(ActionEvent event) {
    
		((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary window
		Stage stage = MainSystemMenuController.stage1;
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/MainSystemMenu.fxml").openStream());		
			Scene scene = new Scene(root);	
			scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
			stage.setTitle("MainSystemMenu");
			stage.setScene(scene);		
			stage.setResizable(false);
			stage.show();	
			
			} 
		catch (IOException e)
			{
			// TODO add to error manager
			e.printStackTrace();
			}
    }
    
	/**
	 * Login button pressed. validate login info.
	 * @param event login button pressed.
	 * @throws IOException 
	 */
    @FXML	
    private void LoginClick(ActionEvent event) throws IOException {
		String UserName = UserNameTextField.getText();
    	String Password = PasswordTextField.getText();
    	if (UserName.isEmpty() || Password.isEmpty()) {
    		Screens.showErrorDialog("Invalid username or password","Cannot be empty", "Please check your info");
    		return;
    	}
    	
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(UserName);
		SetParameters.add(Password);
		//host.getStage1().getScene().getWindow().hide();
		connectionController = new ConnectionController(MainSystemMenuController.Host,MainSystemMenuController.DEFAULT_PORT,this);
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, SetParameters,"User");
	    connectionController.handleMessageFromClientUI(messageToSend); 
	    
	    
	}
    
  

	@Override
	public void display(Object msg) {
		if (msg == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+msg.toString());
		
		/**
		 * Display error dialog is server returned null.
		 * TODO: make stage factory.
		 */
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	                try{
	                	if (msg == null) {
	                		Screens.showErrorDialog("Error","Entry not found", "Server didn't find the entry requested!");
	                		return;
	                	}
	                	
	            		Stage stage = getStage(msg);
	            		if (stage != null) {
	            			//System.out.println("stage is not null");
	            				
	            			stage.show();
	            		}
	            		else {
	            		//	System.out.println("stage is null");
	            			//TODO: add suitable stage
	            		}

	                }
	                catch(Exception e) {
	                	System.out.println("Invoke later failed..");
	                	e.printStackTrace();
	                }
	            }
	            
	        	
	        	/**
	        	 * Get suitable stage for suitable form by object type..
	        	 * @param object
	        	 * @return suitable stage
	        	 * @throws Exception
	        	 */
	        	private Stage getStage(Object object) throws Exception {
	        	
	        		Stage stage = MainSystemMenuController.stage1;
	        	  	FXMLLoader loader= new FXMLLoader();
	        		Pane root;
	        		String mainMenuAccount = null;
	        		User loginInfo = (User)object;
	        		
	        		// get user stage
	        		if (object instanceof User) {
	        			switch (loginInfo.getAccountType().toLowerCase().trim()) {
	        			case "student":
	        				mainMenuAccount = "/client/SubscriberSystemMenu.fxml";
	        				stage.setTitle("SubscriberSystemMenu");
	        				root = loader.load(getClass().getResource(mainMenuAccount).openStream());
		        			Scene scene = new Scene(root);					
		        			stage.setScene(scene);	
		        			stage.setResizable(false);
		        			SubscriberMainScreenController controller1 = loader.getController();
	        				controller1.saveUserDetails((User)object, connectionController); 
	        				
	        				break;
	        			case "librarian":
	        				mainMenuAccount = "/client/LibrarianMainScreen.fxml";	        			
	        				stage.setTitle("LibrarianMainScreen");	        				
	        				root = loader.load(getClass().getResource(mainMenuAccount).openStream());
		        			Scene scene1 = new Scene(root);					
		        			stage.setScene(scene1);	
		        			stage.setResizable(false);
		        			LibrarianMainMenuController controller = loader.getController();
	        				controller.saveUserDetails((User)object, connectionController); 
	        				break;
	        			case "librarymanager":
	        				mainMenuAccount = "/client/LibraryManagerMainScreen.fxml";
	        				stage.setTitle("LibraryManagerMainScreen");
	        				root = loader.load(getClass().getResource(mainMenuAccount).openStream());
		        			Scene scene2 = new Scene(root);					
		        			stage.setScene(scene2);	
		        			stage.setResizable(false);
		        			LibraryManagerMainScreenController controller2 = loader.getController();
	        				controller2.saveUserDetails((User)object, connectionController); 
	        				break;
	        				default:
	        					System.out.println("There is no such user");
	        				}
	        
	        		} 
	        		return stage;
	        	}
	        });
		}
	}
	
