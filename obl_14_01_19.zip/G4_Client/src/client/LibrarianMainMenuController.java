package client;

import java.io.IOException;

import common.Book;
import common.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LibrarianMainMenuController {
	
	 private String connectedUserID= null;
	 private String connectedUserAccount= null;
	 private User localUser= null;
	 private ConnectionController connectionController;
	private  MainSystemMenuController host = new MainSystemMenuController();
	 

		/*	if (connectionController == null || !connectionController.isConnected()) { 
	    		ConnectionStatus.setText("Disconnected");             
				ConnectionStatus.setTextFill(Color.RED);
	    		return;
	    	}
	    	*/
		    //((Node)event.getSource()).getScene().getWindow().hide(); //hiding LibrarianMainMenu window
			
	 public void  saveUserDetails (User user, ConnectionController Controller) throws Exception{
		 connectedUserID=user.getUserName();
		 connectedUserAccount=user.getAccountType();
		localUser = (User) user;
		
		 }
	
	@FXML
	private void BookSearchClick(ActionEvent event) throws Exception {
	
		Stage stage = MainSystemMenuController.stage1;
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/BookSearch.fxml").openStream());
			Scene scene = new Scene(root);	
			//scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
			stage.setTitle("BookSearch");
			stage.setScene(scene);		
			stage.show();
			BookSearchController controller = loader.getController();
			controller.saveDetails(localUser, connectionController); 
			} 
		catch (IOException e) 
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}
	
		
	
		
	
	
	@FXML	
	 public void LogoutClick(ActionEvent event) {
		
	//	Event("/client/MainSystemMenu.fxml", "MainSystemMenu");

	}
	
	@FXML
	private void InventoryManagementClick(ActionEvent event) {
		
		//Event("/client/InventoryManagementWindow.fxml", "InventoryManagement");

	}
	
	@FXML
	private void AddReaderCardClick(ActionEvent event) {
		
		//Event("/client/SubscriberAddingForm.fxml", "SubscriberAddingForm");

	}
	
}
