package client;

import java.io.IOException;

import common.ChatIF;
import common.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LibraryManagerMainScreenController implements ChatIF {
	
	 private String connectedUserID= null;
	 private String connectedUserAccount= null;
	 private User localUser= null;
	 private ConnectionController connectionController;
	
	 public void  saveUserDetails (User user, ConnectionController connectionController) throws Exception{
		 connectedUserID=user.getUserName();
		 connectedUserAccount=user.getAccountType();
		 localUser = (User) user;
			System.out.println(localUser.accountType + "111122");
		 }
	 
	@FXML
	private void BookSearchClick(ActionEvent event) throws Exception {
	/*	if (connectionController == null || !connectionController.isConnected()) { 
    		System.out.println("no connection");
    		return;
    	}*/
    	
	    //((Node)event.getSource()).getScene().getWindow().hide(); //hiding LibrarianMainMenu window
		connectionController = new ConnectionController(MainSystemMenuController.Host,MainSystemMenuController.DEFAULT_PORT,this);
		Stage stage = MainSystemMenuController.stage1;
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/BookSearch.fxml").openStream());
			Scene scene = new Scene(root);			
			stage.setTitle("BookSearch");
			stage.setScene(scene);		
			stage.show();
			BookSearchController controller = loader.getController();
			controller.saveDetails(localUser, connectionController);
		
			} 
		catch (IOException e) 
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}

	
	@FXML	
	 public void LogoutClick(ActionEvent event) {
		//((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary window
		Stage stage = MainSystemMenuController.stage1;
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/MainSystemMenu.fxml").openStream());		
			Scene scene = new Scene(root);	
			scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
			stage.setTitle("MainSystemMenu");
			stage.setScene(scene);		
			stage.setResizable(false);
			stage.show();
			} 
		catch (IOException e)
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}
	
	
	@FXML
	private void InventoryManagementClick(ActionEvent event) {
	/*	if (connectionController == null || !connectionController.isConnected()) { 
    		ConnectionStatus.setText("Disconnected");             
			ConnectionStatus.setTextFill(Color.RED);
    		return;
    	}
    	*/
	    //((Node)event.getSource()).getScene().getWindow().hide(); //hiding LibrarianMainMenu window
		Stage stage = MainSystemMenuController.stage1;
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/InventoryManagementWindow.fxml").openStream());
			Scene scene = new Scene(root);			
			stage.setTitle("InventoryManagement");
			stage.setScene(scene);		
			stage.show();
			} 
		catch (IOException e) 
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
}
