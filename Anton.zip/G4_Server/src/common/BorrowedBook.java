package common;
import java.io.Serializable;

public class BorrowedBook  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 511837015879654821L;
	public String userID;
	public String bookID;		
	public String borrowDate;
	public String returnDate;
	public String borrowStatus;
	public boolean prolongationRequest;
	
	public BorrowedBook(String BookID) {
		
		this.bookID = BookID;
	}
	public BorrowedBook( String BookID ,String  UserID ,  String BorrowDate,String ReturnDate,String BorrowStatus,boolean  ProlongationRequest) {		
		
		this.bookID = BookID;
		this.userID = UserID;	
		this.borrowDate = BorrowDate;
		this.returnDate = ReturnDate;
		this.borrowStatus = BorrowStatus;
		this.prolongationRequest = ProlongationRequest;
	}
	
	public String getBookID() {
		return bookID;
	}
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getBorrowDate() {
		return borrowDate;
	}
	public void setBorrowDate(String borrowDate) {
		this.borrowDate = borrowDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getBorrowStatus() {
		return borrowStatus;
	}
	public void setBorrowStatus(String borrowStatus) {
		this.borrowStatus = borrowStatus;
	}
	public boolean getProlongationRequest() {
		return prolongationRequest;
	}
	public void setProlongationRequest(boolean prolongationRequest) {
		this.prolongationRequest = prolongationRequest;
	}
	
	@Override
	public String toString() {
	return	bookID;
	}
} 
