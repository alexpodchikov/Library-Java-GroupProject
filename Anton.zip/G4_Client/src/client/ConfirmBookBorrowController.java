package client;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.text.*;
import java.time.LocalDate;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class ConfirmBookBorrowController {	
	
	private String borrowerID;
	private String requestedBookID;
	
	public void setBorrowingInfo(String borrowerID, String requestedBookID) {
		this.borrowerID = borrowerID;
		this.requestedBookID = requestedBookID;
	}
	
	@FXML
	private ConnectionController client;			// user database handler.
	@FXML
	private Label subscriberFullNameLabel;
	@FXML
	private Label borrowDateLabel;
	@FXML
	private Label returnDateLabel;
	
	
	// Create date
	//Date today = new Date();
	/*
	LocalDate today =  LocalDate.now();
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	String borrowDate = dateFormat.format(today);
	LocalDate returnDay = LocalDate.now().plusDays(3);		//add 3 or 14 days to today date
	String returnDate = dateFormat.format(returnDay);
	*/
	
	//BorrowedBook borrowedBook = new BorrowedBook(bookName, bookID, userID, borrowDate, returnDate); 

	
	public void  setBorrowedBooklDetais(User subscriber, BorrowedBook book, ConnectionController Controller) throws Exception{				 
		subscriberFullNameLabel.setText(subscriber.userName);
		//borrowDateLabel.setText(book.borrowDate);
		//returnDateLabel.setText(book.returnDate);
		borrowDateLabel.setText(subscriber.userName);
		returnDateLabel.setText(subscriber.userName);
		
		/*
		 * 
		 * 	String borrowDate = borrowDateLabel.getText();
			String returnDate = returnDateLabel.getText();
		 */
	}	 
/*	
	 @FXML	
	    private void OkClick(ActionEvent event) throws IOException {
		


			ArrayList<String> SetParameters = new ArrayList<String>();
			//SetParameters.add(bookID);
			//SetParameters.add(userID);
			SetParameters.add(requestedBookID);
			SetParameters.add(borrowerID);
			SetParameters.add(borrowDate);
			SetParameters.add(returnDate);

			try {
				client = ConnectionController.getConnectionController();
				//client.clientUI = this;
				ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_BORROWED_BOOK, SetParameters, "BorrowedBook");		//add this book copy to borrowed book
				ClientToServerMessage messageToSend_2 = new ClientToServerMessage(EQueryOption.SET_BOOK_AVAILABILITY_OFF, SetParameters, "Book");	//set this book copy unavailable
			    client.handleMessageFromClientUI(messageToSend);
				}
			catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	   */
	@FXML
	void BackClick(ActionEvent event) {
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle("Confirm Book Search");
			stage.setScene(scene);		
			stage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}			        
}