package client;

import java.io.IOException;

import common.ChatIF;
import common.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LibraryMainScreenController implements ChatIF {
	
	private ConnectionController client;
	
	@FXML
	private TextField borrowingUserIDTextField;
	@FXML
	private TextField borrowedBookIDTextField;
	@FXML
	private TextField returnedBookIDTextField;
		
	@FXML
	private void BookSearchClick(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene(); 
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	@FXML
	private void inventoryClicked(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/InventoryManagementWindow.fxml", null, "Inventory Management");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void borrowClick(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/ConfirmBookBorrow.fxml", null, "Confirm Book Borrow Order");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	@FXML
	private void logoutClicked(ActionEvent event) {
		
		Screens.showPrevScreen("Main System Menu");	
	}
	

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
}
