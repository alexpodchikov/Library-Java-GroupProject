package client;

import java.io.IOException;

import common.ChatIF;
import common.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LibraryManagerMainScreenController implements ChatIF {
	
//	 private String connectedUserID= null;
//	 private String connectedUserAccount= null;
//	 private User localUser= null;
//	 private ConnectionController connectionController;
	

	private ConnectionController client;
		
	@FXML
	private void BookSearchClick(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	@FXML	
	 public void LogoutClick(ActionEvent event) {

		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle("Main System Menu");
			stage.setScene(scene);		
			stage.show();
			} 
		catch (IOException e)
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	}
	
	
	@FXML
	private void InventoryManagementClick(ActionEvent event) {
		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		client.setPrevScene(curr);
    	Screens.showNewScreen("/client/InventoryManagementWindow.fxml", null, "InventoryManagement");
    
	}

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
}
