package client;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LibrarianMainMenuController {
	
	private ConnectionController client;
	
	@FXML
	private void BookSearchClick(ActionEvent event) {
		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
	    	client.setPrevScene(curr);
	    	Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void InventoryManagementClick(ActionEvent event) {
		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		client.setPrevScene(curr);
    	Screens.showNewScreen("/client/InventoryManagementWindow.fxml", null, "InventoryManagement");
    
	}

}
