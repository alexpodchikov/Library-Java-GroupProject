package common;

import java.io.Serializable;

public class User implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String userID;
	public String password;
	public String userName;
	public String accountType;
	public String statusMembership;
	public int freeze;
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public User(String UserName, String AccountType, String StatusMembership) {
		
		userName = UserName;
		accountType = AccountType;
		statusMembership = StatusMembership;
		
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}
	
	/**
	 * @return the accountType
	 */
	public String getUserName() {
		return userName;
	}
	@Override
	public String toString() {
		return userName;
	}



}
