package client;

import java.io.IOException;
import java.util.ArrayList;

import common.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class ViewReaderCardController implements ChatIF, FeedbackIF  {
	
	 private ConnectionController client;
	 private String studentGlobalID;

	@FXML
	 private TextField StudentNameTextField;
	 @FXML
	 private TextField StudentIDTextField;
	 @FXML
	 private TextField SubscriberIDTextField;
	 @FXML
	 private TextField StudentEmailTextField;
	 @FXML
	 private TextField StudentPhoneTextField;
	 
	 	 
	 public void setStudentInfo(String studentID) {
			ArrayList<String> SetParameters = new ArrayList<String>();
			studentGlobalID=studentID;
			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
				SetParameters.add(studentID);
				ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_STUDENT_INFO, SetParameters,"student");
				client.handleMessageFromClientUI(messageToSend);
				}
			catch (IOException e) {
				e.printStackTrace();
			}		
			
	}
	 
	 
	 @FXML
	 void SaveClick(ActionEvent event) throws IOException {
		
		 String studentID = StudentIDTextField.getText();
		 String email = StudentEmailTextField.getText();
		 String phone = StudentPhoneTextField.getText();
		 
		 if (studentID.isEmpty() || email.isEmpty() || phone.isEmpty() ) {
	    	Screens.showErrorDialog("Invalid information","Text Field cannot be empty", "Please check info");
	    	return;
	     }
		
		 ArrayList<String> SetParameters = new ArrayList<String>();
		 SetParameters.add(studentID);
		 SetParameters.add(email);
		 SetParameters.add(phone);
		 
		 try {
				client = ConnectionController.getConnectionController();
				client.clientUI = null;
				client.clientF = this;				
			    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SAVE_STUDENT_INFO, SetParameters, null);
			    client.handleMessageFromClientUI(messageToSend);			    
			}
			catch (IOException e) {
				e.printStackTrace();
			}
	 
	}
	 @FXML
	 void ViewBookBorrowHistoryClicked(ActionEvent event) {
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
	        	FXMLLoader loader= new FXMLLoader();	
	        	client = ConnectionController.getConnectionController();
		    	client.setPrevScene(curr);
    			Stage stage = client.getStage();
            	Parent root = loader.load(Main.class.getResource("/client/ReaderBorrowHistoryWindow.fxml").openStream());	        				
            	ReaderBorrowHistoryWindowController controller = loader.getController();
        		controller.setUserBorrowHistory(studentGlobalID);
        		Scene scene = new Scene(root);	
    			stage.setTitle("Borrow History");
    			stage.setScene(scene);
    			stage.show();

			} catch(IOException e) {
	        	e.printStackTrace();
			}
			 
		 
	}
	
	 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Library Main Screen ");	 
	}
		

	@Override
	public void display(Object message) {
		
		if (message == null) 
			System.out.println("> Server returned null");
		else 
			System.out.println("> Server returned: "+message.toString());

		if (message instanceof Student) 
		{
			 Student student = (Student) message;
			 StudentEmailTextField.setText(student.getStudentEmail());
			 StudentPhoneTextField.setText(student.getStudentPhone());
			 SubscriberIDTextField.setText(student.getStudentSubscriberNumber()); 
		     StudentIDTextField.setText(student.getStudentID());
		     StudentNameTextField.setText(student.getStudentName());  
		     
		}
		 		
	}

	@Override
	public void feedback(Object msg)
	{
		Screens.singleFeedback(msg);						
	}

}
