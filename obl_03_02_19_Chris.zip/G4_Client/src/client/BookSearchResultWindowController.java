package client;

import java.io.IOException;
import java.util.ArrayList;
import common.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class BookSearchResultWindowController implements ChatIF, FeedbackIF{ 

    private ConnectionController client;	
	private ObservableList<Book> observableBooks;
	private String globalCatalogNumber;
	
		
	@FXML
	private TextField catalogNumberTextID;
	
	@FXML
	private Label enterWaitingListPromptID;
	
	@FXML
	private Button enterWaitingListTextID;
	
	@FXML
    private TableView<Book> bookTableView;	 
	@FXML
    private TableColumn<Book, String> catalogNumberColID;
    @FXML
    private TableColumn<Book, String> BookNameColID;
    @FXML
    private TableColumn<Book, String> shelfLocationColID;
    @FXML
    private TableColumn<Book, String> inStockColID;
    
	
	public void setBookDetails(ArrayList<Book> bookInfo ) {

		observableBooks = FXCollections.observableArrayList(bookInfo); 
		bookTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		catalogNumberColID.setCellValueFactory(new PropertyValueFactory<Book,String>("catalogNumber"));
		BookNameColID.setCellValueFactory(new PropertyValueFactory<Book,String>("bookName"));
		shelfLocationColID.setCellValueFactory(new PropertyValueFactory<Book,String>("shelfLocation"));
		inStockColID.setCellValueFactory(new PropertyValueFactory<Book,String>("availableCopy"));
		bookTableView.setItems(observableBooks);
		
		 try {
	 			client = ConnectionController.getConnectionController();
	 			if(client.getUserKind() == null)
	 			{
	 				enterWaitingListTextID.setVisible(false);
	 				enterWaitingListPromptID.setVisible(false);
	 			}
	 			else if(!client.getUserKind().toLowerCase().trim().equals("student"))
	 			{
	 				enterWaitingListTextID.setVisible(false);
	 				enterWaitingListPromptID.setVisible(false);
	 			}	 				
	 	}
	 	catch (IOException e) {
	 			e.printStackTrace();
	 	}
		
	}
	
	
	 @FXML
	 void enterWaitingListClick(ActionEvent event) {
		 
		 globalCatalogNumber = catalogNumberTextID.getText();
		 if (globalCatalogNumber.isEmpty()) {
	    		Screens.showErrorDialog("Error","Text field cannot be empty", "Please check info");
	    		return;
		 }

		 ArrayList<String> SetParameters = new ArrayList<String>();
		 SetParameters.add(globalCatalogNumber);
		 
		 try {
	 			client = ConnectionController.getConnectionController();
	 			client.clientUI = this;
	 			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.WAITING_LIST_INFO, SetParameters, "waiting_list_info");
	 		    client.handleMessageFromClientUI(messageToSend);	 		    
	 	}
	 	catch (IOException e) {
	 			e.printStackTrace();
	 	}  
		 
	 		 	 	 
	 }
	 
	 @FXML
	 void viewTableOfContentsClick(ActionEvent event) {
		 
		 	 
	 }
	 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Main System Menu");	 
	 }


	@Override
	public void display(Object message) {
		if (message == null) 
			System.out.println("> Server returned null");
		else 
			System.out.println("> Server returned: "+message.toString());
		
		ArrayList<String> SetParameters = new ArrayList<String>();
		ArrayList<Integer> waitingListInfo = new ArrayList<Integer>();
		waitingListInfo = (ArrayList<Integer> )message; 

		// if waiting list is empty
		// or
		// if(NumberCopies > MAX(PlaceInLine)) 
		// -> enter waiting list
		if((waitingListInfo.get(1) == 0) || (waitingListInfo.get(1) > waitingListInfo.get(0)))
		{
			try {
		 			client = ConnectionController.getConnectionController();
		 			client.clientUI = null;
		 			client.clientF = this;
		 			
		 			SetParameters.add(globalCatalogNumber);
		 			SetParameters.add(client.getUserID());
		 			 
		 			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ENTER_WAITING_LIST, SetParameters, null);
		 		    client.handleMessageFromClientUI(messageToSend);	 		    
		 	}
		 	catch (IOException e) {
		 			e.printStackTrace();
		 	}
			
		}
		
	}


	@Override
	public void feedback(Object message) 
	{		
		Screens.singleFeedback(message);
	}
}	
