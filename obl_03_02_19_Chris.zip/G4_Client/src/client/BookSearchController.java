package client;

import java.io.IOException;
import java.util.ArrayList;
import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class BookSearchController implements ChatIF {
	
	 private ConnectionController client;
	 private Scene curr;
	
	 @FXML
	 private TextField bookTitleTextField=null;
	 @FXML
	 private TextField authorNameTextField=null;
	 @FXML
	 private TextField subjectTextField=null;
	 @FXML
	 private TextField descriptionTextField=null;
	 
	 @FXML
	 private RadioButton RB1ButtonID;
	 @FXML
	 private RadioButton RB2ButtonID;
	 @FXML
	 private RadioButton RB3ButtonID;
	 @FXML
	 private RadioButton RB4ButtonID;
	// @FXML
	 final ToggleGroup group = new ToggleGroup();
		 	
	 
	@FXML	
	    private void RB1Clicked(ActionEvent event) {
		 clearFields();
		 bookTitleTextField.setEditable(true);
		 authorNameTextField.setEditable(false);
		 subjectTextField.setEditable(false);
		 descriptionTextField.setEditable(false);
	 }
	 @FXML	
		 private void RB2Clicked(ActionEvent event) {
		 	clearFields();
			 bookTitleTextField.setEditable(false);
			 authorNameTextField.setEditable(true);
			 subjectTextField.setEditable(false);
			 descriptionTextField.setEditable(false);
		 }
		 @FXML	
		    private void RB3Clicked(ActionEvent event) {
			 clearFields();
			 bookTitleTextField.setEditable(false);
			 authorNameTextField.setEditable(false);
			 subjectTextField.setEditable(true);
			 descriptionTextField.setEditable(false);
		 }
		 @FXML	
		    private void RB4Clicked(ActionEvent event) {
			 clearFields();
			 bookTitleTextField.setEditable(false);
			 authorNameTextField.setEditable(false);
			 subjectTextField.setEditable(false);
			 descriptionTextField.setEditable(true);
		 }	
		 private void clearFields() {
			 bookTitleTextField.clear();
			 authorNameTextField.clear();
			 subjectTextField.clear();
			 descriptionTextField.clear();
			 
		 }
		 
		 @FXML
		 void BackClick(ActionEvent event) {
			 
				try {
					client = ConnectionController.getConnectionController();
					if(client.getUserID() != null)
						Screens.showPrevScreen("User System Menu");
					else
						Screens.showPrevScreen("Main System Menu");
					}
				catch (IOException e) {
					e.printStackTrace();
				}			 	 
		}
		 
	 @FXML	
	    private void SearchClick(ActionEvent event) throws IOException {
		 	curr = (Scene)((Node)event.getSource()).getScene();
			String bookTitle = bookTitleTextField.getText();
	    	String authorName = authorNameTextField.getText();
	    	String subject = subjectTextField.getText();
	    	String description = descriptionTextField.getText();
	    	if (bookTitle.isEmpty() && authorName.isEmpty() && subject.isEmpty() && description.isEmpty()) {
	    		Screens.showErrorDialog("Error","Field cannot be empty", "Please check search info");
	    		return;
	    	}
		
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(bookTitle);
			SetParameters.add(authorName);
			SetParameters.add(subject);
			SetParameters.add(description);
			
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BOOK_INFO, SetParameters, "Book");
		    client.handleMessageFromClientUI(messageToSend); 
		  
		}

		@Override
		public void display(Object msg) {

			 Platform.runLater(new Runnable() {                          
		            @Override
		            public void run() {
		                try{
		        			/**
		        			 * Display error dialog if server returned null.
		        			 */
		                	if (msg == null) {
		                		System.out.println("> Server returned null");
		                		Screens.showErrorDialog("Error","Entry not found", "Server didn't find the entry requested!");
		                		return;
		                	}    
		                	
		                	System.out.println("> Server returned: "+msg.toString());
		                	showStage(msg);
		                }
		                catch(Exception e) {
		                	System.out.println("Invoke later failed..");
		                	e.printStackTrace();
		                }
		            }
		            
		        	/**
		        	 * Get suitable stage for suitable form by object type..
		        	 * @param object
		        	 * @return suitable stage
		        	 * @throws Exception
		        	 */
		        	private void showStage(Object object) throws Exception {

		        	  	FXMLLoader loader= new FXMLLoader();
		        		ArrayList<Book> bookInfo = new ArrayList<Book>();	
		        		bookInfo = (ArrayList)object;
		        		
		        		if(bookInfo.isEmpty())
		        		{
		        			Screens.showSuccessDialog("No matches", "Could not find requested book", "Please check search info");
		        			return;
		        		}
		        		
		        		try {
		        			client = ConnectionController.getConnectionController();
		        			client.setPrevScene(curr);
		        			Stage stage = client.getStage();
		                	Parent root = loader.load(Main.class.getResource("/client/BookSearchResultWindow.fxml").openStream());
		                	BookSearchResultWindowController controller = loader.getController();
			        		controller.setBookDetails(bookInfo);
		                	Scene scene = new Scene(root);	
		        			stage.setTitle("Book Search Result");
		        			stage.setScene(scene);
		        			stage.show(); 
		        		}
		        		catch (IOException e) { 
		        			e.printStackTrace();
		        		}		     
		        		
		        	}
		        });
			} 
}
