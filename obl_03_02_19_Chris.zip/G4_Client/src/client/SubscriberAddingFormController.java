package client;

import java.io.IOException;
import java.util.ArrayList;
import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class SubscriberAddingFormController implements FeedbackIF {
	
	 private ConnectionController client;
	 
	 private int feedbackCounterPos = 0;
	 private int feedbackCounterNeg = 0;
	 private int feedbackExpected;
	 boolean UserFlag = true;
	 int studentNumGlobal = 0;
	
	 @FXML
	 private TextField studentNameTextField;
	 @FXML
	 private TextField studentIDTextField;
	 @FXML
	 private TextField studentEmailAddressTextField;
	 @FXML
	 private TextField studentPhoneNumberTextField;
	 @FXML
	 private TextField SubscriberIDTextField;	 
	 @FXML
	 private TextField studentPasswordTextField;
	 
	 
	 public void setNumOfStudents(int studentNum) {
			
			studentNumGlobal= ++studentNum;			
			SubscriberIDTextField.setText(String.valueOf(studentNum));	
	}
 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Library Main Screen ");	 
	}
	 
	 @FXML	
	 private void SaveClick(ActionEvent event) throws IOException {

			String studentName = studentNameTextField.getText();
	    	String studentID = studentIDTextField.getText();
	    	String studentEmailAddress = studentEmailAddressTextField.getText();
	    	String studentPhoneNumber = studentPhoneNumberTextField.getText();
	    	String studentPassword = studentPasswordTextField.getText();
	    	String subscriberNumber = SubscriberIDTextField.getText();

	    	if (studentName.isEmpty() || studentID.isEmpty() || studentEmailAddress.isEmpty() || studentPhoneNumber.isEmpty() || studentPassword.isEmpty()) {
	    		Screens.showErrorDialog("Error","Text Field cannot be empty", "Please check info");
	    		return;
	    	}
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(studentName);
			SetParameters.add(studentID);
			SetParameters.add(studentEmailAddress);
			SetParameters.add(studentPhoneNumber);
			SetParameters.add(studentPassword);
			SetParameters.add(subscriberNumber);
			
			if(Screens.showConfirmationDialog("Confirmation", "Save details", "Please confirm creating new reader card")) {
			    client = ConnectionController.getConnectionController();
				client.clientUI = null;
				client.clientF = this;
				feedbackExpected = 2;
			    ClientToServerMessage messageToSend1 = new ClientToServerMessage(EQueryOption.ADD_READER_CARD, SetParameters, null);
			    client.handleMessageFromClientUI(messageToSend1);	
			    
			    ArrayList<String> SetParameters2 = new ArrayList<String>();
  			    SetParameters2.add(studentIDTextField.getText()); 
  			    SetParameters2.add(studentNameTextField.getText());
  			    SetParameters2.add(studentPasswordTextField.getText());

  			    ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.ADD_USER, SetParameters2, null);
  			    client.handleMessageFromClientUI(messageToSend2);
		   }
		   	studentNumGlobal++;
		   	studentNameTextField.clear();
		   	studentIDTextField.clear();
		   	studentEmailAddressTextField.clear();
	    	studentPhoneNumberTextField.clear();
	    	studentPasswordTextField.clear();
	    	SubscriberIDTextField.setText(String.valueOf(studentNumGlobal));
	}

	@Override
	public void feedback(Object msg)
	{
		System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
		
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	            	String status;

	            	status = (String)msg;
	    			if(status.equals("Success"))
	    				feedbackCounterPos++;
	    			else 
	    				feedbackCounterNeg++;
	    			
	    			int totalCounter = feedbackCounterPos + feedbackCounterNeg;
	    			
	    			if(totalCounter == feedbackExpected)
	    			{
	    				if(feedbackCounterPos == feedbackExpected)
	    					Screens.showSuccessDialog("Notification", "Successful update", "Database was updated successfully");
	    				else
	    					Screens.showErrorDialog("Error","Faild to update", "Could not update database");
	    				
	    				feedbackCounterPos = 0;
	    				feedbackCounterNeg = 0;
	    			}
	    			
	            }
	            
		 });
				
	}
	
}
