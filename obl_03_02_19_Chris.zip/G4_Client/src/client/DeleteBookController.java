package client;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import common.ClientToServerMessage;
import common.EQueryOption;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

public class DeleteBookController implements FeedbackIF, Initializable {
	
	private ConnectionController client;
	
	private int feedbackCounterPos = 0;
	private int feedbackCounterNeg = 0;
	private int feedbackExpected;
	
	 @FXML
	 private TextField HeadlineTextField, AuthorTextField, ISBNTextField, CatalogNumberTextField,
		               WorkerIDTextField, RemoveDateTextField;
			
	
	public void setBookInfo(ArrayList<String> bookiInfo) {
		
	 	HeadlineTextField.setText(bookiInfo.get(0));
		AuthorTextField.setText(bookiInfo.get(1));
		CatalogNumberTextField.setText(bookiInfo.get(3));
	}
	 
	@FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Inventory Management");
		 
	}	
	
	
	 @FXML	
	 private void DeleteClick(ActionEvent event) throws IOException {
		 
		 String catalogNumber = CatalogNumberTextField.getText();
		 String isbn = ISBNTextField.getText();
		 
	     ArrayList<String> SetParameters = new ArrayList<String>();
	     SetParameters.add(catalogNumber);
		 SetParameters.add(isbn);
		 SetParameters.add(RemoveDateTextField.getText());
		 SetParameters.add(WorkerIDTextField.getText());
		 
	     ArrayList<String> SetParameters1 = new ArrayList<String>();		
		 SetParameters1.add(catalogNumber);
		 SetParameters1.add(isbn);
		 
		 if (isbn.isEmpty()) {
			 if (Screens.showConfirmationDialog("Confirmation", "Delete Books", 
					 "Please confirm deleting all the books \nunder catalog number "+catalogNumber+ " from inventory")){
					try {
			 			client = ConnectionController.getConnectionController();
			 			client.clientUI = null;
			 			client.clientF = this;
			 			feedbackExpected = 2;
			 			
			 			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.RELOCATE_BOOK, SetParameters, null);
			 		    client.handleMessageFromClientUI(messageToSend);
			 		    
			 			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.DELETE_BOOK, SetParameters1, null);
			 		    client.handleMessageFromClientUI(messageToSend2);
			 			}
			 		catch (IOException e) {
			 			e.printStackTrace();
			 		}    
			   }
	    }
		else if (Screens.showConfirmationDialog("Confirmation", "Delete Book Copy",
					"Please confirm deleting the given copy: \ncatalog number "+catalogNumber+ " ISBN "+isbn)){
		  		
				try {
		 			client = ConnectionController.getConnectionController();
		 			client.clientUI = null;
		 			client.clientF = this;	
		 			feedbackExpected = 3;
		 			
		 			ClientToServerMessage messageToSend1 = new ClientToServerMessage(EQueryOption.RELOCATE_BOOK, SetParameters, null);
		 		    client.handleMessageFromClientUI(messageToSend1);
		 		    
		 			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.DELETE_BOOK, SetParameters1, null);
		 		    client.handleMessageFromClientUI(messageToSend2);
		 		    
		 		    SetParameters1.remove(1);
		 		    SetParameters1.add("-1");
		 			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.UPDATE_NUMBERS_OF_BOOKS, SetParameters1, null);
		 		    client.handleMessageFromClientUI(messageToSend);
		 		    
		 		}
		 		catch (IOException e) {
		 			e.printStackTrace();		 		
		 		}       
		   }
	 }
	

	@Override
	public void feedback(Object msg)
	{
		System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
		
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	            	String status;

	            	status = (String)msg;
	    			if(status.equals("Success"))
	    				feedbackCounterPos++;
	    			else 
	    				feedbackCounterNeg++;
	    			
	    			int totalCounter = feedbackCounterPos + feedbackCounterNeg;
	    			
	    			if(totalCounter == feedbackExpected)
	    			{
	    				if(feedbackCounterPos == feedbackExpected)
	    					Screens.showSuccessDialog("Notification", "Successful update", "Database was updated successfully");
	    				else
	    					Screens.showErrorDialog("Error","Faild to update", "Could not update database");
	    				
	    				feedbackCounterPos = 0;
	    				feedbackCounterNeg = 0;
	    			}
	    			
	            }
	            
		 });
				
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	  	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	  	String borrowDate = dateFormat.format(new Date());
		
    	try {
    		
			client = ConnectionController.getConnectionController();
			WorkerIDTextField.setText(client.getUserID());
			RemoveDateTextField.setText(borrowDate);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	
}
