package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class UserProfileController {
	
	 private ConnectionController client;	
		@FXML
		private TextField emailID;
		@FXML
		private TextField phoneID;
	 	 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Subscriber Main Menu");	 
	}
	 
	 @FXML
	 void SaveClick(ActionEvent event) {
String email = emailID.getText();
String phone = phoneID.getText();
System.out.println(email + " " + phone);
		 
	}
	 
	 @FXML
	 void viewHistoryClicked(ActionEvent event) throws Exception  {
			
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
				
				client = ConnectionController.getConnectionController();
		    	client.setPrevScene(curr);
		    	System.out.println("ninjout");
		    	Screens.showNewScreen("/client/ReaderBorrowHistoryWindow.fxml", null, "Borrow History");
				}
			catch (IOException e) {
				e.printStackTrace();
			}
		 
	} 
}
