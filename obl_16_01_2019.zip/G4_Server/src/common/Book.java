package common;

import java.io.Serializable;

public class Book implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String bookID;
	public String catalogNumber;
	public String bookName;
	public String nextReturnDate;
	public boolean availableCopy;
	public String shelfLocation;
	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	public Book( String catalogNumber,String bookName,  String shelfLocation,boolean availableCopy) {		 
		this.catalogNumber = catalogNumber;
		this.bookName = bookName;
		this.shelfLocation = shelfLocation;
		this.availableCopy = availableCopy;
		
		
		
	}
	
	public Book(String bookID) {
		
		this.bookID = bookID;
		
	}
	
	public boolean getAvailableCopy() {
		
		return availableCopy;
		
	}
	
	public String getBookName() {
		
		return bookName;
		
	}
	
	public String getCatalogNumber() {
		
		return catalogNumber;
		
	}
	
	public String getNextReturnDate() {
		
		return nextReturnDate;
		
	}
	public String getShelfLocation() {
		return shelfLocation;
	}

	@Override
	public String toString() {
		return bookName;
	}



}
