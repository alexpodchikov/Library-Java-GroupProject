package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class BookSearchResultWindowController implements Initializable {

	@FXML
    private TableView<Book> bookTableView;
	 
	@FXML
    private TableColumn<Book, String> catalogNumberColID;

    @FXML
    private TableColumn<Book, String> BookNameColID;

    @FXML
    private TableColumn<Book, String> shelfLocationColID;

    @FXML
    private TableColumn<Book, String> inStockColID;
	
    private ConnectionController client;
	private ArrayList<Book> books;
	
	private ObservableList<Book> observableBooks;
	private Object objects;
	//BookSearchController controller  = new BookSearchController();
	
	public void setBookDetails(ArrayList<Book> bookInfo ) {
	/*	if (objects.length == 0 || objects[0] instanceof String) {
			return;
		}*/
		books = bookInfo;
		observableBooks = FXCollections.observableArrayList(books); 
		observableBooks.addAll(books);
		bookTableView.setItems(observableBooks);
		System.out.println("ninja1");
		bookTableView.refresh();
	//	books = controller.getBooks1();
		System.out.println("ninja22" + books);
	}

	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//FXMLLoader loader= new FXMLLoader();
	
		
		bookTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		catalogNumberColID.setCellValueFactory(new PropertyValueFactory<Book,String>("Catalog Number"));
		BookNameColID.setCellValueFactory(new PropertyValueFactory<Book,String>("Book Name"));
		shelfLocationColID.setCellValueFactory(new PropertyValueFactory<Book,String>("Shelf Location"));
		inStockColID.setCellValueFactory(new PropertyValueFactory<Book,String>("In Stock"));
		
	}
}	
