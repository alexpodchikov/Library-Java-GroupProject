package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class BookSearchResultWindowController implements Initializable {

	@FXML
    private TableView<Book> bookTableView;
	 
	@FXML
    private TableColumn<Book, String> catalogNumberColID;

    @FXML
    private TableColumn<Book, String> BookNameColID;

    @FXML
    private TableColumn<Book, String> shelfLocationColID;

    @FXML
    private TableColumn<Book, String> inStockColID;
	
    private ConnectionController client;
	private ArrayList<Book> books;
	
	private ObservableList<Book> observableBooks;
	private Object objects;
	
	public void setBookDetails(ArrayList<Book> bookInfo ) {
		books = bookInfo;
		observableBooks = FXCollections.observableArrayList(books); 
		bookTableView.setItems(observableBooks);
		System.out.println("ninja1");
		bookTableView.refresh();
		System.out.println("ninja43" + books);
	}

	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		bookTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		catalogNumberColID.setCellValueFactory(new PropertyValueFactory<Book,String>("catalogNumber"));
		BookNameColID.setCellValueFactory(new PropertyValueFactory<Book,String>("bookName"));
		shelfLocationColID.setCellValueFactory(new PropertyValueFactory<Book,String>("shelfLocation"));
		inStockColID.setCellValueFactory(new PropertyValueFactory<Book,String>("availableCopy"));
		
	}
}	
