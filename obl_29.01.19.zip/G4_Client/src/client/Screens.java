package client;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.util.*;
import common.*;
import javafx.stage.*;



public class Screens {
	
	private static ConnectionController client;

	public static void showPrevScreen(String stageName) {
		
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle(stageName);
			stage.setScene(scene);		
			stage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void showNewScreen(String fxmlPath, String stylesheetPath, String stageName)
	{
		FXMLLoader loader = new FXMLLoader();
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource(fxmlPath).openStream());
			Scene scene = new Scene(root);	
			if(stylesheetPath != null)
				scene.getStylesheets().add(Main.class.getResource(stylesheetPath).toExternalForm());
			stage.setTitle(stageName);
			stage.setScene(scene);
			stage.show();
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void showErrorDialog(String title, String header, String content) 
	{
		Alert alert = new Alert(AlertType.ERROR);
		alert.getDialogPane();
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.show();
	}
	public static void showSuccessDialog(String title, String header, String content) 
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.getDialogPane();
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.show();
	}

}
