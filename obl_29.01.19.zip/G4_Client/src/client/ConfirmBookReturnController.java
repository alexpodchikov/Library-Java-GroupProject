package client;

import java.io.IOException;
import java.util.ArrayList;

import common.ClientToServerMessage;
import common.EQueryOption;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ConfirmBookReturnController {
	@FXML
	private ConnectionController client;			// user database handler.
	@FXML
	private Label subscriberNameLabel;
	
	public void  setSubscriberdDetails(String borrowerName) throws Exception{
		subscriberNameLabel.setText(borrowerName);
	}	

	@FXML
	void BackClick(ActionEvent event) {
		try {
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			Scene scene = client.getPrevScene();
			stage.setTitle("Confirm Book Return");
			stage.setScene(scene);		
			stage.show();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	/*
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Library Main Screen ");	 
	}
	*/
	/*
	@Override
	public void display(Object message) {
		ArrayList<String> SetParameters = new ArrayList<String>();
	
		  UserFlag = !UserFlag;
		if (message == null) {
			System.out.println("> Server returned null");
		}
		else {
		System.out.println("> Server returned: "+message.toString());

		}		
		
		Platform.runLater(new Runnable() {  
		 
         @Override
         public void run() {
             try{
             	if (message == null) {
             		Screens.showErrorDialog("Error","Entry not found", "Username or password is incorrect!");
             		return;
             	}
            	if (message.toString().contains("Success")) {
    			  if(!UserFlag) {
	        		Screens.showSuccessDialog("Information Dialog", "Success", "The new details were saved successfully");
        			client = ConnectionController.getConnectionController();
    			  SetParameters.add(studentIDTextField.getText()); 
    			  SetParameters.add(studentNameTextField.getText());
    			  SetParameters.add(studentPasswordTextField.getText());
    			  System.out.println(SetParameters + "ninjaaaa555");
    			  ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_USER, SetParameters, null);
    			  client.handleMessageFromClientUI(messageToSend);
    			  } 
    			   
            	}
           	
             }
             catch(Exception e) {
             	System.out.println("Invoke later failed..");
             	e.printStackTrace();
             }
         }
	 });
	}*/
}
