package client;



import ocsf.client.*;
import common.*;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

/**
 * This class overrides some of the methods defined in the abstract
 * superclass in order to give more functionality to the client.
 *
 * @version July 2000
 */
public class ConnectionController extends AbstractClient {
  //Instance variables **********************************************

	public final static int DEFAULT_PORT = 5555;			// default port to connect.
	public final static String DEFAULT_HOST = "localhost";	// default host to connect.
	
	private static int Port = DEFAULT_PORT;
	private static String Host = DEFAULT_HOST;
	private Stage primaryStage;
	private ArrayList<Scene> previousScenes;
	private String userID;
	
	String fxmlPath;

	private static ConnectionController Client = null;
	
  /**
   * The interface type variable.  It allows the implementation of 
   * the display method in the client.
   */
	ChatIF clientUI;
	FeedbackIF clientF;

  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the chat client.
   *
   * @param host The server to connect to.
   * @param port The port number to connect on.
   * @param clientUI The interface type variable.
   */
  
  private ConnectionController(String host, int port)
    throws IOException 
  {
    super(host, port); //Call the superclass constructor
    primaryStage = new Stage();
    previousScenes = new ArrayList<Scene>();
    userID = null;
    openConnection();
  }

 //*******************************************************************
  
  public static ConnectionController getConnectionController() throws IOException
  {
	  if (Client == null)
		  	Client = new ConnectionController(Host, Port);

	  return Client;	 	  
  }
  
  public Stage getStage() 
  {
	return Client.primaryStage;  
  }

  public void setStage(Stage temp) throws IOException
  {
	  Client.primaryStage = temp;  
  }

  
  public Scene getPrevScene() 
  {
	  Scene scene = Client.previousScenes.get(Client.previousScenes.size()-1); 
	  Client.previousScenes.remove(Client.previousScenes.size()-1);
	  return scene;
  }

  public void setPrevScene(Scene temp)
  {
	  Client.previousScenes.add(temp); 
  }
  
	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
  
  
  

  //Instance methods ************************************************
   
  
  
  
  /**
   * This method handles all data that comes in from the server.
   *
   * @param msg The message from the server.
   */
  public void handleMessageFromServer(Object msg) 
  {
	  String statusCheck;
	  String SetStatus = "Failure";
	  Object objectToReturn = (Object)SetStatus;
	  
	  if(msg instanceof String)
	  {
		  statusCheck = (String)msg;
		 
		  if(statusCheck.equals("Success") || statusCheck.equals("Failure"))
			  clientF.feedback(msg);
		  else 
			  clientUI.display(msg);
		  
	  }
	  else 
	  {
		  if(msg == null && clientUI == null)
			  clientF.feedback(objectToReturn);
		  else
			  clientUI.display(msg);
	  }
  }

  /**
   * This method handles all data coming from the UI            
   *
   * @param message The message from the UI.    
   */
  public void handleMessageFromClientUI(Object objectToSend)  
  {
    try
    {
    	sendToServer(objectToSend);
    }
    catch(IOException e)
    {
    	
      clientUI.display("Could not send message to server.  Terminating client.");
      System.out.println(e);
      quit();
    }
  }
  
  /**
   * This method terminates the client.
   */
  public void quit()
  {
    try
    {
      closeConnection();
    }
    catch(IOException e) {}
    System.exit(0);
  }
}
//End of ChatClient class
