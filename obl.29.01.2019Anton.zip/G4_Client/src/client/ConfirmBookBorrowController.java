package client;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.text.*;
import java.time.LocalDate;

import common.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class ConfirmBookBorrowController implements FeedbackIF {	
	
	private ArrayList<String> info;
	private ConnectionController client;			// user database handler.
	private int feedbackCounterPos;
	private int feedbackCounterNeg;
	
	@FXML
	private Label subscriberFullNameLabel;
	@FXML
	private Label borrowDateLabel;
	@FXML
	private Label returnDateLabel;
	@FXML
	private Label borrowPeriodLabel;


	public void  setBorrowedBooklDetais(ArrayList<String> confirmInfo) throws Exception{

		//confirmInfo expected: bookISBN, userID, borrowDate, returnDate, User name, Borrow period.
		info = new ArrayList<String>();
		info = confirmInfo;
		
		borrowDateLabel.setText(info.get(2));
		returnDateLabel.setText(info.get(3));
		subscriberFullNameLabel.setText(info.get(4));		
		borrowPeriodLabel.setText(info.get(5));
		
	}	 

	@FXML
	void OkCLick(ActionEvent event) {
				
		info.remove(5);
		info.remove(4);
		info.add("ok");
		
		try {
			client = ConnectionController.getConnectionController();	
			client.clientF = this;
			client.clientUI = null;
			feedbackCounterPos = 0;
			feedbackCounterNeg = 0;
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_BORROWED_BOOK, info, null);	
			client.handleMessageFromClientUI(messageToSend);

			info.remove(4);			
			info.remove(3);			
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.ADD_BORROWED_BOOK_HISTORY, info, null);	
			client.handleMessageFromClientUI(messageToSend2);
			
			info.remove(2);
			info.remove(1);
			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.SET_BOOK_AVAILABILITY_OFF, info, null);	
			client.handleMessageFromClientUI(messageToSend3);
			
			Screens.showNewScreen(client.fxmlPath, "/client/LibraryMainScreen.css", "User System Menu");
			//Screens.showPrevScreen("User System Menu");
			
			
		}catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	
	@FXML
	void BackClick(ActionEvent event) {
		
		Screens.showPrevScreen("User System Menu");
		
	}	
	
	@Override
	public void feedback(Object msg)
	{
		
		if (msg == null) {
			System.out.println("> Server returned null" + "(Feedback method)");
		}
		else 
		{
			System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
			
			 Platform.runLater(new Runnable() {                          
		            @Override
		            public void run() {
		            	String status;

		            	status = (String)msg;
		    			if(status.equals("Success"))
		    				feedbackCounterPos++;
		    			else 
		    				feedbackCounterNeg++;
		    			
		    			int totalCounter = feedbackCounterPos + feedbackCounterNeg;
		    			
		    			if(totalCounter == 3)
		    			{
		    				if(feedbackCounterPos == 3)
		    					Screens.showSuccessDialog("Notification", "Successful update", "Database was updated successfully");
		    				else
		    					Screens.showErrorDialog("Error","Faild to update", "Could not update database");
		    			}
		    			
		            }
		            
			 });
		}
				
	}
}



