package client;

import java.io.IOException;
import java.util.ArrayList;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class SubscriberMainScreenController  implements ChatIF{
	@FXML
    private TableView<BorrowedBook> studentTableViewID;
	 
	@FXML
    private TableColumn<BorrowedBook, String> ISBNColID;

    @FXML
    private TableColumn<BorrowedBook, String> BorrowerColID;

    @FXML
    private TableColumn<BorrowedBook, String> borrowDateIColD;

    @FXML
    private TableColumn<BorrowedBook, String> returnDateColID;
    
    @FXML
    private TableColumn<BorrowedBook, String> borrowStatusColID;
    
    private ArrayList<BorrowedBook> borrowedBooks;
    private ConnectionController client;
    private ObservableList<BorrowedBook> observableBooks;
	
	@FXML
	private void BookSearchClick(ActionEvent event) { 
		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
	    	client.setPrevScene(curr);
	    	Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		} 
	}
	public void setUserId(String UserID ) {
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(UserID);

		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			}
		catch (IOException e) {
			e.printStackTrace();
		}

	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BORROWED_BOOK_INFO, SetParameters,"borrowedbook");
	    client.handleMessageFromClientUI(messageToSend); 
	}
	

	@Override
	public void display(Object message) {
		if (message == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+message.toString());
		
		borrowedBooks = (ArrayList<BorrowedBook>)message;	
		observableBooks = FXCollections.observableArrayList(borrowedBooks); 
		studentTableViewID.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		ISBNColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("ISBN"));
		BorrowerColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowerID"));	
		borrowDateIColD.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowDate"));
		returnDateColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("returnDate"));
		borrowStatusColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowStatus"));
		studentTableViewID.setItems(observableBooks);		
	}
	
	@FXML
	private void logoutClicked(ActionEvent event) {
		
		Screens.showPrevScreen("Main System Menu");	
	}

	@FXML
	private void ProfileClicked(ActionEvent event) throws Exception {
	
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
        	FXMLLoader loader= new FXMLLoader();
			client = ConnectionController.getConnectionController();
	    	client.setPrevScene(curr);
	    	Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource("/client/UserProfile.fxml").openStream());	        				
	    	UserProfileController controller =  loader.getController();
    		controller.setUserId(client.getUserID());
    		Scene scene = new Scene(root);	
			stage.setTitle("User Profile");
			stage.setScene(scene);
			stage.show();
		
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
