package common;

import java.io.Serializable;

public class Book implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String bookID;
	public String catalogNumber;
	public String bookName;
	public String nextReturnDate;
	public int availableCopy;

	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	public Book(String bookName, int availableCopy, String catalogNumber, String nextReturnDate) {
		this.bookName = bookName;
		this.catalogNumber = catalogNumber;
		this.nextReturnDate = nextReturnDate;
		this.availableCopy = availableCopy;
		
	}
	
	public Book(String bookID) {
		
		this.bookID = bookID;
		
	}


	@Override
	public String toString() {
		return bookName;
	}



}
