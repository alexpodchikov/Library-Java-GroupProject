package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class BookSearchController implements ChatIF {//implements Initializable {
	
	 @FXML
	 private TextField bookTitleTextField=null;
	 @FXML
	 private TextField authorNameTextField=null;
	 @FXML
	 private TextField subjectTextField=null;
	 @FXML
	 private TextField descriptionTextField=null;
	 
	 @FXML
	 private RadioButton RB1ButtonID;
	 @FXML
	 private RadioButton RB2ButtonID;
	 @FXML
	 private RadioButton RB3ButtonID;
	 @FXML
	 private RadioButton RB4ButtonID;
	// @FXML
	 final ToggleGroup group = new ToggleGroup();
	 public final static int DEFAULT_PORT = 5555;			// default port to connect.
	 public final static String DEFAULT_HOST = "localhost";
	 private  MainSystemMenuController host = new MainSystemMenuController();
	 
	 
	 private ConnectionController connectionController;	
	
	 @FXML
	    void BackClick(ActionEvent event) {
			((Node)event.getSource()).getScene().getWindow().hide(); //hiding BookSearch window
			Stage stage = new Stage();
			FXMLLoader loader = new FXMLLoader();
			Pane root;
			try {
				root = loader.load(getClass().getResource("/client/MainSystemMenu.fxml").openStream());		
				Scene scene = new Scene(root);	
				//scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
				stage.setTitle("Main System Menu");
				stage.setScene(scene);		
				stage.show();	
				} 
			catch (IOException e)
				{
				// TODO add to error manager
				e.printStackTrace();
				}
			}
	 @FXML	
	    private void RB1Clicked(ActionEvent event) {
		 	 
		// addRB();
		 bookTitleTextField.setEditable(true);
	 }
	 @FXML	
	    private void RB2Clicked(ActionEvent event) {
		// addRB();
		 authorNameTextField.setEditable(true);
	 }
	 @FXML	
	    private void RB3Clicked(ActionEvent event) {
		// addRB();
		 subjectTextField.setEditable(true);
	 }
	 @FXML	
	    private void RB4Clicked(ActionEvent event) {
		// addRB();
		 descriptionTextField.setEditable(true);
	 }
	// @FXML	
	    private void addRB() {
		 RB1ButtonID.setToggleGroup(group);
		 RB2ButtonID.setToggleGroup(group);
		 RB3ButtonID.setToggleGroup(group);
		 RB4ButtonID.setToggleGroup(group);
	 }
	 @FXML	
	    private void SearchClick(ActionEvent event) throws IOException {
			String bookTitle = bookTitleTextField.getText();
	    	String authorName = authorNameTextField.getText();
	    	String subject = subjectTextField.getText();
	    	String description = descriptionTextField.getText();
	    	if (bookTitle.isEmpty() && authorName.isEmpty() && subject.isEmpty() && description.isEmpty()) {
	    		Screens.showErrorDialog("Invalid search information","Cannot be empty", "Please check search info");
	    		return;
	    	}
		
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(bookTitle);
			SetParameters.add(authorName);
			SetParameters.add(subject);
			SetParameters.add(description);
			connectionController = new ConnectionController(host.getHost(),5555,this);
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BOOK_INFO, SetParameters, "Book");
		    connectionController.handleMessageFromClientUI(messageToSend); 
		  
		}

	/*@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		addRB();
	}*/
	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
	 
}
