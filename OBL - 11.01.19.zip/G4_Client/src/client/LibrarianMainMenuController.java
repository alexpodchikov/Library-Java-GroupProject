package client;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LibrarianMainMenuController {
	
	@FXML
	private void BookSearchClick(ActionEvent event) {
	/*	if (connectionController == null || !connectionController.isConnected()) { 
    		ConnectionStatus.setText("Disconnected");             
			ConnectionStatus.setTextFill(Color.RED);
    		return;
    	}
    	*/
	    ((Node)event.getSource()).getScene().getWindow().hide(); //hiding LibrarianMainMenu window
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/BookSearch.fxml").openStream());
			Scene scene = new Scene(root);			
			stage.setTitle("Book Search");
			stage.setScene(scene);		
			stage.show();
			} 
		catch (IOException e) 
			{
			// TODO add to error manager
			e.printStackTrace();
			}
	};

}
