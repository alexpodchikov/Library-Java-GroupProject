package server;

	import java.util.HashMap;
	import java.util.List;

	import common.EQueryOption;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

	/**
	 * Class: Query
	 * Store all server queries related to our database.
	 *
	 */
	public class Query {

		/// Product related names as in the Database
		//Database user
		private final static String USER_TABLE = "obl.user";
		private final static String USER_ID	="UserID";
		private final static String USER_NAME = "UserName";
		private final static String PASSWORD = "Password";
		private final static String ACCOUNT_TYPE = "AccountType";
		private final static String STATUS_MEMBERSHIP = "StatusMembership";
		
		//Database student
		private final static String STUDENT_TABLE = "obl.student";
		private final static String STUDENT_ID = "StudentID";
		private final static String STUDENT_NAME = "StudentName";
		private final static String STUDENT_PASSWORD = "StudentPassword";
		private final static String STUDENT_PHONE_NUMBER = "PhoneNumber";
		private final static String STUDENT_EMAIL = "Email";
		private final static String STUDENT_STATUS_MEMBERSHIP = "StatusMembership";
		private final static String OPERATION = "Operation";
		private final static String FREEZE = "FreezeCounter";
		private final static String SUBSCRIBER_NUMBER = "StudentSubscriberNumber";

		
		//Database book
		private final static String BOOK_TABLE = "obl.book";
		private final static String BOOK_ID = "ISBN";
		private final static String BOOK_TITLE = "Headline";
		private final static String CATALOG_NUMBER = "CatalogNumber";
		private final static String NEXT_RETURN_DATE = "NextReturnDate";
		private final static String AVAILABLE_COPY = "Available";
		private final static String BOOK_AUTHOR = "Author";
		private final static String BOOK_SUBJECT = "Subject";
		private final static String BOOK_DESCRIPTION = "Description";
		private final static String BOOK_LOCATION = "ShelfLocation";
		private final static String BOOK_BORROW_PERIOD = "BorrowPeriod";
		private final static String BOOK_PURCHASE_DATE = "PurchaseDate";
		private final static String BOOK_PRINT_DATE = "PrintDate";
		private final static String BOOK_EDITION_NUMBER = "EditionNumber";
		private final static String BOOK_NUMBER_COPIES = "NumberCopies";
		private final static String BOOK_BORROW_COUNTER = "BorrowCounter";
		private final static String BOOK_BORROW_DURATION = "BorrowDuration";
		private final static String BOOK_RETURN_DELAY = "ReturnDelay";
		///
		
		//Database Borrowedbook
				private final static String BORROWED_BOOK_TABLE = "obl.borrowedbook";
				private final static String BORROWED_BOOK_ISBN = "ISBN";
				private final static String BORROWED_BOOK_BORROWER_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_DATE = "borrowDate";
				private final static String BORROWED_BOOK_RETURN_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_STATUS = "borrowStatus";
		
				
				
		//Database BorrowedBookHistory
				private final static String BORROWED_BOOK_HISTORY_TABLE = "obl.borrowed_book_history";
				private final static String BORROWED_BOOK_HISTORY_ISBN = "ISBN";
				private final static String BORROWED_BOOK_USER_HISTORY_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_HISTORY_DATE = "borrowDate";
				private final static String BORROWED_BOOK_RETURN_HISTORY_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_HISTORY_STATUS = "borrowStatus";
				
				
		/**
		 * HashMap contains EQueryOption as key
		 * and number of parameters required as value.
		 */
		private static HashMap<EQueryOption, Integer> enumParamNum = startMap();
		
		/**
		 * Static initialization of enumParameterNumber
		 * @return initialized HashMap
		 */
		private static HashMap<EQueryOption, Integer> startMap()
	    {
			HashMap<EQueryOption, Integer> map = new HashMap<EQueryOption,Integer>();
			map.put(EQueryOption.LOGIN_REQUEST, 2); //Parameters: UserName, Password.
	        map.put(EQueryOption.GET_STUDENT_INFO, 1);		// Parameters: ID.
	        map.put(EQueryOption.SAVE_STUDENT_INFO, 3);      //userid , email,phone;
	        map.put(EQueryOption.UPDATE_STATUS_MEMBERSHIP, 2);	// Parameters:ID, StatusMembership.
	        map.put(EQueryOption.GET_BORROWED_BOOK_INFO, 1); // Parameters:,userId.
	        map.put(EQueryOption.GET_BOOK_INFO, 4); // Parameters: BookTitle, BookAuthor, BookSubject, BookDescription;
	        map.put(EQueryOption.ADD_READER_CARD, 6);// Parameters: StudentID, StudentName, StudentPassword, PhoneNumber, Email;
	        map.put(EQueryOption.GET_STUDENT_NAME, 1); // Parameters: StudentName.
	        map.put(EQueryOption.ADD_BORROWED_BOOK, 5);// Parameters: bookID, userID, borrowDate, returnDate, borrowStatus, prolongationRequest;
	        map.put(EQueryOption.DELETE_BORROWED_BOOK, 1);// Parameters: ISBN;	 
	        map.put(EQueryOption.SET_BOOK_AVAILABILITY_ON, 3);// Parameters: bookID, userID, borrowDate, returnDate;
	        map.put(EQueryOption.GET_BOOK_BORROW_HISTORY,1);// Parameters: userID;
	        map.put(EQueryOption.RETURN_BORROWED_BOOK, 3);// Parameters: ISBN, returnDate, retutnStatus;			      
	        map.put(EQueryOption.GET_BOOK_BORROW_HISTORY,1);// Parameters: userID;
	        map.put(EQueryOption.GET_BORROW_INFO, 2);// Parameters: borrower_id,ISBN;
	        map.put(EQueryOption.INCREASE_BORROW_DURATION, 0);
	        map.put(EQueryOption.INCREASE_RETURN_DELAY, 0);
	        map.put(EQueryOption.ADD_USER,3);
	        map.put(EQueryOption.NUM_OF_STUDENTS,1);
	        
	        map.put(EQueryOption.UPDATE_SUBSCRIBER_AND_BOOK_DELAY_STATUS, 1);// Parameters: today;
	        return map;
	    }
		
		
		/**
		 * Get suitable query
		 * Parameters order must be as table columns
		 * @param queryOption 
		 * @return Query string
		 */
		public static String getQuery(EQueryOption queryOption, List<String> Parameters) throws Exception{
			//System.out.println(Parameters);
			//System.out.println("size: "+Parameters.size());
			if (Parameters.size() != enumParamNum.get(queryOption)) {
				//System.out.println("got you!!");
				return "";
				// TODO: add invalid parameters number error or Exception 
			}
			
			switch(queryOption) {
			case LOGIN_REQUEST:
				return LoginRequest(Parameters.get(0),Parameters.get(1));	
			case GET_STUDENT_INFO:
				return getStudentInfo(Parameters.get(0));
			case SAVE_STUDENT_INFO:
				return saveStudentInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2));
			case GET_BORROWED_BOOK_INFO:
				return getBorrowedBookInfo(Parameters.get(0));
			case GET_BOOK_BORROW_HISTORY:
				return getBookBorrowHistory(Parameters.get(0));	
			//case UPDATE_STATUS_MEMBERSHIP:GET_BOOK_BORROW_HISTORY
				//return updateStudentInfo(Parameters.get(0),Parameters.get(1));
			case NUM_OF_STUDENTS:

				return numOfStudents(Parameters.get(0));
			case GET_BOOK_INFO:
				//if(enumParamNum.get(queryOption)== 4) 
				return getBookInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3));
				//else 
					//return getBookInfo(Parameters.get(0));	
			case ADD_USER:
				return addUser(Parameters.get(0),Parameters.get(1),Parameters.get(2));	
			case ADD_READER_CARD:
				return addReaderCard(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),Parameters.get(5));
				
			case GET_STUDENT_NAME:
				return getStudentName(Parameters.get(0));
				
			case ADD_BORROWED_BOOK:
				return addBorrowedBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4));
			case DELETE_BORROWED_BOOK:
				return deleteBorrowedBook(Parameters.get(0));
				
			case RETURN_BORROWED_BOOK:
				return setReturnedBookInfo(Parameters.get(0),Parameters.get(1));
				
			case GET_BORROW_INFO:
				return getBorrowInfo(Parameters.get(0),Parameters.get(1));
			
			case SET_BOOK_AVAILABILITY_OFF:
				return setBookAvailabilityZERO(Parameters.get(0),Parameters.get(1),Parameters.get(2));
				
			case SET_BOOK_AVAILABILITY_ON:
				return setBookAvailabilityON(Parameters.get(0),Parameters.get(1),Parameters.get(2));	
				
			case INCREASE_BORROW_DURATION:
				return increaseBorrowDuration();
				
			case INCREASE_RETURN_DELAY:
				return increaseReturnDelay();
				
			case UPDATE_SUBSCRIBER_AND_BOOK_DELAY_STATUS:
				return updateSubscriberAndBookDelayStatus(Parameters.get(0));
				
			default:
					return "";	// TODO: add error or exception (invalid enum option).
			}
		}



		private static String getBookBorrowHistory(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn =  "SELECT " + BORROWED_BOOK_HISTORY_ISBN + ","+ BORROWED_BOOK_USER_HISTORY_ID +","+ BORROWED_BOOK_BORROW_HISTORY_DATE + " , " + BORROWED_BOOK_RETURN_HISTORY_DATE + " , " + BORROWED_BOOK_BORROW_HISTORY_STATUS + " FROM " + BORROWED_BOOK_HISTORY_TABLE + " WHERE " +
					BORROWED_BOOK_USER_HISTORY_ID + " = " + ID+";";
			return queryToReturn;
		}


		private static String saveStudentInfo(String ID, String email, String phone) {
			ID = "\'"+ ID+ "\'";
			email = "\'"+ email+ "\'";
			phone = "\'"+ phone+ "\'";
			String queryToReturn = "UPDATE " + STUDENT_TABLE + " SET " + STUDENT_EMAIL + " = " + email +" , " + STUDENT_PHONE_NUMBER + "=" + phone + " WHERE " + STUDENT_ID + " = " + ID +  " ;";
			return queryToReturn;
			
		}

		/**
		 * Get query string for getting full product info from product table
		 * by productID.
		 * @param productID
		 * @return Product Info query string.
		 */
	/*	private static String getBookInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " + BOOK_ID + ","+ BOOK_TITLE  + " FROM " + BOOK_TABLE + " WHERE " +
					BOOK_ID + " = " + ID+";";
			return queryToReturn;
		}
		*/
		/**
		 * Get query string for getting full product info from student table
		 * by studentID.
		 * @param studentID
		 * @return Student Info query string.
		 */
		
		private static String getStudentInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " +  STUDENT_NAME+ ","+ STUDENT_ID +","+ SUBSCRIBER_NUMBER + " , " + STUDENT_EMAIL + " , " + STUDENT_PHONE_NUMBER + " , " + STUDENT_PASSWORD + " FROM " + STUDENT_TABLE + " WHERE " +
					STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}
		
		//SELECT StudentName,StudentID,StudentSubscriberNumber,Email,PhoneNumber FROM obl.student WHERE StudentID = 325;
		


		/** 
		 * Get query string for updating product info.
		 * @param productID new ProductID string
		 * @param productName new Product Name
		 * @param productType new Product Type
		 * @return product info update query string.
		 */
		
		
		//SELECT AccountType,UserName,StatusMebership FROM obl.user WHERE UserID = 325;
		private static String LoginRequest (String UserID, String UserPassword) {
			UserID = "\'"+ UserID+ "\'";
			UserPassword = "\'"+ UserPassword+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + ","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP + "," + USER_ID +  " FROM " + USER_TABLE + " WHERE " +
					USER_ID + " = " + UserID + " AND "+ PASSWORD + " = " + UserPassword+ " ;";	
		
			return queryToReturn;
		}
		
		private static String getBookInfo(String bookTitle, String bookAuthor,String bookSubject, String bookDescription) {
			bookTitle = "\'"+ bookTitle+ "\'";
			bookAuthor = "\'"+ bookAuthor+ "\'";
			bookSubject = "\'"+ bookSubject+ "\'";
			String	bookDescription2 = bookDescription;
			bookDescription = "\'"+ bookDescription+ "\'";

			String queryToReturn = "SELECT " + CATALOG_NUMBER + ","+ BOOK_TITLE +","+ BOOK_LOCATION + "," + AVAILABLE_COPY +
					" FROM " + BOOK_TABLE + " WHERE " + BOOK_TITLE + "=" + bookTitle +" OR "+
					BOOK_AUTHOR + " = " + bookAuthor + " OR " + BOOK_SUBJECT  + " = " + bookSubject + " OR (" + BOOK_DESCRIPTION +" LIKE "+ "'%"+ bookDescription2+"%' "+ "AND "+bookDescription + " != "+ "''"+");";
			return queryToReturn;		
		}
		
		
		private static String getBorrowedBookInfo(String borrowerID) {
			borrowerID = "\'"+ borrowerID+ "\'";
			//bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "SELECT " + BORROWED_BOOK_ISBN  + ","+ BORROWED_BOOK_BORROWER_ID +","+ BORROWED_BOOK_BORROW_DATE + "," + BORROWED_BOOK_RETURN_DATE +
					"," + BORROWED_BOOK_BORROW_STATUS + " FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_BORROWER_ID + "=" + borrowerID + " ;";				
			return queryToReturn;
		}

		/* 
		 * add new borrowed book
		 */
		private static String addBorrowedBook(String bookID, String userID, String borrowDate, String returnDate, String borrowStatus) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			borrowStatus = "\'"+ borrowStatus+ "\'";
			String queryToReturn = "INSERT INTO " + BORROWED_BOOK_TABLE + "(" + BORROWED_BOOK_ISBN +","+ BORROWED_BOOK_BORROWER_ID +","+ BORROWED_BOOK_BORROW_DATE +","+ BORROWED_BOOK_RETURN_DATE +","+ BORROWED_BOOK_BORROW_STATUS + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +","+ returnDate +","+ borrowStatus + ")" + ";";
			return queryToReturn;
		}
		
		/*
		 * when the book is returned delete book from "borrowed book" table
		 * 
		 * DELETE FROM obl.borrowedbook WHERE ISBN='0002';
		 */
		private static String deleteBorrowedBook(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "DELETE FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_ISBN +"=" + bookID + ";";
			return queryToReturn;
		}
		
		/*
		 * set availability status of a book to not available
		 * */ 
		private static String setBookAvailabilityZERO(String bookName, String bookID, String bookCatalogNumber) {
			bookName = "\'"+ bookName+ "\'";
			bookID = "\'"+ bookID+ "\'";
			bookCatalogNumber = "\'"+ bookCatalogNumber+ "\'";
			String queryToReturn = "UPDATE" + BOOK_TABLE + "SET" + AVAILABLE_COPY + " = " + 0 + " WHERE " + BOOK_TITLE + " = " + bookName + " AND " + BOOK_ID + " = " + bookID + " AND " + CATALOG_NUMBER + " = " + bookCatalogNumber + " ;";
			return queryToReturn;
		}
		
		/*
		 * set availability status of a book to available
		 * */ 
		private static String setBookAvailabilityON(String bookName, String bookID, String bookCatalogNumber) {
			bookName = "\'"+ bookName+ "\'";
			bookID = "\'"+ bookID+ "\'";
			bookCatalogNumber = "\'"+ bookCatalogNumber+ "\'";
			String queryToReturn = "UPDATE" + BOOK_TABLE + "SET" + AVAILABLE_COPY + " = " + 1 + " WHERE " + BOOK_TITLE + " = " + bookName + " AND " + BOOK_ID + " = " + bookID + " AND " + CATALOG_NUMBER + " = " + bookCatalogNumber + " ;";
			return queryToReturn;
		}
		
		/* 
		 * when borrowing book get subscriber's name for confirm book borrow window
		 * */
		private static String getStudentName(String studentID) {
			studentID = "\'"+ studentID+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + " FROM " + USER_TABLE + " WHERE " + USER_ID + " = " +  studentID + " AND " + STATUS_MEMBERSHIP + " = " + "'Active'" + " ;";
			return queryToReturn;		
		}
		
		
		/* 
		 * when borrowing book get subscriber's name and borrow duration for book borrow window
		 * 
		 * SELECT UserName ,BorrowPeriod 
		 * FROM obl.user , obl.book  
		 * WHERE obl.user.UserID = '325' AND obl.book.ISBN = '12345';
		 * */
		private static String getBorrowInfo(String studentID,String isbn) {
			studentID = "\'"+ studentID+ "\'";
			isbn = "\'"+ isbn+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + " , " + BOOK_BORROW_PERIOD + " FROM " + USER_TABLE + " , " + BOOK_TABLE + " WHERE " + USER_TABLE + "." +
					USER_ID + " = " +  studentID + " AND " + BOOK_TABLE + "." + BOOK_ID + " = " + isbn + " ;";
			return queryToReturn;		
		}
		
		
		/*	
		 *  when book return clicked update "book" data base ( copy is available ) and "borrowed book history" data base ( the date of the return and the status of the return was it on time or late )
		 * 
		 *	UPDATE obl.borrowed_book_history,obl.book 
		 *  	SET obl.borrowed_book_history.returnDate='02.02.2019' , obl.borrowed_book_history.returnStatus = ( 
		 *   		SELECT borrowStatus 
		 *  			FROM obl.borrowedbook 
		 *  				WHERE obl.borrowedbook.ISBN = obl.borrowed_book_history.ISBN  ) ,
		 *	    obl.book.Available='1' 
		 *			WHERE obl.book.ISBN = obl.borrowed_book_history.ISBN AND 
		 *				obl.book.ISBN = '0003' AND obl.borrowed_book_history.returnDate IS NULL;
		 * */
		private static String setReturnedBookInfo(String bookID, String returnDate) {
			bookID = "\'"+ bookID+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			String one = "\'"+ 1+ "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_HISTORY_TABLE +","+ BOOK_TABLE + 
					" SET " + BORROWED_BOOK_HISTORY_TABLE +"."+ BORROWED_BOOK_RETURN_HISTORY_DATE +"="+ returnDate + "," + BORROWED_BOOK_HISTORY_TABLE + "," + BORROWED_BOOK_BORROW_HISTORY_STATUS + "=" + "(" +
						" SELECT " + BORROWED_BOOK_BORROW_STATUS +
							" FROM " + BORROWED_BOOK_TABLE +
								" WHERE " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + "=" +BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + ")" + "," +
					BOOK_TABLE + "." + AVAILABLE_COPY + "=" + one +	
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " AND " 
							+ BOOK_TABLE + "." + BOOK_ID + "=" + bookID + " AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL " + ";";
			return queryToReturn;
		}
		
		private static String addReaderCard(String studentName, String studentID, String email, String phoneNumber, String studentPassword, String numOfStudents  ) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			phoneNumber = "\'"+ phoneNumber+ "\'";
			email = "\'"+ email+ "\'";
			numOfStudents = "\'"+ numOfStudents+ "\'";
			String queryToReturn = "INSERT INTO " + STUDENT_TABLE + "(" + STUDENT_ID +","+ STUDENT_NAME +","+ STUDENT_PASSWORD +","+ STUDENT_PHONE_NUMBER +","+ STUDENT_EMAIL + "," + STUDENT_STATUS_MEMBERSHIP + "," + FREEZE +","+  SUBSCRIBER_NUMBER +")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ phoneNumber +","+ email + "," + "\'" + "Active"+ "\'" + "," + 0 +", "+ numOfStudents  +");";
			return queryToReturn;
		}
		
		
		private static String addUser(String studentID, String studentName, String studentPassword) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			String queryToReturn = "INSERT INTO " + USER_TABLE + "(" + USER_ID +","+ USER_NAME +","+ PASSWORD +","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP +","+ FREEZE + ")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ "\'" + "Student"+ "\'" + "," + "\'" + "Active"+ "\'"+ "," + 0 + ")"+";";
			return queryToReturn;
		}
		
		
		
		
		
		/*
		 * daily update of borrowed books borrow duration
		 * 
		 * 	UPDATE obl.book,obl.borrowedbook 
		 * 		SET obl.book.BorrowDuration = (BorrowDuration + 1) 
		 *			WHERE obl.book.ISBN = obl.borrowedbook.ISBN;
		 */
		private static String increaseBorrowDuration() {
			String queryToReturn = "UPDATE " + BOOK_TABLE +","+ BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE +"."+ BOOK_BORROW_DURATION + "=" + "(" + BOOK_BORROW_DURATION + "+" + 1 + ")" +
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + ";";
			return queryToReturn;
		}
		
		
		/*
		 * daily update of not returned return delay
		 * 
		 *	UPDATE obl.book,obl.borrowedbook 
		 *		SET obl.book.ReturnDelay = (ReturnDelay + 1) 
		 *			WHERE obl.book.ISBN = obl.borrowedbook.ISBN 
		 *				AND obl.borrowedbook.borrowStatus='late';
		 */
		private static String increaseReturnDelay() {
			String queryToReturn = "UPDATE " + BOOK_TABLE +","+ BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE +"."+ BOOK_RETURN_DELAY + "=" + "(" + BOOK_RETURN_DELAY + "+" + 1 + ")" +
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
						" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "=" + "'late'" + ";";
			return queryToReturn;
		}
		
		/*
		 * update borrowStatus and subscriber status when book return delay
		 * 
		 *	UPDATE obl.borrowedbook ,obl.user
		 *		SET borrowStatus='late' ,obl.user.StatusMembership='Frozen'
		 *			WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < 
		 *				STR_TO_DATE('25.01.2019', "%d.%m.%Y") AND obl.user.UserID = obl.borrowedbook.borrowerID;
		 */
		private static String updateSubscriberAndBookDelayStatus(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_TABLE +","+ USER_TABLE + 
					" SET " + BORROWED_BOOK_BORROW_STATUS +"="+ "'late'" + "," + USER_TABLE + "." + STATUS_MEMBERSHIP + "=" + "'Frozen'"
						+" WHERE " + " STR_TO_DATE " + "(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "," + format + ")" + "<" + 
							" STR_TO_DATE " + "(" + today + "," + format + ")" + " AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + ";";					
			return queryToReturn;
		}
		private static String numOfStudents( String Mock ) {
			
			String queryToReturn = "SELECT " + " COUNT(*) FROM " + STUDENT_TABLE + ";" ; 
			return queryToReturn;
		}
		//SELECT COUNT(*) FROM obl.student;
}
