package client;

public interface FeedbackIF {
	
	public abstract void feedback(Object message);
	
}
