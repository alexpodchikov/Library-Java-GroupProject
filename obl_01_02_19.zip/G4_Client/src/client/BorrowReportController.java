package client;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class BorrowReportController {
	
	@FXML
	private TextField borrowingUserIDTextField;
	@FXML
	private TextField borrowedBookIDTextField;
	@FXML
	private TextField returnedBookIDTextField;
	@FXML
	private TextField userIDtoViewTextField;

}
