package common;

/**
 * Have to update initMap() and getQuery() in QueryFactory
 * when updating EQueryOption and vice versa.
 *
 */
public enum EQueryOption {

	GET_STUDENT_INFO,
	UPDATE_STATUS_MEMBERSHIP, 
	LOGIN_REQUEST,
	GET_BOOK_INFO
}
