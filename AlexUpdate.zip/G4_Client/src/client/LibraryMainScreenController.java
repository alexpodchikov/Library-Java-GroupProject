package client;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LibraryMainScreenController implements ChatIF, FeedbackIF {

	private String userID;
	private String bookISBN;
	private int feedbackCounterPos=0;
	private int feedbackCounterNeg=0;
	
	private ConnectionController client;
	
	@FXML
	private TextField borrowingUserIDTextField;
	@FXML
	private TextField borrowedBookIDTextField;
	@FXML
	private TextField returnedBookIDTextField;
	@FXML
	private TextField userIDtoViewTextField;
	@FXML
	private TextField prolongingUserIDTextField;
	@FXML
	private TextField prolongationTextFieldID;
	@FXML
	private TextField 	userNameTextFieldID;
	
	@FXML
	private void borrowerIdClick() {
    	returnedBookIDTextField.clear(); 
    	userIDtoViewTextField.clear();
    }
	
	@FXML
	private void borrowedBookISBNClick() {
    	returnedBookIDTextField.clear();
    	userIDtoViewTextField.clear();
    }
	
	@FXML
	private void returnedBookISBNClick() {
    	borrowingUserIDTextField.clear();
    	borrowedBookIDTextField.clear();
    	userIDtoViewTextField.clear();
    }
    
	@FXML
	private void subscriberIdTextFieldClick() {
    	borrowingUserIDTextField.clear();
    	borrowedBookIDTextField.clear();
    	returnedBookIDTextField.clear();
    }
		/**
		 * change screen to book search menu
		 * @param event book search button clicked
		 */
	@FXML
	private void BookSearchClick(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene(); 
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * change the screen to problematic students
	 * @param event problematic students button clicked
	 */
	@FXML
	void ProblematicClicked(ActionEvent event) {		  
		Scene curr = (Scene)((Node)event.getSource()).getScene();  
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/ProblematicSubscriberTableWindow.fxml", null, "Problematic Students ");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	 
	}
	
	/**
	 * change the screen to card creation menu
	 * @param event create card clicked
	 */
	@FXML
	private void CreateReaderCardClick(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();

		    client.setPrevScene(curr);
		//    Screens.showNewScreen("/client/SubscriberAddingForm.fxml", null, "Subscriber Adding Form");
		    ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add("vasya");
			client.clientUI = this;
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.NUM_OF_STUDENTS, SetParameters, "NUM_OF_STUDENTS");
		    client.handleMessageFromClientUI(messageToSend);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * change the screen to view reader card menu
	 * @param event view reder card clicked
	 */
	@FXML
	private void viewReaderCardClick(ActionEvent event) {
		
	    String subscriberID = userIDtoViewTextField.getText();
	    if(subscriberID.isEmpty()) {
	    	Screens.showErrorDialog("Error","Cannot be empty for reader card view", "Please check your info!");
	    	return;}
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
			FXMLLoader loader= new FXMLLoader();
			Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource("/client/ReaderCard.fxml").openStream());
        	ViewReaderCardController controller = loader.getController();
        	controller.setStudentInfo(subscriberID);
        	Scene scene = new Scene(root);
        	client.setPrevScene(curr);
			stage.setTitle("Subscriber View Form");
			stage.setScene(scene);
			stage.show(); 
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 *  change the screen to inventory screen
	 * @param event inventory Clicked
	 */
	@FXML
	private void inventoryClicked(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/InventoryManagementWindow.fxml", "/client/Inventory.css", "Inventory Management");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * send the query to get the required borrow info
	 * @param event borrow button clicked
	 * @throws Exception something goes wrong
	 */
	@FXML
	private void borrowClick(ActionEvent event) throws Exception{
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		userID = borrowingUserIDTextField.getText();
    	bookISBN = borrowedBookIDTextField.getText();
    	if (userID.isEmpty() || bookISBN.isEmpty()) {
    		Screens.showErrorDialog("Error","Cannot be empty for book borrow", "Please check your info!");
    		return;
    	}

		ArrayList<String> SetParameters2 = new ArrayList<String>();
		SetParameters2.add(userID);
		SetParameters2.add(bookISBN);
		
		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			client.setPrevScene(curr);	
		    ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.GET_BORROW_INFO, SetParameters2, "borrow_info");			    
			client.handleMessageFromClientUI(messageToSend2);
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}
/**
 *  send the queries for inventory options
 * @param event book return button clicked
 * @throws Exception something goes wrong 
 */
	@FXML
	private void bookReturnClick(ActionEvent event) throws Exception{
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		ArrayList<String> SetParameters = new ArrayList<String>();	
		String returnedBookISBN = returnedBookIDTextField.getText();
    	if (returnedBookISBN.isEmpty() ) {
    		Screens.showErrorDialog("Error","Field cannot be empty", "Please enter book ISBN to return a book!");
    		return;
    	}
   				
   		SetParameters.add(returnedBookISBN);
		try {
			client = ConnectionController.getConnectionController();
			client.setPrevScene(curr);
			client.clientUI = null;
			client.clientF = this;
			
			//UPDATE borrow history return date & user status (if no longer has late returns) 
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.UPDATE_RETURN_DATE_USER_STATUS, SetParameters, null);				    
			client.handleMessageFromClientUI(messageToSend);
			
			//DELETE from borrowed book table
		    ClientToServerMessage messageToSend1 = new ClientToServerMessage(EQueryOption.DELETE_BORROWED_BOOK, SetParameters, null);				    
			client.handleMessageFromClientUI(messageToSend1);
			
			//SET book copy available
		    ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.SET_BOOK_AVAILABILITY_ON, SetParameters, null);				    
			client.handleMessageFromClientUI(messageToSend2); 
			
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * change the screen to report options
	 * @param event reports button clicked
	 */
	@FXML
	void ReportsClick(ActionEvent event) {
		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/ReportWindow.fxml", null, "Report Window");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@FXML
	private void ManualProlongationClick(ActionEvent event) throws IOException {
		Scene curr = (Scene)((Node)event.getSource()).getScene();		 
		client = ConnectionController.getConnectionController();
		client.setPrevScene(curr);
		String proUserId = prolongingUserIDTextField.getText();
    	if (proUserId.isEmpty() ) {
    		Screens.showErrorDialog("Error","Field cannot be empty", "Please enter student`s id!");
    		return;
    		
    	}
		
    	FXMLLoader loader= new FXMLLoader();	        			 
		Stage stage = client.getStage();
		Parent root = loader.load(Main.class.getResource("/client/BorrowedBookPerID.fxml").openStream());		        			
		BorrowedBookPerIDController controller = loader.getController();
		controller.setUserBooksInfo(proUserId);
		Scene scene = new Scene(root);	
		scene.getStylesheets().add(Main.class.getResource("/client/Subscriber.css").toExternalForm());			        		
		stage.setTitle("Borrowed books of student " + proUserId);
		stage.setScene(scene);
		stage.show();
		
		
		
		
	}
	
	
	/**
	 *  log out from the menu
	 * @param event logout button clicked
	 * @throws IOException 
	 */
	@FXML
	private void logoutClicked(ActionEvent event) throws IOException {
		
		client = ConnectionController.getConnectionController();
    	//client.clientUI = null;
    	client.clientF = this;
		ArrayList<String> SetParameters2 = new ArrayList<String>();
		SetParameters2.add(client.getUserID());
		SetParameters2.add("0");
		Screens.showPrevScreen("Main System Menu");	 

		  ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.CHANGE_IS_CONNECTED, SetParameters2,null);
		  client.handleMessageFromClientUI(messageToSend);	
	}
	
	/**
	 * receive the result from server  and set the date
	 */
	@Override
	public void display(Object msg) {
		if (msg == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+msg.toString());
		/**
		 * Display error dialog is server returned null.
		 * TODO: make stage factory.
		 */
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	                try{
	                	if (msg == null) {
	                		Screens.showErrorDialog("Error","Entry not found", "Server didn't find the entry requested!");
	                		return;
	                	}   
	                	if (msg instanceof String) {
	                		try {
	                			//    Screens.showNewScreen("/client/SubscriberAddingForm.fxml", null, "Subscriber Adding Form");

	    	        			client = ConnectionController.getConnectionController();
	    	        			FXMLLoader loader= new FXMLLoader();	    	        			
	    	        			Stage stage = client.getStage();
	    	                	Parent root = loader.load(Main.class.getResource("/client/SubscriberAddingForm.fxml").openStream());
	    	                	SubscriberAddingFormController controller = loader.getController();
	    		        		controller.setNumOfStudents(Integer.parseInt(msg.toString()));
	    	                	Scene scene = new Scene(root);	
	    	        			stage.setTitle("Subscriber Adding Form");
	    	        			stage.setScene(scene);
	    	        			stage.show(); 
	    	        			}
	    	        		catch (IOException e) { 
	    	        			e.printStackTrace();
	    	        		}    		
	                	}
	                	
	                	else showStage(msg);

	                }
	                catch(Exception e) {
	                	System.out.println("Invoke later failed..");
	                	e.printStackTrace();
	                }
	            }
	            
	        	/**
	        	 * Get suitable stage for suitable form by object type..
	        	 * @param object
	        	 * @return suitable stage
	        	 * @throws Exception
	        	 */
	        	private void showStage(Object object) throws Exception {

	        	  	FXMLLoader loader= new FXMLLoader();
	        	  	ArrayList<String> borrowInfo = new ArrayList<String>();	
	        	  	ArrayList<String> confirmInfo = new ArrayList<String>();	
	        	  	int borrowPeriod;
	        	  	String membershipStatus;
	        		String borrowDate;
	        		String returnDate;
	        	  	
	        	  	borrowInfo = (ArrayList)object;
	        	  	membershipStatus = borrowInfo.get(1);
	        	  	if(membershipStatus.equals("Active"))
	        	  	{
	        	  		borrowPeriod = Integer.parseInt(borrowInfo.get(2));
		        	  	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		        	  	borrowDate = dateFormat.format(new Date());
		        	  	
		        	    Calendar returnDay = Calendar.getInstance();
		            	for (int i = 0; i < borrowPeriod; i++) 	
		            	{
		            		returnDay.add(Calendar.DATE, 1);
		            		//System.out.println(dateFormat.format(returnDay.getTime()));
		            	}
		            	
		        		Date day = Date.from(returnDay.toInstant());
		            	returnDate = dateFormat.format(day);
		        	  			        
		            	confirmInfo.add(bookISBN);
		            	confirmInfo.add(userID);
		            	confirmInfo.add(borrowDate);
		            	confirmInfo.add(returnDate);
		            	confirmInfo.add(borrowInfo.get(0));	// User name
		            	confirmInfo.add(borrowInfo.get(2));	// Borrow period

		            	try {
		        			Stage stage = client.getStage();
		                	Parent root = loader.load(Main.class.getResource("/client/ConfirmBookBorrow.fxml").openStream());
		                	ConfirmBookBorrowController controller = loader.getController();
			        		controller.setBorrowedBooklDetais(confirmInfo);
		                	Scene scene = new Scene(root);	
		        			stage.setTitle("Confirm Book Borrow");
		        			stage.setScene(scene);
		        			stage.show(); 
		        		}
		        		catch (IOException e) { 
		        			e.printStackTrace();
		        		}	
	        	  		
	        	  	}
	        	  	else
	        	  		Screens.showErrorDialog("Error!", "Cannot perform book borrow", borrowInfo.get(0) + "'s account is frozen.");
	            		
	        	}
	        });
		
	}
	/**
	 * returns the feedback for success and failure
	 */
	@Override
	public void feedback(Object msg)
	{
		System.out.println("> Server returned: "+msg.toString() + "(Feedback method)");
		
		Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	            	String status;

	            	status = (String)msg;
	    			if(status.equals("Success"))
	    				feedbackCounterPos++;
	    			else 
	    				feedbackCounterNeg++;
	    			
	    			int totalCounter = feedbackCounterPos + feedbackCounterNeg;
	    			
	    			if(totalCounter == 3)
	    			{
	    				if(feedbackCounterPos == 3)
	    					Screens.showSuccessDialog("Notification", "Successful return", "The book was returned successfully");
	    				else
	    					Screens.showErrorDialog("Error","Faild to return", "The required book isn`t borrowed! Please check the ISBN and try again");
	    				
	    				feedbackCounterPos = 0;
	    				feedbackCounterNeg = 0;
	    			}
	    			
	            }
	            
		 });
				
	}

	public void setUserName(String name) {
		try {
			client = ConnectionController.getConnectionController();
			userNameTextFieldID.setText(client.getName());
			ArrayList<String> SetParameters2 = new ArrayList<String>();
			SetParameters2.add(client.getUserID());
			SetParameters2.add("1");
			client.clientF = this;  
			//client.clientUI = null;
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.CHANGE_IS_CONNECTED, SetParameters2,null);
			  client.handleMessageFromClientUI(messageToSend);
	}catch (IOException e) { 
		e.printStackTrace();
	}	
	}

}
