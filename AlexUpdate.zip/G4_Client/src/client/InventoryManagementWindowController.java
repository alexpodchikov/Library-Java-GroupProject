package client;

import java.io.IOException;
import java.util.ArrayList;

import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class InventoryManagementWindowController implements ChatIF{
	
	private ConnectionController client;
	private String choice;
	private Scene curr;
	private String CatalogNumber;
		
	private final String ADD_BOOK = "Add Book";
	private final String DELETE_BOOK = "Delete Book";
	private final String EDIT_BOOK = "Edit Book";
	
	@FXML
	private TextField  EditCatalogNumberTextField, RemoveCatalogNumberTextField, AddCatalogNumberTextField;
	
	/**
	 * Private method that is invoked when delete, add and edit book options clicked
	 * Same query executed for all options - getting book info
	 * 
	 * @param catalogNumber
	 */
	private void actionHandle(String catalogNumber)
	{
		Integer catalog;
		
		if (catalogNumber.isEmpty()) {
    		Screens.showErrorDialog("Error","Text Field cannot be empty",
    				"Please enter Catalog Number");
    		return;
    	}
		
		ArrayList<String> SetParameters = new ArrayList<String>();
    	catalog = Integer.parseInt(catalogNumber);
    	catalogNumber = String.format("%04d", catalog);
		SetParameters.add(catalogNumber);
			
		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_EDIT_BOOK_INFO, SetParameters, "EditBook");
			client.handleMessageFromClientUI(messageToSend);
		}
		catch (IOException e) {
				e.printStackTrace();
		}
		
	}
	
	/**
	 * Delete book was chosen
	 * @param event
	 */
	@FXML
	 void RemoveClick(ActionEvent event) {
		String catalogNumber = RemoveCatalogNumberTextField.getText();
		curr = (Scene)((Node)event.getSource()).getScene();
		choice = DELETE_BOOK;
		actionHandle(catalogNumber);
	}
	
	/**
	 * Add book was chosen
	 * @param event
	 */
	@FXML
	 void AddClick(ActionEvent event) {
		String catalogNumber = AddCatalogNumberTextField.getText();
		curr = (Scene)((Node)event.getSource()).getScene();
		choice = ADD_BOOK;
		CatalogNumber = catalogNumber;
		actionHandle(catalogNumber);
	}

	/**
	 * Edit book was chosen
	 * @param event
	 */
	@FXML
	 void EditClick(ActionEvent event) {
		String catalogNumber = EditCatalogNumberTextField.getText();
		curr = (Scene)((Node)event.getSource()).getScene();
		choice = EDIT_BOOK;
		actionHandle(catalogNumber);
	}
	
	 /**
	  * Go to previous screen
	  * @param event
	  */
	@FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Main System Menu");	 
	}
	
	 /**
	  * Handles message from server
	  * According to clicked button, opens the next screen
	  * @param message
	  */
	@Override
	public void display(Object message) {
		
		if (message == null) 
			System.out.println("> Server returned null");
		else	
			System.out.println("> Server returned: "+message.toString());
			
			
		Platform.runLater(new Runnable() {  
		 
         @Override
         public void run() {
        	 
        	 Parent root;
             Scene scene;        	 
             ArrayList<String> bookiInfo = new ArrayList<String>();	
			 bookiInfo = (ArrayList<String>)message;
                         
        	 try{
            	 
 				client = ConnectionController.getConnectionController();
			    FXMLLoader loader = new FXMLLoader();
				Stage stage = client.getStage();
				
				switch(choice){
		
				case ADD_BOOK:
					// Book doesn't exist - add new book
					if(bookiInfo.get(bookiInfo.size()-1) == null)
					{
			        	root = loader.load(Main.class.getResource("/client/AddNewBook.fxml").openStream());
			        	AddNewBookController controller1 = loader.getController();
			        	controller1.setDefaultInfo(CatalogNumber);
			        	scene = new Scene(root);	 
						stage.setTitle("Add Copy");
						stage.setScene(scene);						
					}											
					// The book exists in the inventory - add new copy
					else
					{
			        	root = loader.load(Main.class.getResource("/client/AddNewBookCopy.fxml").openStream());
			        	AddNewBookController controller1 = loader.getController();
			        	controller1.setBookInfo(bookiInfo);
			        	scene = new Scene(root);	 
						stage.setTitle(ADD_BOOK);
						stage.setScene(scene);
					}
		        	break;
				case DELETE_BOOK:
					if(bookiInfo.get(bookiInfo.size()-1) == null)
					{
						Screens.showErrorDialog("Error","Entry was not found", "Server didn't find the requested catalog number!\n");
						return;						
					}
		        	root = loader.load(Main.class.getResource("/client/DeleteBook.fxml").openStream());
		        	DeleteBookController controller2 = loader.getController();
		        	controller2.setBookInfo(bookiInfo);
		        	scene = new Scene(root);	 
					stage.setTitle(DELETE_BOOK);
					stage.setScene(scene);
					break;
				case EDIT_BOOK:
					if(bookiInfo.get(bookiInfo.size()-1) == null)
						{
							Screens.showErrorDialog("Error","Entry was not found", "Server didn't find the requested catalog number!\n");
							return;						
						}
		        	root = loader.load(Main.class.getResource("/client/EditBook.fxml").openStream());
		        	EditBookController controller3 = loader.getController();
		        	controller3.setBookInfo(bookiInfo);
		        	scene = new Scene(root);	 
					stage.setTitle(EDIT_BOOK);
					stage.setScene(scene);
					break;								
				default:
					System.out.println("Error in choice variable");
				}
				
 				client.setPrevScene(curr); 	        	
				stage.show(); 

             }
             catch(Exception e) {
             	System.out.println("Invoke later failed..");
             	e.printStackTrace();
             }
         }
	 });	
}
	
}
