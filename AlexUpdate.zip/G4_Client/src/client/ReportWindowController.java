package client;

import java.io.IOException;
import java.util.ArrayList;

import common.Book;
import common.BookName;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ReportWindowController implements ChatIF {
	private ConnectionController client;

	 /**
	  * going back to previous screen
	  * @param event back button clicked
	  */
	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Library Main Screen");	 
	}
	 /**
	  * change the screen to activity report screeen
	  * @param event borrow button clicked
	  */
	 @FXML
	 void ActivityClicked(ActionEvent event) {
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
				client.setPrevScene(curr);
				 ArrayList<String> SetParameters = new ArrayList<String>();	
				 SetParameters.add("vasya");
				ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.FILL_ACTIVITY_REPORT_COMBO_BOX, SetParameters, "activity_report_combobox");			    
				client.handleMessageFromClientUI(messageToSend);
						    
				}
			catch (IOException e) {
				e.printStackTrace();
			}	 
	}
	 /**
	  * change the screen to borrow report screeen
	  * @param event borrow button clicked
	  */
	 @FXML 
	 void BorrowClicked(ActionEvent event) {
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
				client = ConnectionController.getConnectionController();
			    client.setPrevScene(curr);
			    Screens.showNewScreen("/client/BorrowReport.fxml", null, " Borrow Report Window");
				}
			catch (IOException e) {
				e.printStackTrace();
			}
		 
	}
	 @FXML
	 void LateReturnClicked(ActionEvent event) {
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
				client = ConnectionController.getConnectionController();
			    client.setPrevScene(curr);
			    Screens.showNewScreen("/client/LateReturnReport.fxml", null, " Late Report Window");
				}
			catch (IOException e) {
				e.printStackTrace();
			}
	 
	}
	 /**
	  * returns the answer from server and show it the right place
	  */
	@Override
	public void display(Object message) {

		
		/**
		 * Display error dialog is server returned null.
		 * TODO: make stage factory.
		 */
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	                try{
	                	   	
	                	showStage(message);

	                }
	                catch(Exception e) {
	                	System.out.println("Invoke later failed..");
	                	e.printStackTrace();
	                }
	            }
	            private void showStage(Object object) throws Exception {
	            	
	            	
	            	
	            	
	   	try {
	   		client = ConnectionController.getConnectionController();
	   		
		  	FXMLLoader loader= new FXMLLoader();
	   	 
			Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource("/client/ActivityReport.fxml").openStream()); 
			
			ActivityReportController controller = loader.getController();
    		controller.initComboBox();
        	Scene scene = new Scene(root);	

			stage.setTitle("Activity Report");
			stage.setScene(scene);
			stage.show(); 
		}
		catch (IOException e) { 
			e.printStackTrace();
		}
		  
				
	}
		 }); 
	}
}
