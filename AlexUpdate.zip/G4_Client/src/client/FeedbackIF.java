package client;
/**
 * 
 * @author Group4
 *this is interface that gives us the feedback for db queries
 */
public interface FeedbackIF {
	
	public abstract void feedback(Object message);
	
}
