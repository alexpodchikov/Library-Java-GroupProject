package server;

	import java.util.HashMap;
	import java.util.List;

	import common.EQueryOption;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

	/**
	 * Class: Query
	 * Store all server queries related to our database.
	 *
	 */
	public class Query {

		
		//Database user
		private final static String USER_TABLE = "obl.user";
		private final static String USER_ID	="UserID";
		private final static String USER_NAME = "UserName";
		private final static String PASSWORD = "Password";
		private final static String ACCOUNT_TYPE = "AccountType";
		private final static String STATUS_MEMBERSHIP = "StatusMembership";
		private final static String USER_FREEZE_COUNTER = "FreezeCounter";
		
		//Database student
		private final static String STUDENT_TABLE = "obl.student";
		private final static String STUDENT_ID = "StudentID";
		private final static String STUDENT_NAME = "StudentName";
		private final static String STUDENT_PASSWORD = "StudentPassword";
		private final static String STUDENT_PHONE_NUMBER = "PhoneNumber";
		private final static String STUDENT_EMAIL = "Email";
		private final static String STUDENT_STATUS_MEMBERSHIP = "StatusMembership";
		private final static String OPERATION = "Operation";
		private final static String FREEZE = "FreezeCounter";
		private final static String SUBSCRIBER_NUMBER = "StudentSubscriberNumber";

		
		//Database book
		private final static String BOOK_TABLE = "obl.book";
		private final static String BOOK_TITLE = "Headline";
		private final static String BOOK_AUTHOR = "Author";
		private final static String BOOK_ID = "ISBN";							//Key
		private final static String CATALOG_NUMBER = "CatalogNumber";
		private final static String BOOK_EDITION_NUMBER = "EditionNumber";
		private final static String BOOK_PRINT_DATE = "PrintDate";
		private final static String BOOK_SUBJECT = "Subject";
		private final static String BOOK_PURCHASE_DATE = "PurchaseDate";
		private final static String BOOK_NUMBER_COPIES = "NumberCopies";
		private final static String BOOK_NUMBER_WANTEDTAG = "WantedTag";
		private final static String BOOK_BORROW_PERIOD = "BorrowPeriod";
		private final static String BOOK_BORROW_COUNTER = "BorrowCounter";
		private final static String BOOK_BORROW_DURATION = "BorrowDuration";
		private final static String BOOK_RETURN_DELAY = "ReturnDelay";
		private final static String AVAILABLE_COPY = "Available";
		private final static String NEXT_RETURN_DATE = "NextReturnDate";
		private final static String BOOK_DESCRIPTION = "Description";
		private final static String BOOK_LOCATION = "ShelfLocation";
		///
		
		//Database BorrowedBook
				private final static String BORROWED_BOOK_TABLE = "obl.borrowedbook";
				private final static String BORROWED_BOOK_ISBN = "ISBN";
				private final static String BORROWED_BOOK_BORROWER_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_DATE = "borrowDate";
				private final static String BORROWED_BOOK_RETURN_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_STATUS = "borrowStatus";
		
				//Database books_archive
				private final static String BOOK_ARCHIVE_TABLE = "obl.books_archive";
				private final static String BOOK_ARCHIVE_TITLE = "Headline";
				private final static String BOOK_ARCHIVE_AUTHOR = "Author";
				private final static String BOOK_ARCHIVE_ID = "ISBN";
				private final static String BOOK_ARCHIVE_CATALOG_NUMBER = "CatalogNumber";
				private final static String BOOK_ARCHIVE_EDITION_NUMBER = "EditionNumber";
				private final static String BOOK_ARCHIVE_PRINT_DATE = "PrintDate";
				private final static String BOOK_ARCHIVE_SUBJECT = "Subject";
				private final static String BOOK_ARCHIVE_PURCHASE_DATE = "PurchaseDate";
				private final static String BOOK_ARCHIVE_NUMBER_COPIES = "NumberCopies";
				private final static String BOOK_ARCHIVE_DESCRIPTION = "Description";
				private final static String BOOK_ARCHIVE_AECHIVE_DATE = "ArchiveDate";
				private final static String BOOK_ARCHIVE_WORKER_ID = "WorkerID";		
				
		//Database BorrowedBookHistory
				private final static String BORROWED_BOOK_HISTORY_TABLE = "obl.borrowed_book_history";
				private final static String BORROWED_BOOK_HISTORY_ISBN = "ISBN";
				private final static String BORROWED_BOOK_USER_HISTORY_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_HISTORY_DATE = "borrowDate";
				private final static String BORROWED_BOOK_BORROW_HISTORY_TIME = "borrowTime";
				private final static String BORROWED_BOOK_RETURN_HISTORY_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_HISTORY_STATUS = "borrowStatus";
				
		//Database SubscriberStatusHistory
				private final static String SUBSCRIBER_STATUS_HISTORY_TABLE = "obl.subscriber_status_history";
				private final static String SUBSCRIBER_STATUS_HISTORY_ID = "subscribeID";			//Key
				private final static String SUBSCRIBER_STATUS_HISTORY_STATUS = "subscriberStatus";
				private final static String SUBSCRIBER_STATUS_HISTORY_START_DATE = "beginningDate";	//Key
				private final static String SUBSCRIBER_STATUS_HISTORY_END_DATE = "endDate";
				
		//Database ProlongationRequest
				private final static String PROLONGATION_REQUEST_TABLE = "obl.prolongationrequest";
				private final static String PROLONGATION_REQUEST_SUBSCRIBER_ID = "SubscriberID";	//Key
				private final static String PROLONGATION_REQUEST_DATE = "ProlongationDate";			//Key
				private final static String PROLONGATION_REQUEST_ISBN = "ISBN";						//Key
				private final static String PROLONGATION_REQUEST_DATE_CONFIRMATION = "RequestConfirmation";
				
		//Database ProblematicSubscribers
				private final static String PROBLEMATIC_SUBSCRIBERS_TABLE = "obl.problematicsubscriber";
				private final static String PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID = "SubscribersID";//Key
				private final static String PROBLEMATIC_SUBSCRIBERS_NAME = "SubscribersName";	
				private final static String PROBLEMATIC_SUBSCRIBERS_STATUS= "SubscriberStatus";	
				
		//Database ManualProlongation
				private final static String MANUAL_PROLONGATION_TABLE = "obl.manualprolongation";
				private final static String MANUAL_PROLONGATION_LIBRARIAN_ID = "librarianID";		//Key
				private final static String MANUAL_PROLONGATION_ISBN = "ISBN";						//Key
				private final static String MANUAL_PROLONGATION_LIBRARIAN_NAME = "librarianName";	
				private final static String MANUAL_PROLONGATION_DATE = "prolongationDate";			//Key
				// Database Waiting List	
				private final static String WAITING_LIST_TABLE = "obl.waiting_list";
				private final static String WAITING_LIST_CATALOG_NUMBER = "CatalogNumber";	// key
				private final static String WAITING_LIST_SUBSCRIBER_ID = "SubscriberID";	// key
				private final static String WAITING_LIST_PLACE_IN_LINE = "PlaceInLine"; 
				
		//Database ActivityReport
				private final static String ACTIVE_REPORT_TABLE = "obl.active_report";
				private final static String ACTIVE_REPORT_FROM_DATE = "FromDate";		//Key
				private final static String ACTIVE_REPORT_TO_DATE = "ToDate";						//Key
				private final static String ACTIVE_REPORT_ACTIVE_SUBSCRIBER_AMOUNT = "NumberofActiveSubscribers";	
				private final static String ACTIVE_REPORT_FROZEN_SUBSCRIBER_AMOUNT = "NumberofFrozenSubscribers";			//Key
				private final static String ACTIVE_REPORT_LOCKED_SUBSCRIBER_AMOUNT = "NumberofLockedSubscribers";						//Key
				private final static String ACTIVE_REPORT_NUMBER_OF_BORROWED_BOOKS = "NumberofBorrowedBooks";	
				private final static String ACTIVE_REPORT_NUMBER_OF_LATE_RETURN_SUBSCRIBER = "NumberofLateReturnSubscribers";			//Key				
					
		/**
		 * HashMap contains EQueryOption as key
		 * and number of parameters required as value.
		 */
		private static HashMap<EQueryOption, Integer> enumParamNum = startMap();
		
		/**
		 * Static initialization of enumParameterNumber
		 * @return initialized HashMap
		 */
		private static HashMap<EQueryOption, Integer> startMap()
	    {
			HashMap<EQueryOption, Integer> map = new HashMap<EQueryOption,Integer>();
			map.put(EQueryOption.LOGIN_REQUEST, 2); //Parameters: UserName, Password.
	        map.put(EQueryOption.GET_STUDENT_INFO, 1);		// Parameters: ID.
	        map.put(EQueryOption.SAVE_STUDENT_INFO, 3);      //userid , email,phone;
	        map.put(EQueryOption.UPDATE_STATUS_MEMBERSHIP, 2);	// Parameters:ID, StatusMembership.
	        map.put(EQueryOption.GET_BORROWED_BOOK_INFO, 1); // Parameters:,userId.
	        map.put(EQueryOption.GET_BOOK_INFO, 4); // Parameters: BookTitle, BookAuthor, BookSubject, BookDescription;
	        map.put(EQueryOption.ADD_READER_CARD, 6);// Parameters: StudentID, StudentName, StudentPassword, PhoneNumber, Email;
	        map.put(EQueryOption.GET_STUDENT_NAME, 1); // Parameters: StudentName.
	        map.put(EQueryOption.ADD_BORROWED_BOOK, 5);// Parameters: bookID, userID, borrowDate, returnDate, borrowStatus;
	        map.put(EQueryOption.ADD_BORROWED_BOOK_HISTORY,3);// Parameters: bookID, userID, borrowDate;
	        map.put(EQueryOption.DELETE_BORROWED_BOOK, 1);// Parameters: ISBN;	 
	        map.put(EQueryOption.SET_BOOK_AVAILABILITY_ON, 1);// Parameters: bookID;
	        map.put(EQueryOption.SET_BOOK_AVAILABILITY_OFF, 1);// Parameters: bookID;
	        map.put(EQueryOption.GET_BOOK_BORROW_HISTORY,1);// Parameters: userID;
	        map.put(EQueryOption.RETURN_BORROWED_BOOK, 3);// Parameters: ISBN, returnDate, retutnStatus;			      
	        map.put(EQueryOption.GET_BOOK_BORROW_HISTORY,1);// Parameters: userID;
	        map.put(EQueryOption.GET_BORROW_INFO, 2);// Parameters: borrower_id,ISBN;
	        map.put(EQueryOption.INCREASE_BORROW_DURATION, 0);
	        map.put(EQueryOption.INCREASE_RETURN_DELAY, 0);
	        map.put(EQueryOption.ADD_USER,3);
	        map.put(EQueryOption.NUM_OF_STUDENTS,1);

	        
	        map.put(EQueryOption.SUBSCRIBERS_COUNTER_IN_A_STATUS,3);	// Parameters: fromDate,toDate,status;
	        map.put(EQueryOption.BORROWED_BOOK_COUNTER_FROM_TO,2);	// Parameters: fromDate,toDate,status;
	        map.put(EQueryOption.DELAYING_BOOK_RETURN_SUBSCRIBER_COUNTER_FROM_TO,2);	// Parameters: fromDate,toDate,status;
	        map.put(EQueryOption.AVG_BORROW_DURATION, 1);
	        map.put(EQueryOption.MEDIAN_BORROW_DURATION, 1);	// Parameters: wantedStatus; ( Wanted OR Regular )
	        map.put(EQueryOption.AVG_LATE_RETURN_AMOUNT_AND_DURATION, 0);
	        map.put(EQueryOption.MEDIAN_DELAY_DURATION, 0);
	        map.put(EQueryOption.RETURN_BOOKS_THAT_CAN_BE_PROLONGED_ISBN_TABLE, 1);	// Parameters: today;	        
	        map.put(EQueryOption.UPDATE_BORROWED_BOOK_RETURN_DELAY, 1);	// Parameters: today; 
	        map.put(EQueryOption.INCREASE_BORROWED_BOOK_BORROW_DURATION, 0);
	        map.put(EQueryOption.SET_PROBLEMATIC_SUBSCRIBER_LOCKING_DURATION, 2);		// Parameters: subscriberID,lockingDuration;
	        map.put(EQueryOption.ADD_PROBLEMATIC_SUBSCRIBER, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.DELETE_SUBSCRIBER_FROM_PROBLEMATIC_SUBSCRIBER, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.SET_SUBSCRIBER_STATUS_ACTIVE, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.SET_RETURN_DATE_IN_BORROWED_BOOK_HISTORY, 1);	// Parameters: ISBN;
	        map.put(EQueryOption.UPDATE_SUBSCRIBER_STATUS_TO_ACTIVE, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.GET_BORROWER_ID, 1);	// Parameters: ISBN;
	        map.put(EQueryOption.UPDATE_RETURN_DATE_USER_STATUS, 1);	// Parameters: ISBN;
	        map.put(EQueryOption.SUBSCRIBER_MANUAL_PROLONGATION,1); //ISBN;
	        map.put(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION,1); //ISBN;
	        map.put(EQueryOption.ADD_ACTIVITY_REPORT,7); //FromDate,ToDate,NumberofActiveSubscribers,NumberofFrozenSubscribers,NumberofLockedSubscribers,NumberofLateReturnSubscribers ,NumberofBorrowedBooks;
	        map.put(EQueryOption.FILL_ACTIVITY_REPORT_COMBO_BOX,1); 
	        map.put(EQueryOption.GET_ACTIVITY_REPORT_INFO,2); //FromDate
	        map.put(EQueryOption.MEDIAN_DELAY_AMOUNT,1);
	        map.put(EQueryOption.ALL_BOOKS_DELAY_DISTRIBUTION,1);
	        map.put(EQueryOption.UPDATE_SUBSCRIBER_AND_BOOK_DELAY_STATUS, 1);// Parameters: today;
	        map.put(EQueryOption.ALL_BOOKS_DELAY_AMOUNT_DISTRIBUTION,1);
	        map.put(EQueryOption.BOOK_DELAY_DISTRIBUTION,1);
	        map.put(EQueryOption.BOOK_DELAY_AMOUNT_DISTRIBUTION,1);
	        map.put(EQueryOption.BORROW_DURATION_DISTRIBUTION,1);
	        map.put(EQueryOption.AVG_LATE_RETURN_AMOUNT,1);
	        map.put(EQueryOption.AVG_LATE_RETURN_DURATION,1);
	        map.put(EQueryOption.GET_BOOK_NAMES,1);
			map.put(EQueryOption.BOOK_MEDIAN_DELAY_AMOUNT,1);
	        map.put(EQueryOption.BOOK_MEDIAN_DELAY,1);
	        map.put(EQueryOption.BOOK_AVG_DELAY_AMOUNT,1);
	        map.put(EQueryOption.BOOK_AVG_DELAY,1);	
	        map.put(EQueryOption.GET_PROBLEMATIC_SUBSCRIBERS,1);
	        map.put(EQueryOption.UNLOCK_PROBLEMATIC_SUBSCRIBER,1);
	        map.put(EQueryOption.DELETE_PROBLEMATIC_SUBSCRIBER,1);
	        map.put(EQueryOption.LOCK_PROBLEMATIC_SUBSCRIBER,1);
	        map.put(EQueryOption.ADD_NEW_BOOK,13);
	        map.put(EQueryOption.RELOCATE_BOOK, 4);
	        map.put(EQueryOption.DELETE_BOOK, 2); // Parameters: catalogNumber, isbn
	        map.put(EQueryOption.UPDATE_NUMBERS_OF_BOOKS, 2); //Parameters: catalogNumber
	        map.put(EQueryOption.GET_EDIT_BOOK_INFO, 1);
	        map.put(EQueryOption.UPDATE_BOOK, 6); // Parameters: catalogNumber, wantedTag, borrowPeriod, subject, shelfLocation, description
	        
	        map.put(EQueryOption.WAITING_LIST_INFO, 1); // Parameters: catalogNumber
	        map.put(EQueryOption.ENTER_WAITING_LIST, 2); // Parameters: catalogNumber, subscriberID
			
	        
	        return map;
	    }
		
		
		/**
		 * Get suitable query
		 * Parameters order must be as table columns
		 * @param queryOption 
		 * @return Query string
		 */
		public static String getQuery(EQueryOption queryOption, List<String> Parameters) throws Exception{
			//System.out.println(Parameters);
			/*//System.out.println("size: "+Parameters.size());
			if (Parameters.size() != enumParamNum.get(queryOption)) {
				//System.out.println("got you!!");
				return "";
				// TODO: add invalid parameters number error or Exception 
			}*/
			
			switch(queryOption) {
			case LOGIN_REQUEST:
				return LoginRequest(Parameters.get(0),Parameters.get(1));	
			case GET_STUDENT_INFO:
				return getStudentInfo(Parameters.get(0));
			case SAVE_STUDENT_INFO:
				return saveStudentInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2));
			case GET_BORROWED_BOOK_INFO:
				return getBorrowedBookInfo(Parameters.get(0));
			case GET_BOOK_BORROW_HISTORY:
				return getBookBorrowHistory(Parameters.get(0));	
			//case UPDATE_STATUS_MEMBERSHIP:GET_BOOK_BORROW_HISTORY
				//return updateStudentInfo(Parameters.get(0),Parameters.get(1));
			case NUM_OF_STUDENTS:

				return numOfStudents(Parameters.get(0));
			case GET_BOOK_INFO:
				//if(enumParamNum.get(queryOption)== 4) 
				return getBookInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3));
				//else 
					//return getBookInfo(Parameters.get(0));	
			case ADD_USER:
				return addUser(Parameters.get(0),Parameters.get(1),Parameters.get(2));	
			case ADD_READER_CARD:
				return addReaderCard(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),Parameters.get(5));
				
			case GET_STUDENT_NAME:
				return getStudentName(Parameters.get(0));
				
			case ADD_BORROWED_BOOK:
				return addBorrowedBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4));
				
			case ADD_BORROWED_BOOK_HISTORY:
				return addBorrowedBookHistory(Parameters.get(0),Parameters.get(1),Parameters.get(2));
				
			case DELETE_BORROWED_BOOK:
				return deleteBorrowedBook(Parameters.get(0));
				
			case RETURN_BORROWED_BOOK:
				return setReturnedBookInfo(Parameters.get(0),Parameters.get(1));
				
			case GET_BORROW_INFO:
				return getBorrowInfo(Parameters.get(0),Parameters.get(1));
			
			case SET_BOOK_AVAILABILITY_OFF:
				return setBookAvailabilityOFF(Parameters.get(0));
				
			case SET_BOOK_AVAILABILITY_ON:
				return setBookAvailabilityON(Parameters.get(0));	
				
			case INCREASE_BORROW_DURATION:
				return increaseBorrowDuration();
				
			case INCREASE_RETURN_DELAY:
				return increaseReturnDelay();
				
			case UPDATE_SUBSCRIBER_AND_BOOK_DELAY_STATUS:
				return updateSubscriberAndBookDelayStatus(Parameters.get(0));
			
			case SET_RETURN_DATE_IN_BORROWED_BOOK_HISTORY:
				return setReturnDateInBorrowedBookHistory(Parameters.get(0));
			
			case UPDATE_SUBSCRIBER_STATUS_TO_ACTIVE:
				return updateSubscriberStatusToActive (Parameters.get(0));
			
			case GET_BORROWER_ID:
				return getBorrowerID(Parameters.get(0));
				
			case UPDATE_RETURN_DATE_USER_STATUS:
				return updateReturnDateAndUserStatus(Parameters.get(0));
			
			/**
			 * system update
			 */
			case RETURN_BOOKS_THAT_CAN_BE_PROLONGED_ISBN_TABLE:
				return findBooksThatCanBeProlonged(Parameters.get(0));
			case UPDATE_BORROWED_BOOK_RETURN_DELAY:
				return updateBorrowedBookReturnDelay(Parameters.get(0)); 
			case INCREASE_BORROWED_BOOK_BORROW_DURATION:
				return increaseBorrowedBookBorrowDuration();
			case ADD_PROBLEMATIC_SUBSCRIBER:
				return addProblematicSubscriber(Parameters.get(0)); 
			case DELETE_SUBSCRIBER_FROM_PROBLEMATIC_SUBSCRIBER:
				return deleteProblematicSubscriber(Parameters.get(0));
			case SET_SUBSCRIBER_STATUS_ACTIVE:
				return setSubscriberStatusActive(Parameters.get(0));			
			/**
			 * Activity report	
			 */
			case SUBSCRIBERS_COUNTER_IN_A_STATUS:
				return subscriberCounterInSpecificStatus(Parameters.get(0),Parameters.get(1),Parameters.get(2));				
			case BORROWED_BOOK_COUNTER_FROM_TO:
				return borrowedBookCounter(Parameters.get(0),Parameters.get(1));
			case DELAYING_BOOK_RETURN_SUBSCRIBER_COUNTER_FROM_TO:
				return notReturnBookCounter(Parameters.get(0),Parameters.get(1));
			case ADD_ACTIVITY_REPORT:
				return addActivityReport (Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),Parameters.get(5),Parameters.get(6));
			case FILL_ACTIVITY_REPORT_COMBO_BOX:
				return fillActivityReportComboBox(Parameters.get(0));
			case GET_ACTIVITY_REPORT_INFO:
				return getActivityReportInfo(Parameters.get(0),Parameters.get(1));
			case UNLOCK_PROBLEMATIC_SUBSCRIBER:
				return unlockProblematicSubscriber(Parameters.get(0));
			case DELETE_PROBLEMATIC_SUBSCRIBER:
				return deleteProblematicSubscriber(Parameters.get(0));
			case LOCK_PROBLEMATIC_SUBSCRIBER:
				return lockProblematicSubscriber(Parameters.get(0));
				
			/**
			 * Borrow report 
	    	 */
			case AVG_BORROW_DURATION:
				return avgBorrowDuration(Parameters.get(0));
			case MEDIAN_BORROW_DURATION:
				return medianBorrowDuration(Parameters.get(0));
				
			/**
			 * Return Delay report 
			 */	

				
				
				/**
				 * Return Delay report 
				 */	
				case AVG_LATE_RETURN_AMOUNT:
					return avgNumberOfLateReturns();
				case AVG_LATE_RETURN_DURATION:
					return avgDelayDuration();
				case BOOK_MEDIAN_DELAY_AMOUNT:
					return bookMedianDelayAmount(Parameters.get(0));
				case BOOK_MEDIAN_DELAY:
					return bookMedianDelay(Parameters.get(0));
				case BOOK_AVG_DELAY_AMOUNT:
					return bookAvgDelayAmount(Parameters.get(0));
				case BOOK_AVG_DELAY:
					return bookAvgDelay(Parameters.get(0));
			
					
			case MEDIAN_DELAY_DURATION:
				return medianDelayDuration();
			case LIBRARIAN_MANUAL_PROLONGATION:
				return librarianManualProlongation(Parameters.get(0));
			case SUBSCRIBER_MANUAL_PROLONGATION:
				return subscriberManualProlongation(Parameters.get(0));
			case MEDIAN_DELAY_AMOUNT:
				return medianDelayAmount(Parameters.get(0));
			case ALL_BOOKS_DELAY_DISTRIBUTION:
				return allBooksDelayDistribution(Parameters.get(0));
			case BOOK_DELAY_DISTRIBUTION:
				return bookDelayDistribution(Parameters.get(0));
			case ALL_BOOKS_DELAY_AMOUNT_DISTRIBUTION:
				return allBooksDelayAmountDistribution(Parameters.get(0));
			case BOOK_DELAY_AMOUNT_DISTRIBUTION:
				return bookDelayAmountDistribution(Parameters.get(0));
			case BORROW_DURATION_DISTRIBUTION:
				return borrowDurationDistribution(Parameters.get(0)); 
				
			case GET_PROBLEMATIC_SUBSCRIBERS:
				return getProblematicSubscriber(Parameters.get(0));
				
			case GET_BOOK_NAMES:
				return getBookName(Parameters.get(0));
					
			case ADD_NEW_BOOK:
				return addNewBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),
						Parameters.get(5),Parameters.get(6),Parameters.get(7),Parameters.get(8),Parameters.get(9),Parameters.get(10),
						Parameters.get(11),Parameters.get(12));				
			case RELOCATE_BOOK:
				return relocateBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3));				
			case DELETE_BOOK:
				return deleteBook(Parameters.get(0),Parameters.get(1));				
			case UPDATE_NUMBERS_OF_BOOKS:
				return updateNumbersOFBooks(Parameters.get(0), Parameters.get(1));				
			case GET_EDIT_BOOK_INFO:
				return getEditBookInfo(Parameters.get(0));			
			case UPDATE_BOOK:
				return updateBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),Parameters.get(5));
			
			case WAITING_LIST_INFO:
				return waitingListInfo(Parameters.get(0));		
			case ENTER_WAITING_LIST:
				return enterWaitingList(Parameters.get(0),Parameters.get(1));		
				
				
			default:
					return "";	// TODO: add error or exception (invalid enum option).
			}
		}


		private static String waitingListInfo(String catalogNumber)
		{
			catalogNumber = "\'"+ catalogNumber + "\'";
			String queryToReturn = "SELECT MAX(" + WAITING_LIST_PLACE_IN_LINE +"), " + BOOK_NUMBER_COPIES +
					" FROM " + WAITING_LIST_TABLE + ", " + BOOK_TABLE + 
					" WHERE " + WAITING_LIST_TABLE + "." + WAITING_LIST_CATALOG_NUMBER + " = " + BOOK_TABLE + "." + CATALOG_NUMBER + " = " + catalogNumber + ";";

			return queryToReturn;
			
		}
		
	
		private static String enterWaitingList(String catalogNumber, String subscriberID)
		{
			catalogNumber = "\'"+ catalogNumber + "\'";
			subscriberID = "\'"+ subscriberID + "\'";
			
			String queryToReturn = "INSERT INTO " + WAITING_LIST_TABLE + 
					"(" + WAITING_LIST_CATALOG_NUMBER + ", "+ WAITING_LIST_SUBSCRIBER_ID + ", "+ WAITING_LIST_PLACE_IN_LINE + ") " +
					"SELECT " + catalogNumber + ", " + subscriberID + ", IF(MAX(" + WAITING_LIST_PLACE_IN_LINE + "), MAX(" + WAITING_LIST_PLACE_IN_LINE + ") + 1, 1)" +
					" FROM " + WAITING_LIST_TABLE + 
					" WHERE " + WAITING_LIST_CATALOG_NUMBER + " = " + catalogNumber + ";";
							
			return queryToReturn;
		}
				
		
		private static String updateBook(String catalogNumber, String wantedTag,
			String borrowPeriod, String subject, String shelfLocation, String description) {
			subject = "\'"+ subject+ "\'";
			wantedTag = "\'"+ wantedTag+ "\'";
			borrowPeriod = "\'"+ borrowPeriod+ "\'";
			description = "\'"+ description+ "\'";
			shelfLocation = "\'"+ shelfLocation+ "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + " SET " + BOOK_BORROW_PERIOD + " = " + borrowPeriod +" , "
			+ BOOK_SUBJECT + " = " + subject + " , " + BOOK_LOCATION + " = " + shelfLocation + " , " + BOOK_NUMBER_WANTEDTAG + " = " + wantedTag + " , "
			+ BOOK_DESCRIPTION + " = " + description  + " WHERE " + CATALOG_NUMBER + "=" + catalogNumber + ";";
			return queryToReturn;
		}
		

		private static String getEditBookInfo(String catalogNumber) {
			catalogNumber = "\'"+ catalogNumber+ "\'";
			String queryToReturn = "SELECT " + BOOK_TITLE + ","+ BOOK_AUTHOR + "," +" MAX(" +BOOK_ID + ")" + "," + CATALOG_NUMBER +","+ BOOK_EDITION_NUMBER 
					+","+ BOOK_PRINT_DATE + "," + BOOK_BORROW_PERIOD +","+ BOOK_NUMBER_WANTEDTAG + "," + BOOK_PURCHASE_DATE
					+","+ BOOK_SUBJECT + "," + BOOK_LOCATION + ","+ BOOK_NUMBER_COPIES + "," + BOOK_DESCRIPTION +
					" FROM " + BOOK_TABLE + " WHERE " + CATALOG_NUMBER + " = " + catalogNumber + " ;";
			return queryToReturn;				
		}


		private static String updateNumbersOFBooks(String catalogNumber, String sign) {

			catalogNumber = "\'"+ catalogNumber+ "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + " SET " + BOOK_NUMBER_COPIES + " = " 
			+ BOOK_NUMBER_COPIES + sign + " WHERE " + CATALOG_NUMBER + "=" + catalogNumber +" ;";
			return queryToReturn;
		}


		private static String deleteBook(String catalogNumber, String isbn) {
			catalogNumber = "\'"+ catalogNumber+ "\'";
			isbn = "\'"+ isbn+ "\'";
			String queryToReturn = "DELETE FROM " + BOOK_TABLE + " WHERE IF ("+  isbn + " != "+ "''" + " , "
					+ BOOK_ID + " = "+ isbn + " AND " + CATALOG_NUMBER + "=" + catalogNumber 
					+  " , "+ CATALOG_NUMBER + " = " + catalogNumber + ");";
			return queryToReturn;
		}


		private static String relocateBook(String catalogNumber, String isbn, String removeDate, String workerID) {
			catalogNumber = "\'"+ catalogNumber+ "\'";
			isbn = "\'"+ isbn+ "\'";
			removeDate = "\'"+ removeDate+ "\'";
			workerID = "\'"+ workerID+ "\'";
			String queryToReturn = "INSERT INTO " + BOOK_ARCHIVE_TABLE + "(" + BOOK_ARCHIVE_TITLE +","+ BOOK_ARCHIVE_AUTHOR 
					+","+ BOOK_ARCHIVE_ID +","+ BOOK_ARCHIVE_CATALOG_NUMBER +","+ BOOK_ARCHIVE_EDITION_NUMBER
					+ "," + BOOK_ARCHIVE_PRINT_DATE + "," + BOOK_ARCHIVE_SUBJECT +","+  BOOK_ARCHIVE_PURCHASE_DATE + "," 
					+ BOOK_ARCHIVE_DESCRIPTION + "," + BOOK_ARCHIVE_AECHIVE_DATE
					+ "," + BOOK_ARCHIVE_WORKER_ID +")" + "SELECT " + BOOK_TITLE +","+ BOOK_AUTHOR +","+ BOOK_ID 
					+","+ CATALOG_NUMBER +","+ BOOK_EDITION_NUMBER + "," + BOOK_PRINT_DATE + "," + BOOK_SUBJECT 
					+","+ BOOK_PURCHASE_DATE + "," + BOOK_DESCRIPTION 
					+","+ removeDate +","+ workerID + " FROM " + BOOK_TABLE + " WHERE IF ("+  isbn + " != "+ "''" + " , "
					+ BOOK_ID + " = "+ isbn + " AND " + CATALOG_NUMBER + "=" + catalogNumber 
					+  " , "+ CATALOG_NUMBER + " = " + catalogNumber + ");";
			return queryToReturn;
		}


		private static String addNewBook(String headline, String author, String isbn, String catalogNumber, String editionNumber,
				String printDate, String subject, String purchaseDate, String numberCopies, String wantedTag, String borrowPeriod,
				String description, String shelfLocation) {
			headline = "\'"+ headline+ "\'";
			author = "\'"+ author+ "\'";
			isbn = "\'"+ isbn+ "\'";
			catalogNumber = "\'"+ catalogNumber+ "\'";
			editionNumber = "\'"+ editionNumber+ "\'";
			printDate = "\'"+ printDate+ "\'";
			subject = "\'"+ subject+ "\'";
			purchaseDate = "\'"+ purchaseDate+ "\'";
			numberCopies = "\'"+ numberCopies+ "\'";
			wantedTag = "\'"+ wantedTag+ "\'";
			borrowPeriod = "\'"+ borrowPeriod+ "\'";
			description = "\'"+ description+ "\'";
			shelfLocation = "\'"+ shelfLocation+ "\'";
			String queryToReturn = "INSERT INTO " + BOOK_TABLE + "(" + BOOK_TITLE +","+ BOOK_AUTHOR +","+ BOOK_ID 
					+","+ CATALOG_NUMBER +","+ BOOK_EDITION_NUMBER + "," + BOOK_PRINT_DATE + "," + BOOK_SUBJECT 
					+","+  BOOK_PURCHASE_DATE + ","+ BOOK_NUMBER_COPIES +","+ BOOK_NUMBER_WANTEDTAG + "," + BOOK_BORROW_PERIOD 
					+ "," + BOOK_BORROW_COUNTER /*+ "," + BOOK_BORROW_DURATION +*/+ ","+ BOOK_RETURN_DELAY
					+ "," + AVAILABLE_COPY + "," + BOOK_DESCRIPTION +","+  BOOK_LOCATION +")" + 
					"VALUE" + "(" + headline +","+ author +","+ isbn +","+ catalogNumber +","+ editionNumber 
					+ "," + printDate +","+ subject +","+ purchaseDate +","+ numberCopies +","+ wantedTag 
					+","+ borrowPeriod +","+ 0 +"," + 0 +", "+ 1 +", "+ description +","+ shelfLocation +");"; //+ "ON DUPLICATE KEY UPDATE" 

			return queryToReturn;
		}
		/**
		 * Get query string for borrow history
		 * @param ID
		 * @return Book Borrow History Info query string.
		 */
		
		private static String getBookBorrowHistory(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn =  "SELECT " + BORROWED_BOOK_HISTORY_ISBN + ","+ BORROWED_BOOK_USER_HISTORY_ID +
					"," + BORROWED_BOOK_BORROW_HISTORY_DATE + " , " + BORROWED_BOOK_RETURN_HISTORY_DATE + " , " + 
					BORROWED_BOOK_BORROW_HISTORY_STATUS + 
					" FROM " + BORROWED_BOOK_HISTORY_TABLE + 
					" WHERE " + BORROWED_BOOK_USER_HISTORY_ID + " = " + ID+";";
			return queryToReturn;
		}

		/**
		 * Get query string for updating student's info
		 * @param ID
		 * @param email
		 * @param phone
		 * @return
		 */
		private static String saveStudentInfo(String ID, String email, String phone) {
			ID = "\'"+ ID+ "\'";
			email = "\'"+ email+ "\'";
			phone = "\'"+ phone+ "\'";
			String queryToReturn = "UPDATE " + STUDENT_TABLE + " SET " + STUDENT_EMAIL + " = " + email +" , " + STUDENT_PHONE_NUMBER + "=" + phone + " WHERE " + STUDENT_ID + " = " + ID +  " ;";
			return queryToReturn;
			
		}


		/**
		 * Get query string for getting full student info from student table
		 * by studentID.
		 * @param studentID
		 * @return Student Info query string.
		 */
		
		private static String getStudentInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " +  STUDENT_NAME+ ","+ STUDENT_ID +","+ SUBSCRIBER_NUMBER + " , " + STUDENT_EMAIL + " , " + STUDENT_PHONE_NUMBER + " , " + STUDENT_PASSWORD + " FROM " + STUDENT_TABLE + " WHERE " +
					STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}
		
		//SELECT StudentName,StudentID,StudentSubscriberNumber,Email,PhoneNumber FROM obl.student WHERE StudentID = 325;
		


		/**
		 * Get query string for
		 * when login request submitted returns user's indo
		 * @param UserID
		 * @param UserPassword
		 * @return account type, user name AND user status
		 */
		
		
		//SELECT AccountType,UserName,StatusMebership FROM obl.user WHERE UserID = 325;
		private static String LoginRequest (String UserID, String UserPassword) {
			UserID = "\'"+ UserID+ "\'";
			UserPassword = "\'"+ UserPassword+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + ","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP + "," + USER_ID +  " FROM " + USER_TABLE + " WHERE " +
					USER_ID + " = " + UserID + " AND "+ PASSWORD + " = " + UserPassword+ " ;";	
		
			return queryToReturn;
		}
		/**
		 * Get query string for
		 * getting book's info
		 * @param bookTitle
		 * @param bookAuthor
		 * @param bookSubject
		 * @param bookDescription
		 * @return catalog number,book's title ,book's shelf location AND availability status
		 */
		private static String getBookInfo(String bookTitle, String bookAuthor,String bookSubject, String bookDescription) {
			bookTitle = "\'"+ bookTitle+ "\'";
			bookAuthor = "\'"+ bookAuthor+ "\'";
			bookSubject = "\'"+ bookSubject+ "\'";
			String	bookDescription2 = bookDescription;
			bookDescription = "\'"+ bookDescription+ "\'";

			String queryToReturn = "SELECT " + CATALOG_NUMBER + ","+ BOOK_TITLE +","+ BOOK_LOCATION + "," + AVAILABLE_COPY +
					" FROM " + BOOK_TABLE + " WHERE " + BOOK_TITLE + "=" + bookTitle +" OR "+
					BOOK_AUTHOR + " = " + bookAuthor + " OR " + BOOK_SUBJECT  + " = " + bookSubject + " OR (" + BOOK_DESCRIPTION +" LIKE "+ "'%"+ bookDescription2+"%' "+ "AND "+bookDescription + " != "+ "''"+");";
			return queryToReturn;		
		}
		
		/**
		 * Get query string for
		 * getting borrowed book's info
		 * @param borrowerID
		 * @return borrowed book isbn , book's borrower ID ,borrow date, return date AND borrowed book's status
		 *//* 
		 * SELECT bor.ISBN, bor.borrowerID, bor.borrowDate, bor.returnDate, bor.borrowStatus, b.Author, b.Headline 
		 * FROM obl.borrowedbook bor, obl.book b 
		 * WHERE borrowerID='222' AND bor.ISBN = b.ISBN;
		 */
		static String getBorrowedBookInfo(String borrowerID) {
			borrowerID = "\'"+ borrowerID+ "\'";
			//bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "SELECT bor." + BORROWED_BOOK_ISBN  + ", bor."+ BORROWED_BOOK_BORROWER_ID + 
					", bor."+ BORROWED_BOOK_BORROW_DATE + ", bor." + BORROWED_BOOK_RETURN_DATE + ", bor." + BORROWED_BOOK_BORROW_STATUS + 
					", b." + BOOK_AUTHOR + ", b." + BOOK_TITLE + 
					" FROM " + BORROWED_BOOK_TABLE + " bor, " + BOOK_TABLE + " b " +
					" WHERE " + BORROWED_BOOK_BORROWER_ID + "=" + borrowerID + 
							" AND bor." + BORROWED_BOOK_ISBN + " = b." + BOOK_ID + " ;";				
			return queryToReturn;
		}

			/**
			 * Get query string for
			 * adding new borrowed book to borrowed book database and set it's info (book's ISBN, borrowerID, current date , return tate)
			 * @param bookID
			 * @param userID
			 * @param borrowDate
			 * @param returnDate
			 * @param borrowStatus
			 * @return
			 */
		private static String addBorrowedBook(String bookID, String userID, String borrowDate, String returnDate, String borrowStatus) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			borrowStatus = "\'"+ borrowStatus+ "\'";
			String queryToReturn = "INSERT INTO " + BORROWED_BOOK_TABLE + "(" + BORROWED_BOOK_ISBN +","+ BORROWED_BOOK_BORROWER_ID +","+ BORROWED_BOOK_BORROW_DATE +","+ BORROWED_BOOK_RETURN_DATE +","+ BORROWED_BOOK_BORROW_STATUS + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +","+ returnDate +","+ borrowStatus + ")" + ";";
			return queryToReturn;
		}
		
		/**
		 * Get query string for
		 * adding borrowed book to borrowed book history database and set it's info (ISBN, borrowerID, borrowDate, borrowTime)
		 * @param bookID
		 * @param userID
		 * @param borrowDate
		 * @return
		 */
		private static String addBorrowedBookHistory(String bookID, String userID, String borrowDate) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			
			String queryToReturn = "INSERT INTO " + BORROWED_BOOK_HISTORY_TABLE + "(" + BORROWED_BOOK_HISTORY_ISBN +","+ BORROWED_BOOK_USER_HISTORY_ID + "," + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + BORROWED_BOOK_BORROW_HISTORY_TIME + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +", CURRENT_TIME()"+ ")" + ";";
			return queryToReturn;
		}
		
		
		/**
		 * Get query string for
		 * when the book is returned delete book from "borrowed book" table
		 * delete book from borrowed book database
		 * @param bookID
		 * @return
		 */
		private static String deleteBorrowedBook(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "DELETE FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_ISBN +"=" + bookID + ";";
			return queryToReturn;
		}
		
		/**
		 * Get query string for
		 * setting book's availability status to "not available" AND update next return date
		 * @param bookID
		 * @return
		 */
		private static String setBookAvailabilityOFF(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + " SET " + AVAILABLE_COPY + " = 0, " +
					NEXT_RETURN_DATE + " = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL "+ BOOK_TABLE +"."+ BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y') "+
					" WHERE "+ BOOK_TABLE +"."+ BOOK_ID + " = " + bookID + " ;";
			return queryToReturn;
		}
		
		/**
		 * set availability status of a book to available AND update copie's next return date (null)
		 * @param bookID
		 * @return
		 */
		private static String setBookAvailabilityON(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + " SET " + AVAILABLE_COPY + " = 1, " + NEXT_RETURN_DATE + " = NULL " +
			" WHERE " + BOOK_TABLE +"."+ BOOK_ID + " = " + bookID + " ;";
			return queryToReturn;
		}
		
		
		
		/**
		 * set borrowed book history return date
		 * @param bookID
		 * @return
		 */
		private static String setReturnDateInBorrowedBookHistory(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_HISTORY_TABLE + 
					" SET " + BORROWED_BOOK_RETURN_HISTORY_DATE + " = DATE_FORMAT( CURRENT_DATE() , '%d.%m.%Y') " +
					" WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " = " + bookID + 
					" AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL;";
			return queryToReturn;
		}
		
		/**
		 * update subscriber status to Active if returned book was his only one that in delayed return status
		 * @param subscriberID
		 * @return
		 */
		private static String updateSubscriberStatusToActive(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "UPDATE " + USER_TABLE + " SET "+
					USER_TABLE + "." + STATUS_MEMBERSHIP + " = IF ((SELECT SUM(IF(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + " = " + subscriberID + 
					" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "='late',1,0)) AS SubscriberNumberOfNotReturnedBooks "+
			        " FROM " + BORROWED_BOOK_TABLE + " ) = 0 ,'Active','Frozen') " +
			        " WHERE " + USER_TABLE + "." + USER_ID + " =" + subscriberID +";";
			return queryToReturn;
		}
		
		/**
		 * get borrower ID
		 * @param bookID
		 * @return borrower ID
		 */
		private static String getBorrowerID(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "SELECT " + BORROWED_BOOK_BORROWER_ID + " FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + "=" + bookID +";";
			return queryToReturn;
		}
		
		
		
		/**
		 * updates borrowed book history AND user database
		 * set borrowed book history return date and 
		 * set user's status to be active if it was frozen just because of this book
		 * @param bookID
		 * @return
		 */
		//////////////////////////////problem////////////////////////
		private static String updateReturnDateAndUserStatus(String bookID)
		{
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = /*"SET SQL_SAFE_UPDATES = 0; " + */
			"UPDATE " + BORROWED_BOOK_HISTORY_TABLE + " , " + USER_TABLE +		
			" SET " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " = DATE_FORMAT( CURRENT_DATE() , \'%d.%m.%Y\'), " +
			USER_TABLE + "." + STATUS_MEMBERSHIP + " = IF ((SELECT SUM(IF(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + " = " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_USER_HISTORY_ID + 
				" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + " =\'late\',1,0)) AS SubscriberNumberOfNotReturnedBooks " +
				"FROM " + BORROWED_BOOK_TABLE + " ) = 0 ,\'Active\',\'Frozen\') " +	
			"WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " = " + bookID +
				" AND " + USER_TABLE + "." + USER_ID + " = " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_USER_HISTORY_ID +
				" AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL;";
			
			return queryToReturn;
		}

		
		/**
		 * when borrowing book ,returns subscriber's name for confirm book borrow window
		 * @param studentID
		 * @return subscriber's name
		 */
		private static String getStudentName(String studentID) {
			studentID = "\'"+ studentID+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + " FROM " + USER_TABLE + " WHERE " + USER_ID + " = " +  studentID + " AND " + STATUS_MEMBERSHIP + " = " + "'Active'" + " ;";
			return queryToReturn;		
		}
		
		
		/**
		 * when borrowing book get subscriber's name and borrow duration for book borrow window 
		 * return userName ,userStatus & book's borrow period
		 * @param studentID
		 * @param isbn
		 * @return userName ,userStatus & book's borrow period
		 */
		private static String getBorrowInfo(String studentID, String isbn) {
			studentID = "\'"+ studentID + "\'";
			isbn = "\'"+ isbn + "\'";			
			String queryToReturn = "SELECT " + USER_NAME + " , " + STATUS_MEMBERSHIP + " , " + BOOK_BORROW_PERIOD + " FROM " +
					USER_TABLE + " , " + BOOK_TABLE + " WHERE " + 
					USER_TABLE + "." + USER_ID + " = " +  studentID + " AND " + BOOK_TABLE + "." + BOOK_ID + " = " + isbn + " ;";
			return queryToReturn;		
		}
		
		
		/**
		 * when book return clicked update "book" database 
		 * ( copy is available ) and "borrowed book history" database 
		 * ( the date of the return and the status of the return , was it on time or late )
		 * @param bookID
		 * @param returnDate
		 * @return
		 */
		/////////////////////////////////problem//////////////////////////////////
		private static String setReturnedBookInfo(String bookID, String returnDate) {
			bookID = "\'"+ bookID+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			String one = "\'"+ 1+ "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_HISTORY_TABLE +","+ BOOK_TABLE + 
					" SET " + BORROWED_BOOK_HISTORY_TABLE +"."+ BORROWED_BOOK_RETURN_HISTORY_DATE +"="+ returnDate + "," + BORROWED_BOOK_HISTORY_TABLE + "," + BORROWED_BOOK_BORROW_HISTORY_STATUS + "=" + "(" +
						" SELECT " + BORROWED_BOOK_BORROW_STATUS +
							" FROM " + BORROWED_BOOK_TABLE +
								" WHERE " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + "=" +BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + ")" + "," +
					BOOK_TABLE + "." + AVAILABLE_COPY + "=" + one +	
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " AND " 
							+ BOOK_TABLE + "." + BOOK_ID + "=" + bookID + " AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL " + ";";
			return queryToReturn;
		}
		/**
		 * add reader card to reader card database table
		 * @param studentName
		 * @param studentID
		 * @param email
		 * @param phoneNumber
		 * @param studentPassword
		 * @param numOfStudents
		 * @return
		 */
		private static String addReaderCard(String studentName, String studentID, String email, String phoneNumber, String studentPassword, String numOfStudents  ) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			phoneNumber = "\'"+ phoneNumber+ "\'";
			email = "\'"+ email+ "\'";
			numOfStudents = "\'"+ numOfStudents+ "\'";
			String queryToReturn = "INSERT INTO " + STUDENT_TABLE + "(" + STUDENT_ID +","+ STUDENT_NAME +","+ STUDENT_PASSWORD +","+ STUDENT_PHONE_NUMBER +","+ STUDENT_EMAIL + "," + STUDENT_STATUS_MEMBERSHIP + "," + FREEZE +","+  SUBSCRIBER_NUMBER +")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ phoneNumber +","+ email + "," + "\'" + "Active"+ "\'" + "," + 0 +", "+ numOfStudents  +");";
			return queryToReturn;
		}
		/**
		 * add user to user database table
		 * @param studentID
		 * @param studentName
		 * @param studentPassword
		 * @return
		 */
		
		private static String addUser(String studentID, String studentName, String studentPassword) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			String queryToReturn = "INSERT INTO " + USER_TABLE + "(" + USER_ID +","+ USER_NAME +","+ PASSWORD +","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP +","+ FREEZE + ")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ "\'" + "Student"+ "\'" + "," + "\'" + "Active"+ "\'"+ "," + 0 + ")"+";";
			return queryToReturn;
		}
		
		
		/**
		 * System daily update of borrowed books borrow duration
		 * @return
		 */
		private static String increaseBorrowDuration() {
			String queryToReturn = "UPDATE " + BOOK_TABLE +","+ BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE +"."+ BOOK_BORROW_DURATION + "=" + "(" + BOOK_BORROW_DURATION + "+" + 1 + ")" +
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + ";";
			return queryToReturn;
		}
		
		/**
		 * System daily return delay update of not returned books
		 * @return
		 */
		static String increaseReturnDelay() {
			String queryToReturn = "UPDATE " + BOOK_TABLE +","+ BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE +"."+ BOOK_RETURN_DELAY + "=" + "(" + BOOK_RETURN_DELAY + "+" + 1 + ")" +
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
						" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "=" + "'late'" + ";";
			return queryToReturn;
		}
		
		/**
		 * update borrowStatus and subscriber status when book return delay
		 * @param today
		 * @return
		 */
		private static String updateSubscriberAndBookDelayStatus(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_TABLE +","+ USER_TABLE + 
					" SET " + BORROWED_BOOK_BORROW_STATUS +"='late' ," + USER_TABLE + "." + STATUS_MEMBERSHIP + "=" + "'Frozen'," + USER_TABLE + "." + USER_FREEZE_COUNTER + "=" + "(" + USER_FREEZE_COUNTER + "+1) "+
					" WHERE " + " STR_TO_DATE " + "(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "," + format + ")" + "<" + 
					" STR_TO_DATE " + "(" + today + "," + format + ")" + 
					" AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + 
					" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "='ok';";					
			return queryToReturn;
		}
		
		/**
		 * System daily check update borrowed book return delay
		 * @param today
		 * @return
		 */
		private static String updateBorrowedBookReturnDelay(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + "," + BORROWED_BOOK_TABLE +  
					" SET " + BOOK_TABLE + "." + BOOK_RETURN_DELAY + "= (" + BOOK_RETURN_DELAY + " + 1) "+ 
					" WHERE " + " STR_TO_DATE " + "(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "," + format + ")" + "<" + 
					" STR_TO_DATE " + "(" + today + "," + format + ")" + 
					" AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN +";";					
			return queryToReturn;
		}
		

		/**
		 * Extends borrowed book borrow duration
		 * @return
		 */
		private static String increaseBorrowedBookBorrowDuration() {
			String queryToReturn = "UPDATE " + BOOK_TABLE + "," + BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE + "." + BOOK_BORROW_DURATION + "= (" + BOOK_BORROW_DURATION + " +1) "+
					" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN +";";					
			return queryToReturn;
		}

		
		/**
		 * Count and return number of students in student table
		 * @param Mock
		 * @return number of students
		 */
		private static String numOfStudents( String Mock ) {
			
			String queryToReturn = "SELECT " + " COUNT(*) FROM " + STUDENT_TABLE + ";" ; 
			return queryToReturn;
		}
		//SELECT COUNT(*) FROM obl.student;
		
		
		/**
		 * Problematic Subscribers
		 */
		/**
		 * System daily check add new problematic subscriber
		 * @param subscriberID
		 * @return
		 */
		/////////////////////////////problem//////////////////////////////////////
		private static String addProblematicSubscriber(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "INSERT INTO " + PROBLEMATIC_SUBSCRIBERS_TABLE +"("+ subscriberID +")"+
						" SELECT " + USER_TABLE +"."+USER_ID + "," + USER_TABLE +"." + USER_NAME +
						" FROM " + USER_TABLE + " WHERE " + USER_TABLE + "." + USER_FREEZE_COUNTER + " >= 3;";
			return queryToReturn;
		}
		
		
	
		
		/**
		 * set subscribers status Active
		 * @param subscriberID
		 * @return
		 */
		private static String setSubscriberStatusActive(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "UPDATE " + USER_TABLE + " SET " + STATUS_MEMBERSHIP + "= 'Active'" +
					 " WHERE " + USER_TABLE +"." + USER_ID + "=" + subscriberID +");";
			return queryToReturn;
		}
		

		/**
		 * returns all problematic subscribers ID, Name and Status for problematic subscribers table
		 * @param MOCK
		 * @return all problematic subscribers info
		 */
		private static String getProblematicSubscriber(String MOCK) {
			String queryToReturn = "SELECT * FROM " +PROBLEMATIC_SUBSCRIBERS_TABLE+";";
			return queryToReturn;
		}
		
		/**
		 * System daily check
		 */
		/**
		 * System daily check returns ISBNs of books that can be prolonged
		 * @param today
		 * @return isbns of books that can be prolonged
		 */
		private static String findBooksThatCanBeProlonged(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT "+ BORROWED_BOOK_TABLE +"." + BORROWED_BOOK_ISBN + " FROM " + BORROWED_BOOK_TABLE + "," + BOOK_TABLE + 
					" WHERE STR_TO_DATE(" + BORROWED_BOOK_TABLE + "."+BORROWED_BOOK_RETURN_DATE+","+format+") < DATE_ADD(" + today + ", INTERVAL 7 DAY) "+ 
					" AND "+ BOOK_TABLE +"." + BOOK_BORROW_PERIOD + " = 14 AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN +
					" AND "+ BORROWED_BOOK_TABLE + "."+BORROWED_BOOK_BORROW_STATUS+"='ok' AND "+BOOK_TABLE+"." + BOOK_NUMBER_WANTEDTAG + "= 'Regular';";
			return queryToReturn;
		}
		


		
		
		
		
		
		
		
		/**
		 * Activity report queries
		 */
		
		/**
		 * return number of ACTIVE/LOCKED/FROZEN subscribers between given dates 
		 * @param fromDate
		 * @param toDate
		 * @param status
		 * @return number of ACTIVE/LOCKED/FROZEN subscribers  
		 */
		private static String subscriberCounterInSpecificStatus(String fromDate, String toDate, String status) {
		//	fromDate = "\'"+ fromDate+ "\'";
			//toDate = "\'"+ toDate+ "\'";
			//status = "\'"+ status+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT SUM(IF(STR_TO_DATE(" + "'" + fromDate + "'" + "," + format + ")" + 
					" BETWEEN STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_START_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_END_DATE + "," + format + ")" + 
		            
		            " OR STR_TO_DATE( " + "'" + toDate + "'" + "," + format + ")" +
					" BETWEEN STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_START_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_END_DATE + "," + format + ")" +  
		            
		            " OR STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_START_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            
					" OR STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_END_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            ", 1 , 0 )) AS NumberOfFrozenSubscribers " +
		            " FROM " + SUBSCRIBER_STATUS_HISTORY_TABLE + " WHERE " + 
		            SUBSCRIBER_STATUS_HISTORY_TABLE +"."+ SUBSCRIBER_STATUS_HISTORY_STATUS + "='" + status + "';";
			return queryToReturn;
		}
		
		/**
		 * return number of not returned books between given dates 
		 * @param fromDate
		 * @param toDate
		 * @return number of not returned books
		 */
		private static String notReturnBookCounter(String fromDate, String toDate) {	
		//	fromDate = "\'"+ fromDate+ "\'";
			//toDate = "\'"+ toDate+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT SUM(IF(STR_TO_DATE(" + "'" + fromDate + "'" + "," + format + ")" + 
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
		            
		            " OR STR_TO_DATE( " + "'" + toDate + "'" + "," + format + ")" +
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" +  
		            
		            " OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            
					" OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            ", 1 , 0 )) AS NumberOfDelayedReturn " +
		            " FROM " + BORROWED_BOOK_HISTORY_TABLE + " WHERE " + 
		            BORROWED_BOOK_HISTORY_TABLE +"."+ BORROWED_BOOK_BORROW_HISTORY_STATUS + "=" + "'late'" + ";";
			return queryToReturn;
		}
		/**
		 * returns number of borrowed books between given dates 
		 * @param fromDate
		 * @param toDate
		 * @return number of borrowed books
		 */
		private static String borrowedBookCounter(String fromDate, String toDate) {	
		//	fromDate = "\'"+ fromDate+ "\'";
			//toDate = "\'"+ toDate+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT SUM(IF(STR_TO_DATE(" + "'" + fromDate + "'" + "," + format + ")" + 
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
		            
		            " OR STR_TO_DATE( " + "'" + toDate + "'" + "," + format + ")" +
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" +  
		            
		            " OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            
					" OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            ", 1 , 0 )) AS NumberOfBorrowedBooks " +
		            " FROM " + BORROWED_BOOK_HISTORY_TABLE + ";";
			return queryToReturn;
		}
		
		/**
		 * insert data of new activity report to activity report table
		 * @param FromDate
		 * @param ToDate
		 * @param NumberofActiveSubscribers
		 * @param NumberofFrozenSubscribers
		 * @param NumberofLockedSubscribers
		 * @param NumberofLateReturnSubscribers
		 * @param NumberofBorrowedBooks
		 * @return
		 */
		private static String addActivityReport(String FromDate, String ToDate, String NumberofActiveSubscribers, String NumberofFrozenSubscribers, String NumberofLockedSubscribers, String NumberofLateReturnSubscribers, String NumberofBorrowedBooks) {
			FromDate = "\'"+ FromDate+ "\'";
			ToDate = "\'"+ ToDate+ "\'";
			NumberofActiveSubscribers = "\'"+ NumberofActiveSubscribers+ "\'";
			NumberofFrozenSubscribers = "\'"+ NumberofFrozenSubscribers+ "\'";
			NumberofLockedSubscribers = "\'"+ NumberofLockedSubscribers+ "\'";
			NumberofLateReturnSubscribers = "\'"+ NumberofLateReturnSubscribers+ "\'";
			NumberofBorrowedBooks = "\'"+ NumberofBorrowedBooks+ "\'";
			String queryToReturn = "INSERT INTO " + ACTIVE_REPORT_TABLE + " (" + ACTIVE_REPORT_FROM_DATE +","+ ACTIVE_REPORT_TO_DATE +","+ ACTIVE_REPORT_ACTIVE_SUBSCRIBER_AMOUNT + ","+ ACTIVE_REPORT_FROZEN_SUBSCRIBER_AMOUNT +","+ ACTIVE_REPORT_LOCKED_SUBSCRIBER_AMOUNT + "," + ACTIVE_REPORT_NUMBER_OF_LATE_RETURN_SUBSCRIBER +","+ ACTIVE_REPORT_NUMBER_OF_BORROWED_BOOKS +")" + 
					" SELECT " + FromDate +","+ ToDate +","+ NumberofActiveSubscribers +","+ NumberofFrozenSubscribers +","+ NumberofLockedSubscribers + ","+ NumberofLateReturnSubscribers +","+ NumberofBorrowedBooks +
					" WHERE NOT EXISTS (SELECT " + ACTIVE_REPORT_FROM_DATE +","+ ACTIVE_REPORT_TO_DATE + " FROM " + ACTIVE_REPORT_TABLE + " WHERE " + ACTIVE_REPORT_FROM_DATE + "=" + FromDate + " AND " + ACTIVE_REPORT_TO_DATE + "=" + ToDate + ");"; 
			return queryToReturn;
		}
		 
		/**
		 * returns the dates of saved activity reports
		 * @param mock
		 * @return
		 */
		private static String fillActivityReportComboBox(String mock) {
			String queryToReturn = "SELECT "+ ACTIVE_REPORT_FROM_DATE +","+ ACTIVE_REPORT_TO_DATE+" FROM " + ACTIVE_REPORT_TABLE +";";	
					return queryToReturn;
		}
		
		/**
		 * returns the info of saved activity report between given dates (between the "FromDate" to "ToDate")
		 * @param FromDate
		 * @param ToDate
		 * @return info of saved activity report between given dates 
		 */
		private static String getActivityReportInfo(String FromDate,String ToDate) {
			FromDate = "\'"+ FromDate+ "\'";
			ToDate = "\'"+ ToDate+ "\'";
			String queryToReturn = "SELECT  * FROM " + ACTIVE_REPORT_TABLE + " WHERE " + ACTIVE_REPORT_FROM_DATE +"="+FromDate+ " AND "+ACTIVE_REPORT_TO_DATE +" = " +  ToDate + ";";
					return queryToReturn;
		}
		
		

		/**
		 * Borrow report queries
		 */
		
		/**
		 * calculate average borrow duration
		 * @param wantedStatus
		 * @return
		 */
		private static String avgBorrowDuration(String wantedStatus) {
			wantedStatus = "\'"+ wantedStatus+ "\'";
			String queryToReturn = "SELECT BorrowDuration FROM("+
					" SELECT t1." + BOOK_NUMBER_WANTEDTAG +", AVG(t1." + BOOK_BORROW_DURATION + ") AS BorrowDuration " + 
			 	 " FROM (SELECT " + BOOK_NUMBER_WANTEDTAG +", SUM("+ BOOK_BORROW_DURATION +") AS BorrowDuration " +
	    	 		" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER +") AS t1 " +
			 " GROUP BY t1."+ BOOK_NUMBER_WANTEDTAG +") AS t2 " +
			 " WHERE t2."+ BOOK_NUMBER_WANTEDTAG + "=" + wantedStatus +";";
			return queryToReturn;
		}
		/**
		 * calculate median borrow duration
		 * @param wantedStatus
		 * @return median borrow duration
		 */
		private static String medianBorrowDuration(String wantedStatus) {
			wantedStatus = "\'"+ wantedStatus+ "\'";
			String queryToReturn = "SELECT AVG(dd.BorrowDuration) as median_val "+
			 	" FROM ( " +
			 		" SELECT t1.BorrowDuration , @rownum:=@rownum+1 AS `row_number`, @total_rows:=@rownum "+
			 		" FROM (SELECT @rownum:=0) r "+
			 		",(SELECT "+ BOOK_NUMBER_WANTEDTAG +", SUM("+BOOK_BORROW_DURATION+") AS BorrowDuration"+
			 			" FROM " + BOOK_TABLE +" GROUP BY "+ CATALOG_NUMBER+") AS t1 "+
			 		" WHERE t1.BorrowDuration is NOT NULL AND t1.WantedTag = " + wantedStatus +
			 		" ORDER BY t1.BorrowDuration "+
			 	") as dd "+
			 " WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		/**
		 * Return Delay report queries
		 */
		
		/**
		 * calculate average number of late returns for all the books
		 * @return  average number of late returns 
		 */
		private static String avgNumberOfLateReturnsAndAvgDelayDuration() {
			String queryToReturn = "SELECT " + "(t2.ReturnDelayCounter)/count(*) AS ReturnDelayCounter, AVG(t1.ReturnDelayDuration) AS ReturnDelayDuration " +
					 		" FROM ( "+
					    	 	" SELECT SUM(" + BOOK_RETURN_DELAY +") AS ReturnDelayDuration "+
					    	 	" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER +") AS t1, "+
					    	 	"(SELECT SUM(IF( " + BORROWED_BOOK_HISTORY_TABLE + "."+ BORROWED_BOOK_BORROW_HISTORY_STATUS + " = 'late', 1 , 0 )) AS ReturnDelayCounter "+
					    	" FROM " + BORROWED_BOOK_HISTORY_TABLE + " ) AS t2;";
			return queryToReturn;
		}
		
		
		/**
		 * calculate  average delay duration for all the books
		 * @return average delay duration
		 */
		private static String avgNumberOfLateReturns() {
			String queryToReturn = "SELECT (t2.ReturnDelayCounter)/count(*) AS ReturnDelayCounter " +
					 		" FROM ( "+
					    	 	" SELECT SUM(" + BOOK_RETURN_DELAY +") AS ReturnDelayDuration "+
					    	 	" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER +") AS t1, "+
					    	 	"(SELECT SUM(IF( " + BORROWED_BOOK_HISTORY_TABLE + "."+ BORROWED_BOOK_BORROW_HISTORY_STATUS + " = 'late', 1 , 0 )) AS ReturnDelayCounter "+
					    	" FROM " + BORROWED_BOOK_HISTORY_TABLE + " ) AS t2;";
			return queryToReturn;
		}
		

		/**
		 * calculate median delay duration for all the books
		 * @return median delay duration
		 */
		private static String avgDelayDuration() {
			String queryToReturn = "SELECT AVG(t1.ReturnDelayDuration) AS ReturnDelayDuration " +
					 		" FROM ( "+
					    	 	" SELECT SUM(" + BOOK_RETURN_DELAY +") AS ReturnDelayDuration "+
					    	 	" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER +") AS t1, "+
					    	 	"(SELECT SUM(IF( " + BORROWED_BOOK_HISTORY_TABLE + "."+ BORROWED_BOOK_BORROW_HISTORY_STATUS + " = 'late', 1 , 0 )) AS ReturnDelayCounter "+
					    	" FROM " + BORROWED_BOOK_HISTORY_TABLE + " ) AS t2;";
			return queryToReturn;
		}

		/**
		 * calculate median delay amount for all the books
		 * @param Mock
		 * @return median delay amount
		 */
		private static String medianDelayDuration() {
			String queryToReturn = "SELECT AVG(dd.ReturnDelayDuration) as median_val "+
					 	"FROM ( "+
					 		" SELECT t1.ReturnDelayDuration , @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum "+
					 		" FROM (SELECT @rownum:=0) r "+ 
					 			" ,(SELECT SUM(" + BOOK_RETURN_DELAY + ") AS ReturnDelayDuration"+
					 			" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER + ") AS t1 "+
					 		" WHERE t1.ReturnDelayDuration IS NOT NULL "+
					 		" ORDER BY t1.ReturnDelayDuration "+
					 	" ) as dd "+
					 	" WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		//////////from here///////////////
		/**
		 * 
		 * *************************************************************************************************************************************************/
		/**
		 * calculate book's delay duration and number of appearances of every delay duration 
		 * @param Mock
		 * @return table of delay durations and their number of appearances
		 */
		private static String medianDelayAmount(String Mock) {
			String queryToReturn = "SELECT AVG(dd2.ReturnDelayAmount) as median_val " +
					 " FROM ( "+
							" SELECT COUNT(*) AS ReturnDelayAmount, @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum " +
							" FROM (SELECT @rownum:=0) r "+
						        ",(SELECT " + BOOK_TABLE + "." + CATALOG_NUMBER + ","+ BOOK_TABLE + "." + BOOK_RETURN_DELAY +
								" FROM " + BORROWED_BOOK_HISTORY_TABLE + "," + BOOK_TABLE +
						        " WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + "=" + BOOK_TABLE +"." + BOOK_ID +" AND "+
						        BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_BORROW_HISTORY_STATUS + "= 'late') AS t1 " +
						        " GROUP BY t1.ReturnDelay ORDER BY COUNT(*) DESC "+
						        ") as dd2 " +
						" WHERE dd2.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		
		/**
		 * calculate for specific book delay duration it's number of appearances 
		 * @param bookName
		 * @return table of book's delay duration and it's number of appearances per duration
		 */
		private static String allBooksDelayDistribution(String Mock) {
			String queryToReturn = "SELECT t1." + BOOK_RETURN_DELAY + " ,COUNT(*) "+
					 " FROM (SELECT "+ BOOK_TABLE +"." + CATALOG_NUMBER +","+ BOOK_TABLE +"."+BOOK_RETURN_DELAY+ 
							 " FROM " + BORROWED_BOOK_HISTORY_TABLE + "," + BOOK_TABLE +
					         " WHERE " + BORROWED_BOOK_HISTORY_TABLE + "."+BORROWED_BOOK_HISTORY_ISBN +"=" +BOOK_TABLE+"."+BOOK_ID + " AND "+
					         BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late') AS t1 "+
					         " GROUP BY t1."+BOOK_RETURN_DELAY + " ORDER BY COUNT(*) DESC ;";
			return queryToReturn;
		}
		
		
		/**
		 * calculate for specific book delay duration it's number of appearances 
		 * @param bookName
		 * @return table of book's delay duration and it's number of appearances per duration
		 */
		private static String bookDelayDistribution(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String queryToReturn = "SELECT t1." + BOOK_RETURN_DELAY +",COUNT(*) "+
					 " FROM (SELECT "+ BOOK_TABLE+"."+BOOK_ID +" ,"+BOOK_TABLE+"."+BOOK_RETURN_DELAY +
							 " FROM " +BORROWED_BOOK_HISTORY_TABLE+","+BOOK_TABLE+
					         " WHERE "+BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE+"."+ BOOK_ID + " AND "+
					         BOOK_TABLE+"."+BOOK_TITLE +"="+ bookName +" AND "+
					         BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late') AS t1 "+
					         " GROUP BY t1."+BOOK_RETURN_DELAY+ " ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		/**
		 * return distinct book titles
		 * @param mock
		 * @return distinct book titles
		 */
		private static String getBookName(String mock) {
		
			String queryToReturn = "SELECT DISTINCT " + BOOK_TITLE+ " FROM " + BOOK_TABLE +";";
			return queryToReturn;
		}
		
		
		/**
		 * calculate delay amount and their appearance for delay amount distribution for all of the books 
		 * @param Mock
		 * @return delay amount and their appearance counter
		 */
		private static String allBooksDelayAmountDistribution(String Mock) {
			String queryToReturn = "SELECT t2.DelayAmount, COUNT(*) FROM "+
					" (SELECT t1."+CATALOG_NUMBER+" ,COUNT(*) AS DelayAmount " + 
					" FROM (SELECT " + BOOK_TABLE + "." + CATALOG_NUMBER + ","+BOOK_TABLE+"."+BOOK_RETURN_DELAY + 
					" FROM " + BORROWED_BOOK_HISTORY_TABLE + ", "+ BOOK_TABLE + 
					" WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + "=" +BOOK_TABLE + "." + BOOK_ID + " AND " + 
					BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_BORROW_HISTORY_STATUS + " = 'late') AS t1 " + 
					" GROUP BY t1." + CATALOG_NUMBER + " ORDER BY COUNT(*) DESC) AS t2 "+
					" GROUP BY t2.DelayAmount ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		/**
		 * calculate delay amount and their appearance for delay amount distribution for specific book 
		 * @param bookName
		 * @return delay amount and their appearance counter for specific book 
		 */
		private static String bookDelayAmountDistribution(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String queryToReturn = "SELECT t2.DelayAmount, COUNT(*) FROM "+
					" (SELECT t1."+BOOK_RETURN_DELAY + " ,COUNT(*) AS DelayAmount"+
							" FROM (SELECT "+BOOK_TABLE+"."+CATALOG_NUMBER +","+BOOK_TABLE+"."+BOOK_RETURN_DELAY +
							 " FROM " + BORROWED_BOOK_HISTORY_TABLE + "," + BOOK_TABLE +
					         " WHERE " +BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+ "="+BOOK_TABLE + "."+ BOOK_ID + " AND "+
					         BOOK_TABLE+"."+ BOOK_TITLE +"=" + bookName + " AND "+
					         BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late') AS t1 "+
					         " GROUP BY t1."+ BOOK_RETURN_DELAY + " ORDER BY COUNT(*) DESC) AS t2 "+
					         " GROUP BY t2.DelayAmount ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		
		/**
		 * calculate borrow duration and their appearance for borrow duration distribution by status
		 * @param status
		 * @return table of borrow duration and the count of this duration appearance
		 */
		private static String borrowDurationDistribution(String status) {
			status = "\'"+ status+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = 	"SELECT BorrowDuration , COUNT(*) FROM "+
			         " (SELECT DATEDIFF( IF(" + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NOT NULL	,STR_TO_DATE( "+ BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + "),CURRENT_DATE()),STR_TO_DATE( "+ BORROWED_BOOK_BORROW_HISTORY_DATE + ","+format+")) AS BorrowDuration "+
			        		 " FROM (SELECT "+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_DATE +" ,"+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_RETURN_HISTORY_DATE + 
			        		 " FROM "+ BORROWED_BOOK_HISTORY_TABLE +","+BOOK_TABLE+ 
			        		 " WHERE "+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE +"."+ BOOK_ID +
			        		 " AND " + BOOK_TABLE+"."+ BOOK_NUMBER_WANTEDTAG +"="+ status +") AS WantedBooks) AS maxWantedBook "+
			        		 " GROUP BY BorrowDuration ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		/**
		 * librarian implement subscriber manual prolongation by book's isbn
		 * @param isbn
		 * @return
		 */
		private static String librarianManualProlongation(String isbn) {
			isbn = "\'"+ isbn+ "\'";
			
					String queryToReturn ="UPDATE " + BOOK_TABLE + 
					" JOIN " + BORROWED_BOOK_TABLE + " ON " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE +"."+ BORROWED_BOOK_ISBN +
					" JOIN " + USER_TABLE + " ON " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + "=" + USER_TABLE +"." + USER_ID +
					" SET " + BOOK_TABLE + "." + NEXT_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y')," +
					BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y') " +
					    	"WHERE STR_TO_DATE(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + ", \"%d.%m.%Y\") < DATE_ADD( CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD +" DAY)"+ 
								" AND " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + "= 14 " + 
								" AND " + BOOK_TABLE + "." + BOOK_ID + "=" + isbn + " AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
								" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + " ='ok' " +
								" AND " + BOOK_TABLE + "." + BOOK_NUMBER_WANTEDTAG + " = 'Regular' "+ 
								" AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + 
								" AND " + USER_TABLE + "." + STATUS_MEMBERSHIP + " = 'Active';";
			return queryToReturn;
			
		}
		
		/**
		 * implement subscriber manual prolongation request by book's isbn
		 * @param isbn
		 * @return
		 */
		private static String subscriberManualProlongation(String isbn) {
			isbn = "\'"+ isbn+ "\'";
			
			String queryToReturn = "UPDATE " + BOOK_TABLE + 
					" JOIN " + BORROWED_BOOK_TABLE + " ON " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE +"."+ BORROWED_BOOK_ISBN +
					" JOIN " + USER_TABLE + " ON " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + "=" + USER_TABLE +"." + USER_ID +
					" SET " + BOOK_TABLE + "." + NEXT_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y')," +
					BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y') " +
					    	"WHERE STR_TO_DATE(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + ", \"%d.%m.%Y\") < DATE_ADD( CURRENT_DATE(), INTERVAL 8 DAY)"+ 
								" AND " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + "= 14 " + 
								" AND " + BOOK_TABLE + "." + BOOK_ID + "=" + isbn + " AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
								" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + " ='ok' " +
								" AND " + BOOK_TABLE + "." + BOOK_NUMBER_WANTEDTAG + " = 'Regular' "+ 
								" AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + 
								" AND " + USER_TABLE + "." + STATUS_MEMBERSHIP + " = 'Active';";
			return queryToReturn;
		}

		/**
		 * calculate average of delay amount
		 * @param bookName
		 * @return average of delay amount
		 */
		private static String bookAvgDelayAmount(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String queryToReturn = "SELECT SUM(IF(t1."+BORROWED_BOOK_BORROW_HISTORY_STATUS +"= 'late', 1 , 0 ))/COUNT(DISTINCT t1."+BOOK_ID+" ) "+ 	
					" FROM (SELECT " +BOOK_TABLE+"."+BOOK_ID +","+BOOK_TABLE+"."+BOOK_TITLE+","+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +
							" FROM "+BOOK_TABLE+ " CROSS JOIN "+BORROWED_BOOK_HISTORY_TABLE +
							" WHERE "+BOOK_TABLE+"."+BOOK_ID +"="+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN +
							" AND "+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE+"."+BOOK_ID +
							" AND "+ BOOK_TABLE+"."+BOOK_TITLE+"="+bookName+ " ) AS t1;";
			return queryToReturn;
		}
		
		/**
		 * calculate average of delay duration
		 * @param bookName
		 * @return average of delay duration
		 */
		private static String bookAvgDelay(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String queryToReturn = "SELECT SUM(DISTINCT t1."+BOOK_RETURN_DELAY+")/COUNT(DISTINCT t1."+BOOK_ID +" )  "+
					" FROM (SELECT "+BOOK_TABLE+"."+BOOK_ID +","+BOOK_TABLE+"."+BOOK_TITLE+","+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS+","+BOOK_TABLE+"."+BOOK_RETURN_DELAY+ 
							" FROM "+BOOK_TABLE+ " CROSS JOIN "+BORROWED_BOOK_HISTORY_TABLE +
							" WHERE "+BOOK_TABLE+"."+BOOK_ID +"="+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN +
							" AND "+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE+"."+BOOK_ID +
							" AND "+ BOOK_TABLE+"."+BOOK_TITLE+"="+bookName+ " ) AS t1;";
			return queryToReturn;
		}
		
		/**
		 * calculate median of return delay amount
		 * @param bookName
		 * @return median of return delay amount
		 */
		private static String bookMedianDelayAmount(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = 	"SELECT AVG(dd.ReturnDelayCounter) as median_val "+
					" FROM ( "+
							" SELECT t2.ReturnDelayCounter , @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum "+
							" FROM (SELECT @rownum:=0) r "+
							",(SELECT SUM(IF(t1."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late', 1 , 0 )) AS ReturnDelayCounter "+	
							" FROM (SELECT " +BOOK_TABLE+"."+BOOK_ID +","+BOOK_TABLE+"."+BOOK_TITLE+","+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +
							" FROM "+BOOK_TABLE+ " CROSS JOIN "+BORROWED_BOOK_HISTORY_TABLE +
							" WHERE "+BOOK_TABLE+"."+BOOK_ID +"="+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN +
							" AND "+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE+"."+BOOK_ID +
							" AND "+ BOOK_TABLE+"."+BOOK_TITLE+"="+bookName+ " ) AS t1 GROUP BY t1."+BOOK_ID+") AS t2"+
							" ORDER BY t2.ReturnDelayCounter "+
							") as dd "+
					" WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		
		/**
		 * calculate median of return delay duration
		 * @param bookName
		 * @return median of return delay duration
		 */
		private static String bookMedianDelay(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = 	"SELECT AVG(dd.ReturnDelays) as median_val "+
					" FROM ( "+
							" SELECT t2.ReturnDelays , @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum "+
							" FROM (SELECT @rownum:=0) r "+
							",(SELECT DISTINCT t1."+BOOK_RETURN_DELAY+ " AS ReturnDelays "+ 
							" FROM (SELECT "+BOOK_TABLE+"."+BOOK_ID +","+BOOK_TABLE+"."+BOOK_TITLE+","+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS+","+BOOK_TABLE+"."+BOOK_RETURN_DELAY+ 
							" FROM "+BOOK_TABLE+ " CROSS JOIN "+BORROWED_BOOK_HISTORY_TABLE +
							" WHERE "+BOOK_TABLE+"."+BOOK_ID +"="+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN +
							" AND "+ BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE+"."+BOOK_ID +
							" AND "+ BOOK_TABLE+"."+BOOK_TITLE+"="+bookName+ " ) AS t1) AS t2 "+
							" ORDER BY t2.ReturnDelays "+
							") as dd "+
					" WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}


		/**
		 * unlock subscriber and initialise FreezeCounter to 0 ,by ID
		 * @param subscriberID
		 * @return
		 */
		private static String unlockProblematicSubscriber(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "UPDATE "+PROBLEMATIC_SUBSCRIBERS_TABLE+
					 " JOIN "+USER_TABLE + " ON " + PROBLEMATIC_SUBSCRIBERS_TABLE+"."+PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID + "="+ USER_TABLE+"."+USER_ID +
					 " JOIN "+STUDENT_TABLE + " ON " + USER_TABLE+"."+USER_ID +"="+ STUDENT_TABLE+"."+STUDENT_ID+
					 " SET "+USER_TABLE+"."+STATUS_MEMBERSHIP +" = 'Active', "+
					 PROBLEMATIC_SUBSCRIBERS_TABLE+"."+PROBLEMATIC_SUBSCRIBERS_STATUS +" = 'Active', "+
					 STUDENT_TABLE+"."+STUDENT_STATUS_MEMBERSHIP +" = 'Active', "+
					 STUDENT_TABLE+"."+FREEZE +" = 0, "+
					 USER_TABLE+"."+USER_FREEZE_COUNTER +" = 0 "+
					 " WHERE "+PROBLEMATIC_SUBSCRIBERS_TABLE+"."+PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID +"="+ subscriberID+
					 " AND "+USER_TABLE+"."+USER_ID +"="+ subscriberID+
					 " AND "+STUDENT_TABLE+"."+STUDENT_ID +"="+ subscriberID+";"; 
			return queryToReturn;
		}

		
		
		/**
		 * delete subscriber by ID from problematic subscribers table 
		 * @param subscriberID
		 * @return
		 */
		private static String deleteProblematicSubscriber(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = " DELETE FROM "+PROBLEMATIC_SUBSCRIBERS_TABLE +" WHERE "+PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID+"="+subscriberID +" AND "+PROBLEMATIC_SUBSCRIBERS_STATUS +" ='Active';";
			return queryToReturn;
		}


		
		/**
		 * lock problematic subscriber by ID
		 * @param subscriberID
		 * @return
		 */
		private static String lockProblematicSubscriber(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "UPDATE "+PROBLEMATIC_SUBSCRIBERS_TABLE+
					 " JOIN "+USER_TABLE +" ON "+PROBLEMATIC_SUBSCRIBERS_TABLE+"."+PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID +"="+ USER_TABLE+"."+USER_ID+ 
					 " JOIN "+STUDENT_TABLE+" ON "+USER_TABLE+"."+USER_ID +"="+ STUDENT_TABLE+"."+STUDENT_ID+
					 " SET " +USER_TABLE+"."+STATUS_MEMBERSHIP +" = 'Locked', "+
					 PROBLEMATIC_SUBSCRIBERS_TABLE+"."+PROBLEMATIC_SUBSCRIBERS_STATUS +" = 'Locked', "+
					 STUDENT_TABLE+"."+STUDENT_STATUS_MEMBERSHIP +" = 'Locked' "+
					 " WHERE "+PROBLEMATIC_SUBSCRIBERS_TABLE+"."+PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID +"="+ subscriberID+
					 " AND "+USER_TABLE+"."+USER_ID +"="+ subscriberID+
					 " AND "+STUDENT_TABLE+"."+STUDENT_ID +"="+ subscriberID+";";   
			return queryToReturn;
		}
}
