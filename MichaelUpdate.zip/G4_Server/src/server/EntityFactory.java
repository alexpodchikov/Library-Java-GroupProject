package server;

import java.sql.ResultSet;
import java.util.ArrayList;

import common.*;

/**
 * Create object entity by string type name.
 *
 */
public class EntityFactory {

	
	public static Object getEntity(String entityName, ResultSet rs) throws Exception {
		Object objectToReturn = null;
		//System.out.println(" "+ entityName);
		try {
		switch(entityName.toLowerCase().trim()) {
		case "borrow_info":		
			rs.next();		
			ArrayList<String> info = new ArrayList<String>();		
			info.add(rs.getString(1));		
			info.add(rs.getString(2));
			info.add(rs.getString(3));
			objectToReturn = (Object)info;		
					break;
		case "student":
			rs.next();
			objectToReturn = new Student(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
		break;
		case "active_subscriber_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "frozen_subscriber_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "locked_subscriber_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
			
		case "delaying_book_return_subscriber_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "borrowed_book_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "activity_report_combobox":		
			rs.next();		
			ArrayList<String> comboboxInfo = new ArrayList<String>();		
			while(rs.next()) {
				
				String dates = rs.getString(1);
				dates+= " - "+rs.getString(2);
				comboboxInfo.add(dates);
			}		
			objectToReturn = (Object)comboboxInfo;		
			break;
		case "activity_report_show":		
			rs.next();		
			ArrayList<String> chosenReport = new ArrayList<String>();					
			chosenReport.add( new String(rs.getString(1)));	
			chosenReport.add( new String(rs.getString(2)));
			chosenReport.add( new String(rs.getString(3)));
			chosenReport.add( new String(rs.getString(4)));
			chosenReport.add( new String(rs.getString(5)));
			chosenReport.add( new String(rs.getString(6)));
			chosenReport.add( new String(rs.getString(7)));
			objectToReturn = (Object)chosenReport;		
			break;
		case "getbookname":
			ArrayList<BookName> booknames = new ArrayList<BookName>();
			while(rs.next()) {
				booknames.add(new BookName(rs.getString(1)));
			}
			System.out.println(booknames+ "12345");
			objectToReturn = (Object)booknames;
			break;
		case "get_problematic_students":
			ArrayList<ProblematicStudent> problemers = new ArrayList<ProblematicStudent>();
			while(rs.next()) {
				problemers.add(new ProblematicStudent(rs.getString(1),rs.getString(2),rs.getString(3)));
			}
			System.out.println(problemers+ "12345");
			objectToReturn = (Object)problemers;
			break;
		case "num_of_students":
			rs.next(); 
			objectToReturn = rs.getString(1); 
					//new ArrayList<String>() ;
					break;
		case "borrowedbookhistory":
			ArrayList<BorrowedBook> borrowedBooksHistory = new ArrayList<BorrowedBook>();
			while(rs.next()) {
				borrowedBooksHistory.add( new BorrowedBook(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
			}
			for (int i = 0; i <borrowedBooksHistory.size(); i++) {
			System.out.println(entityName + borrowedBooksHistory.get(i));	
			}
			objectToReturn=(Object)borrowedBooksHistory; 
			break;	
		
		case "book":
			ArrayList<Book> books = new ArrayList<Book>(); 
			while(rs.next()) {
			books.add( new Book(rs.getString(1),rs.getString(2),rs.getString(3),rs.getBoolean(4)));
			}
			for (int i = 0; i <books.size(); i++) {
			System.out.println(books.get(i));	
			}
			objectToReturn=(Object)books; 
			break;
		case "borrowedbook":
			ArrayList<BorrowedBook> borrowedbooks = new ArrayList<BorrowedBook>();
			while(rs.next()) {
				borrowedbooks.add( new BorrowedBook(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
			}		
			objectToReturn=(Object)borrowedbooks; 
			break;	
		case "user":
			rs.next();		
			objectToReturn = new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
			break;
		case "borrower_id":
			rs.next();		
			ArrayList<String> borrowerID = new ArrayList<String>();		
			borrowerID.add(rs.getString(1));
			objectToReturn = (Object)borrowerID;
			System.out.println("ninja2");
			break;
		case "avg_number_of_late_returns":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "avg_delay_duration":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;	
		case "median_delay_duration":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
			
		case "median_delay_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;		

		case "all_books_delay_distribution":
			
			ArrayList<Distribution> zebras= new ArrayList<Distribution>();	
			while(rs.next()) {				
				zebras.add( new Distribution((rs.getString(1)),(rs.getString(2))));		
				}
				System.out.println(zebras + "here5");
				objectToReturn =(Object)zebras;
				break;

		case "book_delay_distribution":
			ArrayList<Distribution> zebra= new ArrayList<Distribution>();	
			while(rs.next()) {				
				zebra.add( new Distribution((rs.getString(1)),(rs.getString(2))));		
				}
				objectToReturn =(Object)zebra;
				break;			
				
		
		case "all_books_delay_amount_distribution":
			ArrayList<Distribution> foxs= new ArrayList<Distribution>();	
			while(rs.next()) {				
				foxs.add( new Distribution((rs.getString(1)),(rs.getString(2))));		
				}
				objectToReturn =(Object)foxs;
				break;
			
		case "book_delay_amount_distribution":
			ArrayList<Distribution> fox= new ArrayList<Distribution>();
			while(rs.next()) {				
				fox.add( new Distribution((rs.getString(1)),(rs.getString(2))));		
			}
			objectToReturn =(Object)fox;
			break;
			
		case "average_wanted_book_borrow_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "average_regular_book_borrow_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "median_wanted_book_borrow_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;		
		case "median_regular_book_borrow_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "borrow_duration_distribution":
			ArrayList<Distribution> puma= new ArrayList<Distribution>();
			while(rs.next()) {				
			puma.add( new Distribution((rs.getString(1)),(rs.getString(2))));		
			}
			System.out.println(puma + "here5");
			objectToReturn =(Object)puma;
			break;
		case "book_median_delay_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "book_median_delay":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "book_avg_delay_amount":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;		
		case "book_avg_delay":
			rs.next();
			objectToReturn = new String(rs.getString(1));
			break;
		case "editbook":
	        rs.next();
			ArrayList<String> bookiInfo = new ArrayList<String>();		
			bookiInfo.add(rs.getString(1));		// BOOK_TITLE
			bookiInfo.add(rs.getString(2));		// BOOK_AUTHOR
			bookiInfo.add(rs.getString(3));		// (MAX) ISBN
			bookiInfo.add(rs.getString(4));		// CATALOG_NUMBER
			bookiInfo.add(rs.getString(5));		// BOOK_EDITION_NUMBER
			bookiInfo.add(rs.getString(6));		// BOOK_PRINT_DATE
			bookiInfo.add(rs.getString(7));		// BOOK_BORROW_PERIOD
			bookiInfo.add(rs.getString(8));		// BOOK_NUMBER_WANTEDTAG
			bookiInfo.add(rs.getString(9));		// BOOK_PURCHASE_DATE
			bookiInfo.add(rs.getString(10));	// BOOK_SUBJECT	
			bookiInfo.add(rs.getString(11));	// BOOK_LOCATION	
			bookiInfo.add(rs.getString(12));	// BOOK_NUMBER_COPIES
			bookiInfo.add(rs.getString(13));	// BOOK_DESCRIPTION
			objectToReturn = (Object)bookiInfo;		
			break;	
		
		case "waiting_list_info":
	        rs.next();
			ArrayList<Integer> waitingInfo = new ArrayList<Integer>();			
			waitingInfo.add(rs.getInt(1));		// MAX(PlaceInLine)		obl.waiting_list  	
			waitingInfo.add(rs.getInt(2));		// NumberCopies			obl.book	
			objectToReturn = (Object)waitingInfo;	
			break;
		default:
			System.out.println("its an update");
			return true;
		
		}
		return objectToReturn;
		}
		catch(Exception e) {
			return null;
		}
	}
}
