package common;
import java.io.Serializable;

public class BorrowedBook  implements Serializable{

	private static final long serialVersionUID = 511837015879654821L;
	public String isbn;
	public String borrowerID;		
	public String borrowDate;
	public String returnDate;
	public String borrowStatus;
	public String author;
	public String headline;
	
	public BorrowedBook(String ISBN) {		
		this.isbn = ISBN;
	}
	
	public BorrowedBook(String ISBN ,String  BorrowerID ,  String BorrowDate,String ReturnDate, String BorrowStatus) {		
		
		this.isbn = ISBN;
		this.borrowerID = BorrowerID;	
		this.borrowDate = BorrowDate;
		this.returnDate = ReturnDate;
		this.borrowStatus = BorrowStatus;

	}
	
	
	public BorrowedBook(String ISBN ,String  BorrowerID ,  String BorrowDate,String ReturnDate, String BorrowStatus, String author, String headline) {		
		
		this.isbn = ISBN;
		this.borrowerID = BorrowerID;	
		this.borrowDate = BorrowDate;
		this.returnDate = ReturnDate;
		this.borrowStatus = BorrowStatus;
		this.author = author;
		this.headline = headline;

	}

	
	public String getISBN() {
		return isbn;
	}
	public void setISBN(String ISBN) {
		this.isbn = ISBN;
	}
	
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}
	
	public String getBorrowerID() {
		return borrowerID;
	}
	public void setBorrowerID(String BorrowerID) {
		this.borrowerID = BorrowerID;
	}
	public String getBorrowDate() {
		return borrowDate;
	}
	public void setBorrowDate(String borrowDate) {
		this.borrowDate = borrowDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getBorrowStatus() {
		return borrowStatus;
	}
	public void setBorrowStatus(String borrowStatus) {
		this.borrowStatus = borrowStatus;
	}

	@Override
	public String toString() {
		return borrowerID;
	}
	
} 
