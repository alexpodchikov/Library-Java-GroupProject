package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import common.ClientToServerMessage;
import common.EQueryOption;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class EditBookController implements FeedbackIF, Initializable {
	
	 private ConnectionController client;
	 private static Integer REGULAR_BORROW_PERIOD = 14;
	 private static Integer WANTED_BORROW_PERIOD = 3;
	 private ArrayList<String> globalBookiInfo;
	 
	 @FXML
	 private ChoiceBox<String> WantedTagChoiceBox;
	
	 @FXML
	 private TextField 	HeadlineTextField, AuthorTextField, ISBNTextField, CatalogNumberTextField, 
	 					EditionNumberTextField, PrintDateTextField, SubjectTextField, PurchaseDateTextField, 
	 					NumberCopiesTextField, BorrowPeriodTextField, DescriptionTextField, ShelfLocationTextField;
	
		/**
		 * Set book to be edited details 
		 * @param bookiInfo
		 */
	public void setBookInfo(ArrayList<String> bookiInfo) throws IOException {
		
		globalBookiInfo = bookiInfo;
		
 		HeadlineTextField.setText(bookiInfo.get(0));
		AuthorTextField.setText(bookiInfo.get(1));
		CatalogNumberTextField.setText(bookiInfo.get(3));
		EditionNumberTextField.setText(bookiInfo.get(4));
		PrintDateTextField.setText(bookiInfo.get(5));
		WantedTagChoiceBox.setValue(bookiInfo.get(7));
		PurchaseDateTextField.setText(bookiInfo.get(8));
		SubjectTextField.setText(bookiInfo.get(9));
		ShelfLocationTextField.setText(bookiInfo.get(10));
		NumberCopiesTextField.setText(bookiInfo.get(11));
		DescriptionTextField.setText(bookiInfo.get(12));
		
	}	
	
	 /**
	  * Go to previous screen
	  * @param event
	  */
	@FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Inventory Management");
		 
	}
	
	/**
	 * Edit book confirmed
	 * Initiate query to update book database
	 * @param event
	 * @throws Exception
	 */
	 @FXML
	 void SaveClick(ActionEvent event) throws Exception  {
		 
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(globalBookiInfo.get(3));					// catalogNumber		
		String wantedTag = WantedTagChoiceBox.getValue();
		SetParameters.add(wantedTag);								// wantedTag
		if (wantedTag.equals("Regular"))
			SetParameters.add(REGULAR_BORROW_PERIOD.toString());	// borrowPeriod = 14
		else
			SetParameters.add(WANTED_BORROW_PERIOD.toString()); 	// borrowPeriod = 3
		SetParameters.add(SubjectTextField.getText());				// subject
		SetParameters.add(ShelfLocationTextField.getText());		// shelfLocation
		SetParameters.add(DescriptionTextField.getText());			// description
		
		// Check that information wasn't deleted by accident
		if (SubjectTextField.getText().isEmpty() || ShelfLocationTextField.getText().isEmpty() 
				|| DescriptionTextField.getText().isEmpty()) {
				
			Screens.showErrorDialog("Error","Text Field cannot be empty", "Please check info");
			return;
		}// Check
		
		if (Screens.showConfirmationDialog("Confirmation", "Edit Book", "Please confirm saving changes.")){
			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = null;
				client.clientF = this;
				ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.UPDATE_BOOK, SetParameters, null);
			    client.handleMessageFromClientUI(messageToSend);		
				}
			catch (IOException e) {
				e.printStackTrace();
			
			}
		
		}// if
		
	}// SaveClick
	
		/**
		 * Handles feedback for update queries 
		 */
	@Override
	public void feedback(Object msg)
	{
		Screens.singleFeedback(msg);						
	}

	/**
	 * Initialize default data for editing a book
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		 WantedTagChoiceBox.getItems().removeAll(WantedTagChoiceBox.getItems());
		 WantedTagChoiceBox.getItems().addAll("Regular","Wanted");
		// WantedTagChoiceBox.getSelectionModel().select("Regular");
		 
	}
	
}