package client;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import common.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * 
 * Controller responsible for reader borrow history
 *
 */
public class ReaderBorrowHistoryWindowController implements ChatIF, FeedbackIF{
	
    private ConnectionController client;
    private ArrayList<BorrowedBook> borrowedBooks;
    private ObservableList<BorrowedBook> observableBooks;
    
	@FXML
	private TextField prolongationTextFieldID;
	@FXML
    private TableView<BorrowedBook> BorrowHistoryViewID;	 
	@FXML
    private TableColumn<BorrowedBook, String> ISBNID;
    @FXML
    private TableColumn<BorrowedBook, String> BorrowerID;
    @FXML
    private TableColumn<BorrowedBook, String> BorrowDateID;
    @FXML
    private TableColumn<BorrowedBook, String> ReturnDateID;   
    @FXML
    private TableColumn<BorrowedBook, String> ReturnStatusID;
    @FXML
    private Button SubmitButtonId;
    @FXML
    private Label askProlongationTextID;
    
/**
 * 
 * @param userID get userID from previous controller
 * The method send userId to server to get borrow history
 *  
 */
	public void setUserBorrowHistory(String userID) {
		
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(userID);
		

		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;		
			String user = client.getUserKind();
			
			if (user.toLowerCase().trim().equals("student")) {
				System.out.println("this user isssss " + user);
				SubmitButtonId.setVisible(false);
				askProlongationTextID.setVisible(false);
				prolongationTextFieldID.setVisible(false);
			}
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BOOK_BORROW_HISTORY, SetParameters,"borrowedbookhistory");
		    client.handleMessageFromClientUI(messageToSend);

		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 * @param event button clicked
	 * @throws IOException
	 * The method send isbn to server according to user
	 * 
	 */
    @FXML
	private void SubmitClicked(ActionEvent event) throws IOException {
    
    	boolean isbnExist =false;
        String borrowDate,returnDate;
        boolean IsWanted = false;

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
        	String prolongationISBN = prolongationTextFieldID.getText();
        	client = ConnectionController.getConnectionController(); 
        	client.clientUI = null;
        	client.clientF = this;	
        	for (int i = 0; i < borrowedBooks.size(); i++) {
    			if(borrowedBooks.get(i).getISBN().equals(prolongationISBN)) {
    				isbnExist = true;
    				borrowDate=borrowedBooks.get(i).getBorrowDate();
    				returnDate=borrowedBooks.get(i).getReturnDate();
    				Date firstDate = null;
    				try {
    					firstDate = sdf.parse(borrowDate);

    				} catch (ParseException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    			    Date secondDate = null;
    				try {
    					secondDate = sdf.parse(returnDate);
    				} catch (ParseException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}

    				long diffInMillies = (Math.abs(secondDate.getTime() - firstDate.getTime())/86400000)-1;
    				if (diffInMillies<=3)
    					IsWanted=true;
    			}
    		}
            if(prolongationISBN.isEmpty()) {
      	    	Screens.showErrorDialog("Error","Cannot be empty for prolongation ISBN", "Please check your info!");
      	    	return;
      	    }
           /* if(	client.getStatus().toLowerCase().trim().equals("frozen")) {
      	    	Screens.showErrorDialog("Error","Your acount is Frozen", "You are not able to extend borrowing period because of your status!");
      		    	return;	
      	    }*/
           if(IsWanted) {
            	Screens.showErrorDialog("Error","Book prolongation failed", "The book is 'wanted' and cannot be borrowed");
    		    	return;	
            }
        	 if(!isbnExist) {
       	    	Screens.showErrorDialog("Error","Book prolongation failed", "The book is not in student's borrowed books list!");
       		    	return;	
       	    }
        	ArrayList<String> SetParameters = new ArrayList<String>();
    		SetParameters.add(prolongationISBN);	
      	
      	   
      	    switch (client.getUserKind().toLowerCase().trim()) {
    		case "student":							
    			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SUBSCRIBER_MANUAL_PROLONGATION, SetParameters, null);			    
    			client.handleMessageFromClientUI(messageToSend);
    			break;
    		case "librarian":
    			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
    			client.handleMessageFromClientUI(messageToSend2);
    			break;
    		case "librarymanager":
    			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
    			client.handleMessageFromClientUI(messageToSend3);
    			break;
    		default:
    			System.out.println("There is no such user");
    		}				
  	}
	 /**
	  * 
	  * @param event button clicked
	  * Back to previous screen
	  */
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("User Profile");	 
	}
	 /**
	  *  @param message server response 
	  *  the method gets response message from server and sets it to text fields
	  *  
	  */
	 @Override
	 public void display(Object message) {
		 if (message == null) 
			System.out.println("> Server returned null");
		else 
			System.out.println("> Server returned: "+message.toString());
			
		borrowedBooks = (ArrayList<BorrowedBook>)message;	
		observableBooks = FXCollections.observableArrayList(borrowedBooks); 
		BorrowHistoryViewID.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		ISBNID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("ISBN"));
		BorrowerID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowerID"));	
		BorrowDateID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowDate"));
		ReturnDateID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("returnDate"));
		ReturnStatusID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowStatus"));
		BorrowHistoryViewID.setItems(observableBooks);
					
	}
		

	@Override
	public void feedback(Object msg) 
	{			
		Screens.submitFeedback(msg);
	}
		
}
