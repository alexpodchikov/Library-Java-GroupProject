
package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.BookName;
import common.ChatIF;
import common.ClientToServerMessage;
import common.Distribution;
import common.EQueryOption;
import common.Student;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * 
 * @author group 4 
 * taking care of activity report.
 *
 */
public class LateReturnReportController implements ChatIF,Initializable {
	
	@FXML
	private TextField AverageAmountTextField;
	@FXML
	private TextField AverageDurationTextField;
	@FXML
	private TextField MedianAmountTextField;
	@FXML
	private TextField MedianDurationTextField;		
	@FXML
	private ComboBox<BookName> ComboBoxBookID=new ComboBox<BookName>();
	ObservableList<BookName> list;
	private ConnectionController client;
	int counter = 1;
	boolean durationCounter= false;
	boolean comboboxflag=false;
	@FXML
	private Label Amount1ID;
	@FXML
	private Label Amount2ID;
	@FXML
	private Label Amount3ID;
	@FXML
	private Label Amount4ID;
	@FXML
	private Label Amount5ID;
	@FXML
	private Label Amount6ID;
	@FXML
	private Label Amount7ID;
	@FXML
	private Label Amount8ID;
	@FXML
	private Label Amount9ID;
	@FXML
	private Label Amount10ID;
	@FXML
	private Label Amount11ID;
	@FXML
	private Label Amount12ID;
	@FXML
	private Label Amount13ID;
	@FXML
	private Label Amount14ID;
	@FXML
	private Label Amount15ID;
	@FXML
	private Label Amount16ID;
	@FXML
	private Label Amount17ID;
	@FXML
	private Label Amount18ID;
	@FXML
	private Label Amount19ID;
	@FXML
	private Label Amount20ID;
	 /**
	  * going back to previous screen
	  * @param event back button clicked
	  */
	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Report Window");	 
	}
	 /**
	  * receive the choice from combo box and send the result to book return report
	  * @param event submit button clicked
	  */
	 @FXML
	 void submitClicked(ActionEvent event) {
		 
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
				client = ConnectionController.getConnectionController();
			    client.setPrevScene(curr);
			    String bookname = ComboBoxBookID.getValue().toString();
			  	FXMLLoader loader= new FXMLLoader();
			  	
				Stage stage = client.getStage();
		        Parent root = loader.load(Main.class.getResource("/client/BookReturnReport.fxml").openStream()); 
					
		        BookReturnReportController controller = loader.getController();
		    	controller.initDetails(bookname);
		       	Scene scene = new Scene(root);	
				stage.setTitle("Book Return Report");
				stage.setScene(scene);
				stage.show(); 
		
				}
			catch (IOException e) {
				e.printStackTrace();
			}	}
	 
/**
 * call to init()
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	try {
		init();
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	 /**
	  * sends all the queries
	  * @throws IOException in case the connection goes wrong
	  */
	 public void init() throws IOException {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add("vasya");
			 ArrayList<String> SetComboBox = new ArrayList<String>();	
			 SetComboBox.add("vasya");
			ClientToServerMessage messageToSendcombo = new ClientToServerMessage(EQueryOption.GET_BOOK_NAMES, SetComboBox, "getbookname");			    
			client.handleMessageFromClientUI(messageToSendcombo);
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.AVG_LATE_RETURN_AMOUNT, SetParameters, "avg_number_of_late_returns");			    
			client.handleMessageFromClientUI(messageToSend);
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.AVG_LATE_RETURN_DURATION, SetParameters, "avg_delay_duration");			    
			client.handleMessageFromClientUI(messageToSend2);
			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.MEDIAN_DELAY_AMOUNT, SetParameters, "median_delay_amount");			    
			client.handleMessageFromClientUI(messageToSend3);
			ClientToServerMessage messageToSend4 = new ClientToServerMessage(EQueryOption.MEDIAN_DELAY_DURATION, SetParameters, "median_delay_duration");			    
			client.handleMessageFromClientUI(messageToSend4);
			ClientToServerMessage messageToSend5 = new ClientToServerMessage(EQueryOption.ALL_BOOKS_DELAY_AMOUNT_DISTRIBUTION, SetParameters, "all_books_delay_amount_distribution");			    
			client.handleMessageFromClientUI(messageToSend5);
			ClientToServerMessage messageToSend6 = new ClientToServerMessage(EQueryOption.ALL_BOOKS_DELAY_DISTRIBUTION, SetParameters, "all_books_delay_distribution");			    
			client.handleMessageFromClientUI(messageToSend6);
		
	 }
	 /**
	  * returns the answer from server and show it the right place
	  */
	 @Override
		public void display(Object message) {
			if (message == null) {
				System.out.println("> Server returned null");
			}
			Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	                try{
	                	 if (!comboboxflag) {
	                		 if( message instanceof ArrayList<?>) {
	                		 
	                			 ArrayList<BookName> booknames = (ArrayList<BookName>)message;
	                			 list = FXCollections.observableArrayList(booknames);
	                			 ComboBoxBookID.setItems(list);
	                		 	        comboboxflag = !comboboxflag;        		 
	                		 }
	                		 
	                	 }  	
	                	showStage(message);

	                }
	                catch(Exception e) {
	                	System.out.println("Invoke later failed..");
	                	e.printStackTrace();
	                }
	            }
	            private void showStage(Object object) throws Exception {
	   	try {
	   		client = ConnectionController.getConnectionController();
	if( message instanceof ArrayList<?>) {
				
				ArrayList<Distribution> distribution = (ArrayList<Distribution>)message;
				for (int i = 0; i < distribution.size(); i++) {
					
					String temp=null;
					Integer sum=0,num=0;
					String percent = distribution.get(i).getPercent();
					String count = distribution.get(i).getCount();
					System.out.println("counter state : " + durationCounter);
					switch(percent){ 
					case "0" :
					case "1":
					case "2":
						if(!durationCounter ) { 
							
							temp = Amount1ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							System.out.println("kova" + temp);
							Amount1ID.setText(temp);
						}	
						else { 
						
							temp = Amount11ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							System.out.println(temp + "ninjas123");
							Amount11ID.setText(temp);
						}
					break;
					
					case "3" :
					case "4":
					case "5":
						if(!durationCounter ) { 
							temp = Amount2ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount2ID.setText(temp);
						}	
						else { 
							temp = Amount12ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount12ID.setText(temp);
						}				
					break;
					case "6" :
					case "7":
					case "8":
						if(!durationCounter ) { 
							temp = Amount3ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount3ID.setText(temp);
						}	
						else { 
							temp = Amount13ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount13ID.setText(temp);
						}				
					break;
					case "9" :
					case "10":
					case "11":
						if(!durationCounter ) { 
							temp = Amount4ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount4ID.setText(temp);
						}	
						else { 
							temp = Amount14ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount14ID.setText(temp);
						}				
					break;
					case "12" :
					case "13":
					case "14":
						if(!durationCounter ) { 
							temp = Amount5ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount5ID.setText(temp);
						}	
						else { 
							temp = Amount15ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount15ID.setText(temp);
						}				
					break;
					case "15" :
					case "16":
					case "17":
						if(!durationCounter ){ 
							temp = Amount6ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount6ID.setText(temp);
						}	
						else { 
							temp = Amount16ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount16ID.setText(temp);
						}				
					break;
					case "18" :
					case "19":
					case "20":
						if(!durationCounter ) { 
							temp = Amount7ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount7ID.setText(temp);
						}	
						else { 
							temp = Amount17ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount17ID.setText(temp);
						}				
					break;
					case "21" :
					case "22":
					case "23":
						if(!durationCounter ) { 
							temp = Amount8ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount8ID.setText(temp);
						}	
						else { 
							temp = Amount18ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount18ID.setText(temp);
						}
						break;
					case "24" :
					case "25":
					case "26":
						if(!durationCounter ) { 
							temp = Amount9ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount9ID.setText(temp);
						}	
						else { 
							temp = Amount19ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount19ID.setText(temp);
						}				break;
					case "27" :
					case "28":
					case "29":
						if(!durationCounter ) { 
							temp = Amount10ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount10ID.setText(temp);
						}	
						else { 
							temp = Amount20ID.getText();
							sum = Integer.parseInt(temp);
							num = Integer.parseInt(count);
							sum+=num;
							temp = sum.toString();
							Amount20ID.setText(temp);
						}				
						break;
						
					default:
						 System.out.println("youre gone too far");
					}

				
			}
				
			durationCounter = !durationCounter;
			}
	 		else {
	 			System.out.println(message.toString()  + "cheetah");
				switch (counter) {
				case 1:	
					AverageAmountTextField.setText((String)message);
					counter++;
				break;
				case 2:
					AverageDurationTextField.setText((String)message);
					counter++;
				break;	
				
				case 3:
					MedianDurationTextField.setText((String)message);
					counter++;
				break;
				case 4:	
					MedianAmountTextField.setText((String)message);
					counter++;
				break;
				default: System.out.println("youre gone too far");
				}	
			}
		}
		
		catch (IOException e) { 
			e.printStackTrace();
		}
		  
				
	}
		 });
			
		}	

}