package client;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
/**
 * 
 * Controller responsible for student capabilities as a user
 *
 */
public class SubscriberMainScreenController  implements ChatIF, FeedbackIF{

    private ConnectionController client;
    
    private ArrayList<BorrowedBook> borrowedBooks;
    private ObservableList<BorrowedBook> observableBooks;
    
	@FXML
    private TableView<BorrowedBook> studentTableViewID;	 
	@FXML
    private TableColumn<BorrowedBook, String> ISBNColID;
    @FXML
    private TableColumn<BorrowedBook, String> titleColD;
    @FXML
    private TableColumn<BorrowedBook, String> authorColD;
    @FXML
    private TableColumn<BorrowedBook, String> borrowDateIColD;
    @FXML
    private TableColumn<BorrowedBook, String> returnDateColID;    
    @FXML
    private TableColumn<BorrowedBook, String> borrowStatusColID;
	@FXML
	private TextField prolongationTextFieldID;
	@FXML
	private TextField userNameTextFieldID;
	String id=null;

	public void setUserBooksInfo(String UserID ) {
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(UserID);
		id = UserID;
		
		try {
			client = ConnectionController.getConnectionController();
			userNameTextFieldID.setText(client.getName());
			client.clientUI = this;
		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BORROWED_BOOK_INFO, SetParameters,"borrowedbook");
		    client.handleMessageFromClientUI(messageToSend);			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
 
	}
	
	/**
	 * 
	 * @param event button clicked
	 * the method send to server request to get a book info
	 */
	@FXML
	private void BookSearchClick(ActionEvent event) { 
		
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
	    	client.setPrevScene(curr);
	    	Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		} 
	}
	
	/**
	 * 
	 * @param event button clicked
	 * @throws Exception  
	 * The method open profile controller (fxml) and sends to it user id
	 */
	@FXML
	private void ProfileClicked(ActionEvent event) throws Exception {
	
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
        	FXMLLoader loader= new FXMLLoader();
			client = ConnectionController.getConnectionController();
	    	client.setPrevScene(curr);
	    	Stage stage = client.getStage();
        	Parent root = loader.load(Main.class.getResource("/client/UserProfile.fxml").openStream());	        				
	    	UserProfileController controller =  loader.getController();
    		controller.setUserInfo(client.getUserID());
    		Scene scene = new Scene(root);	
			stage.setTitle("User Profile");
			stage.setScene(scene);
			stage.show();
		
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @param event button clicked
	 * @throws IOException
	 * The method send isbn to server according to user
	 * 
	 */
    @FXML
	private void SubmitClicked(ActionEvent event) throws IOException {
    boolean isbnExist =false;
    String borrowDate,returnDate;
    boolean IsWanted = false;

    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
    	String prolongationISBN = prolongationTextFieldID.getText();
    	client = ConnectionController.getConnectionController();
    	client.clientUI = null;
    	client.clientF = this;	
    	for (int i = 0; i < borrowedBooks.size(); i++) {
			if(borrowedBooks.get(i).getISBN().equals(prolongationISBN)) {
				isbnExist = true;
				borrowDate=borrowedBooks.get(i).getBorrowDate();
				returnDate=borrowedBooks.get(i).getReturnDate();
				Date firstDate = null;
				try {
					firstDate = sdf.parse(borrowDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    Date secondDate = null;
				try {
					secondDate = sdf.parse(returnDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
				long diffInMillies = (Math.abs(secondDate.getTime() - firstDate.getTime())/86400000)-1;
				if (diffInMillies<=3)
					IsWanted=true;
			}
		}
        if(prolongationISBN.isEmpty()) {
  	    	Screens.showErrorDialog("Error","Cannot be empty for prolongation ISBN", "Please check your info!");
  	    	return;
  	    }
        if(	client.getStatus().toLowerCase().trim().equals("frozen")) {
  	    	Screens.showErrorDialog("Error","Your acoount is Frozen", "You are not able to extend borrowing period because of your status!");
  		    	return;	
  	    }
        if(IsWanted) {
        	Screens.showErrorDialog("Error","Book prolongation failed", "The book is 'wanted' and cannot be borrowed");
		    	return;	
        }
    	 if(!isbnExist) {
   	    	Screens.showErrorDialog("Error","Book prolongation failed", "The book is not in your borrowed books list!");
   		    	return;	
   	    }
    	ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(prolongationISBN);	
  	
  	   
  	    switch (client.getUserKind().toLowerCase().trim()) {
		case "student":							
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SUBSCRIBER_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend);
			break;
		case "librarian":
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend2);
			break;
		case "librarymanager":
			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend3);
			break;
		default: 
			System.out.println("There is no such user");
		}		
  	    setUserBooksInfo(id);
  	}
	
	/**
	 * 
	 * @param event button clicked
	 *  Back to Main screen
	 */
	@FXML
	private void logoutClicked(ActionEvent event) {
		
		Screens.showPrevScreen("Main System Menu");	
	}
	
	 /**
	  *  @param message server response 
	  *  the method gets response message from server about searched book 
	  *  and sets it to text fields
	  */
	@Override
	public void display(Object message) {
		if (message == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+message.toString());
		
		borrowedBooks = (ArrayList<BorrowedBook>)message;			
		observableBooks = FXCollections.observableArrayList(borrowedBooks); 
		studentTableViewID.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		ISBNColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("ISBN"));
		titleColD.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("headline"));
		authorColD.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("author"));
		borrowDateIColD.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowDate"));
		returnDateColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("returnDate"));
		borrowStatusColID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowStatus"));
		studentTableViewID.setItems(observableBooks);		
	
	}

	@Override
	public void feedback(Object message) {
		Screens.submitFeedback(message);
		
	}
}
