package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class ViewReaderCardController implements ChatIF  {
	
	@FXML
	 private TextField StudentNameTextField;
	 @FXML
	 private TextField StudentIDTextField;
	 @FXML
	 private TextField SubscriberIDTextField;
	 @FXML
	 private TextField StudentEmailTextField;
	 @FXML
	 private TextField StudentPhoneTextField;
	 
	 private String studentPasswordGlobal;
	
	 private ConnectionController client;
	 private String studentGlobalID;
	 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Library Main Screen ");	 
	}
	 
	 @FXML
	 void SaveClick(ActionEvent event) throws IOException {
		
		 String studentID = StudentIDTextField.getText();
		 String email = StudentEmailTextField.getText();
		 String phone = StudentPhoneTextField.getText();
			ArrayList<String> SetParameters = new ArrayList<String>();

			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
				if (studentID.isEmpty() || email.isEmpty() || phone.isEmpty() ) {
		    		Screens.showErrorDialog("Invalid information","Text Field cannot be empty", "Please check info");
		    		return;
		    		}
				SetParameters.add(studentID);
				SetParameters.add(email);
				SetParameters.add(phone);
				}
			catch (IOException e) {
				e.printStackTrace();
			}

		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SAVE_STUDENT_INFO, SetParameters,null);
		    client.handleMessageFromClientUI(messageToSend); 
		 
	}
	 @FXML
	 void ViewBookBorrowHistoryClicked(ActionEvent event) {
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
			try {
		        	FXMLLoader loader= new FXMLLoader();	
		        	client = ConnectionController.getConnectionController();
			    	client.setPrevScene(curr);
	    			Stage stage = client.getStage();
	            	Parent root = loader.load(Main.class.getResource("/client/ReaderBorrowHistoryWindow.fxml").openStream());	        				
	            	ReaderBorrowHistoryWindowController controller = loader.getController();
	        		controller.setUserId(studentGlobalID);
	        		Scene scene = new Scene(root);	
	    			stage.setTitle("Borrow History");
	    			stage.setScene(scene);
	    			stage.show();
					} catch(IOException e) {
	        			e.printStackTrace();
					}
			 
		 
	}
	
	public void setStudentsID(String studentID) {
		ArrayList<String> SetParameters = new ArrayList<String>();
		studentGlobalID=studentID;
		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			SetParameters.add(studentID);
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_STUDENT_INFO, SetParameters,"student");
			client.handleMessageFromClientUI(messageToSend);
			}
		catch (IOException e) {
			e.printStackTrace();
		}		
		
	}
	

	@Override
	public void display(Object message) {

		 if (message instanceof Student) {
		Student student = (Student) message;
		StudentEmailTextField.setText(student.getStudentEmail());
		StudentPhoneTextField.setText(student.getStudentPhone());
      	SubscriberIDTextField.setText(student.getStudentSubscriberNumber()); 
      	StudentIDTextField.setText(student.getStudentID());
      	StudentNameTextField.setText(student.getStudentName());  
      	studentPasswordGlobal = student.getStudentPassword();
		 }
		 
		if (message == null) {
			System.out.println("> Server returned null");
		}
		else {
		System.out.println("> Server returned: "+message.toString());

		}		
		
		Platform.runLater(new Runnable() {  
		 
         @Override
         public void run() {
             try{
             	if (message == null) {
             		Screens.showErrorDialog("Error","Entry not found", "Username or password is incorrect!");
             		return;
             	}
            	if (message.toString().contains("Success")) {
        			Screens.showSuccessDialog("Information Dialog", "Success", "The new details were saved successfully");
        		}
           	
             }
             catch(Exception e) {
             	System.out.println("Invoke later failed..");
             	e.printStackTrace();
             }
         }
	 }); 
	}

}
