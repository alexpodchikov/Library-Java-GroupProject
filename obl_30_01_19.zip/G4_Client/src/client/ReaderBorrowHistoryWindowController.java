package client;


import java.io.IOException;
import java.util.ArrayList;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ReaderBorrowHistoryWindowController implements ChatIF{
	@FXML
	private TextField prolongationTextFieldID;
	@FXML
    private TableView<BorrowedBook> BorrowHistoryViewID;
	 
	@FXML
    private TableColumn<BorrowedBook, String> ISBNID;

    @FXML
    private TableColumn<BorrowedBook, String> BorrowerID;

    @FXML
    private TableColumn<BorrowedBook, String> BorrowDateID;

    @FXML
    private TableColumn<BorrowedBook, String> ReturnDateID;
    
    @FXML
    private TableColumn<BorrowedBook, String> ReturnStatusID;

    private ArrayList<BorrowedBook> borrowedBooks;
    private ConnectionController client;
    private ObservableList<BorrowedBook> observableBooks;
	
	
    @FXML
	private void SubmitClicked(ActionEvent event) throws IOException {
    	  String prolongationISBN = prolongationTextFieldID.getText();
			client = ConnectionController.getConnectionController();
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(prolongationISBN);	
  	    if(prolongationISBN.isEmpty()) {
  	    	Screens.showErrorDialog("Error","Cannot be empty for prolongation ISBN", "Please check your info!");
  	    	return;
  	    	}
  	  switch (client.getUserKind().toLowerCase().trim()) {
		case "student":
							
		ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SUBSCRIBER_MANUAL_PROLONGATION, SetParameters, null);			    
		client.handleMessageFromClientUI(messageToSend);

			break;
		case "librarian":
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend2);
			break;
		case "librarymanager":
			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
			client.handleMessageFromClientUI(messageToSend3);
			break;
		default:
			System.out.println("There is no such user");
			}			
  		}
	
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("User Profile");	 
	}
		@Override
		public void display(Object message) {
			if (message == null) {
				System.out.println("> Server returned null");
			}
			else System.out.println("> Server returned:2: "+message.toString());
			
			borrowedBooks = (ArrayList<BorrowedBook>)message;	
			observableBooks = FXCollections.observableArrayList(borrowedBooks); 
			BorrowHistoryViewID.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
			ISBNID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("ISBN"));
			BorrowerID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowerID"));	
			BorrowDateID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowDate"));
			ReturnDateID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("returnDate"));
			ReturnStatusID.setCellValueFactory(new PropertyValueFactory<BorrowedBook,String>("borrowStatus"));
			BorrowHistoryViewID.setItems(observableBooks);		
		}
		public void setUserId(String userID) {
			ArrayList<String> SetParameters = new ArrayList<String>();

			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
			
				SetParameters.add(userID);

				}
			catch (IOException e) {
				e.printStackTrace();
			}

		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_BOOK_BORROW_HISTORY, SetParameters,"borrowedbookhistory");
		    client.handleMessageFromClientUI(messageToSend); 
		 
			
		}

}
