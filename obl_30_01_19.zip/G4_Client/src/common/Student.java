package common;

import java.io.Serializable;


public class Student implements Serializable {
	private static final long serialVersionUID = -1133128363482085515L;
	

	public String StudentID;
	public String StudentName;
	public String StatusMembership;
	public String Operation;
	public String Freeze;
	public String StudentSubscriberNumber;
	public String StudentEmail;
	public String StudentPhone;
	public String StudentPassword;
	
	public Student(String studentID, String studentName, String statusMembership) {
		
		StudentID = studentID;
		StudentName = studentName;
		StatusMembership = statusMembership;
		
	}
	
	public Student(String studentName, String studentID , String studentSubscriberNumber, String  email, String phone, String studentPassword) {
		
		StudentName = studentName;
		StudentID = studentID;
		StudentSubscriberNumber = studentSubscriberNumber;
		StudentEmail = email;
		StudentPhone = phone;
		StudentPassword = studentPassword;
	}

	public String getStudentID() {
		return StudentID;
	}

	public void setStudentID(String studentID) {
		StudentID = studentID;
	}

	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
	}
	
	public String getStudentPassword() {
		return StudentPassword;
	}
	
	public void setStudentPassword(String studentPassword) {
		StudentPassword = studentPassword;
	}

	public String getStatusMembership() {
		return StatusMembership;
	}

	public void setStatusMembership(String statusMembership) {
		StatusMembership = statusMembership;
	}

	public String getOperation() {
		return Operation;
	}

	public void setOperation(String operation) {
		Operation = operation;
	}

	public String getFreeze() {
		return Freeze;
	}

	public void setFreeze(String freeze) {
		Freeze = freeze;
	}

	public String getStudentSubscriberNumber() {
		return StudentSubscriberNumber;
	}

	public void setStudentSubscriberNumber(String studentSubscriberNumber) {
		StudentSubscriberNumber = studentSubscriberNumber;
	}

	public String getStudentEmail() {
		return StudentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		StudentEmail = studentEmail;
	}

	public String getStudentPhone() {
		return StudentPhone;
	}

	public void setStudentPhone(String studentPhone) {
		StudentPhone = studentPhone;
	}


	
	@Override
	public String toString() {
		return StudentName;
	}


}
