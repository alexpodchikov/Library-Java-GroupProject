package client;

import java.io.IOException;
import java.util.ArrayList;

import common.ClientToServerMessage;
import common.EQueryOption;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LoginScreenConnector {	
	
	 @FXML
	 private TextField UserNameTextField;
	 @FXML
	 private PasswordField PasswordTextField;
	 private ConnectionController ConnectionController;			// user database handler.
	 
	
    @FXML
    void BackToMainSystemMenuClick(ActionEvent event) {
		((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary window
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
			root = loader.load(getClass().getResource("/client/MainSystemMenu.fxml").openStream());		
			Scene scene = new Scene(root);	
			scene.getStylesheets().add(getClass().getResource("MainSystemMenu.css").toExternalForm());
			stage.setTitle("Main System Menu");
			stage.setScene(scene);		
			stage.show();	
			} 
		catch (IOException e)
			{
			// TODO add to error manager
			e.printStackTrace();
			}
    }
    
	/**
	 * Login button pressed. validate login info.
	 * @param event login button pressed.
	 */
    @FXML	
    private void LoginClick(ActionEvent event) {
		String UserName = UserNameTextField.getText();
    	String Password = PasswordTextField.getText();
    	if (UserName.isEmpty() || Password.isEmpty()) {
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.getDialogPane();//.getStylesheets().add("/style.css");
    		alert.setTitle("Invalid username or password");
    		alert.setHeaderText("Cannot be empty");
    		alert.setContentText("Please check your info");
    		alert.show();
    		//WindowFactory.showErrorDialog("Invalid username or password","Cannot be empty", "Please check your info");
    		return;
    	}
		//String input = searchStudentTextFieldID.getText();
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(UserName);
		SetParameters.add(Password);
		System.out.println(SetParameters);
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, SetParameters, "user");
	    ConnectionController.handleMessageFromClientUI(messageToSend);
	    ((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary window
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root;
		try {
		root = loader.load(getClass().getResource("/client/UpdateScreen.fxml").openStream());
			Scene scene = new Scene(root);			
			stage.setScene(scene);		
			stage.show();
			
		} catch (IOException e) {
			// TODO add to error manager
			e.printStackTrace();
		}
		
	}
}
