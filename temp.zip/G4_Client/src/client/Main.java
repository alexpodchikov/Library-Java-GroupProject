package client;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Program main entry point.
 *
 */
public class Main extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainSystemMenuConnector.class.getResource("/client/MainSystemMenu.fxml"));// The 1st fxml view.
			Pane MainSystemMenu = loader.load();
            Scene scene = new Scene(MainSystemMenu);
			primaryStage.setTitle("Main System Menu");
            primaryStage.setScene(scene);
            primaryStage.setResizable(true);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
        }
	}

	public static void main(String[] args) {
		launch(args);
	}

}
