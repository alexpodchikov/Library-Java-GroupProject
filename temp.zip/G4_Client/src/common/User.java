package common;

import java.io.Serializable;

public class User implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String UserID;
	public String Password;
	public String UserName;
	public String AccountType;
	public String StatusMembership;
	public int Freeze;
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public User(String UserID, String UserPassword) {
		
		this.UserID = UserID;
		Password = UserPassword;
		
	}


	@Override
	public String toString() {
		return UserName;
	}



}
