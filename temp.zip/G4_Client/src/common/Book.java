package common;

import java.io.Serializable;

public class Book implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String BookID;
	public String BookName;

	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	public Book(String bookID) {
		
		this.BookID = bookID;
		
	}


	@Override
	public String toString() {
		return BookName;
	}



}
