package server;

	import java.util.HashMap;
	import java.util.List;

	import common.EQueryOption;

	/**
	 * Class: Query
	 * Store all server queries related to our database.
	 *
	 */
	public class Query {

		/// Product related names as in the Database
		//Database student
		private final static String USER_TABLE = "obl.user";
		private final static String USER_ID	="UserID";
		private final static String USER_NAME = "UserName";
		private final static String PASSWORD = "Password";
		private final static String ACCOUNT_TYPE = "AccountType";
		private final static String STUDENT_ID = "StudentID";
		private final static String STUDENT_NAME = "StudentName";
		private final static String STATUS_MEMBERSHIP = "StatusMembership";
		private final static String OPERATION = "Operation";
		private final static String FREEZE = "Freeze";
		
		//Database book
		private final static String BOOK_TABLE = "student.book";
		private final static String BOOK_ID = "bookId";
		private final static String BOOK_NAME = "bookName";
		///

		
		/**
		 * HashMap contains EQueryOption as key
		 * and number of parameters required as value.
		 */
		private static HashMap<EQueryOption, Integer> enumParamNum = startMap();
		
		/**
		 * Static initialization of enumParameterNumber
		 * @return initialized HashMap
		 */
		private static HashMap<EQueryOption, Integer> startMap()
	    {
			HashMap<EQueryOption, Integer> map = new HashMap<EQueryOption,Integer>();
			map.put(EQueryOption.LOGIN_REQUEST, 2); //Parameters: UserName, Password.
	        map.put(EQueryOption.GET_STUDENT_INFO, 1);		// Parameters: ID.
	        map.put(EQueryOption.UPDATE_STATUS_MEMBERSHIP, 2);	// Parameters:ID, StatusMembership.
	        map.put(EQueryOption.GET_BOOK_INFO, 1); // Parameters: BookId.
	        return map;
	    }
		
		
		/**
		 * Get suitable query
		 * Parameters order must be as table columns
		 * @param queryOption 
		 * @return Query string
		 */
		public static String getQuery(EQueryOption queryOption, List<String> Parameters) throws Exception{
			//System.out.println(Parameters);
			//System.out.println("size: "+Parameters.size());
			if (Parameters.size() != enumParamNum.get(queryOption)) {
				//System.out.println("got you!!");
				return "";
				// TODO: add invalid parameters number error or Exception 
			}
			
			switch(queryOption) {
			case LOGIN_REQUEST:
				return LoginRequest(Parameters.get(0),Parameters.get(1));	
				
			case GET_STUDENT_INFO:
				return getStudentInfo(Parameters.get(0));
				
			case UPDATE_STATUS_MEMBERSHIP:
				return updateStudentInfo(Parameters.get(0),Parameters.get(1));
			case GET_BOOK_INFO:
				return getBookInfo(Parameters.get(0));	
				
				default:
					return "";	// TODO: add error or exception (invalid enum option).
			}
		}
		
		/**
		 * Get query string for getting full product info from product table
		 * by productID.
		 * @param productID
		 * @return Product Info query string.
		 */
		private static String getBookInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " + BOOK_ID + ","+ BOOK_NAME  + " FROM " + BOOK_TABLE + " WHERE " +
					BOOK_ID + " = " + ID+";";
			return queryToReturn;
		}
		/**
		 * Get query string for getting full product info from product table
		 * by productID.
		 * @param productID
		 * @return Product Info query string.
		 */
		private static String getStudentInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " + STUDENT_ID + ","+ STUDENT_NAME +","+ STATUS_MEMBERSHIP + " FROM " + USER_TABLE + " WHERE " +
					STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}
		/**
		 * Get query string for updating product info.
		 * @param productID new ProductID string
		 * @param productName new Product Name
		 * @param productType new Product Type
		 * @return product info update query string.
		 */
		private static String updateStudentInfo(String ID, String Status) {
			ID = "\'"+ ID+ "\'";
			Status = "\'"+ Status+ "\'";
				////////////////////////// TO BE CONTINUED.....
			String queryToReturn = "UPDATE " +USER_TABLE + " SET " +
					STATUS_MEMBERSHIP + " = " + Status + 
					" WHERE " + STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}
		//SELECT AccountType,UserName,StatusMebership FROM obl.user WHERE UserID = 325;
		private static String LoginRequest (String UserID, String UserPassword) {
			UserID = "\'"+ UserID+ "\'";
			UserPassword = "\'"+ UserPassword+ "\'";
			String queryToReturn = "SELECT " + ACCOUNT_TYPE + ","+ USER_NAME +","+ STATUS_MEMBERSHIP + " FROM " + USER_TABLE + " WHERE " +
					USER_ID + " = " + UserID + " AND "+ PASSWORD + " = " + UserPassword+ " ;";	
			return queryToReturn;
		}
		

}
