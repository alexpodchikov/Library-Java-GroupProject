package client;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LibraryMainScreenController implements ChatIF {
	
	private String borrowDate;
	private String returnDate;

	
	private ConnectionController client;
	
	@FXML
	private TextField borrowingUserIDTextField;
	@FXML
	private TextField borrowedBookIDTextField;
	@FXML
	private TextField returnedBookIDTextField;
		
	@FXML
	private void BookSearchClick(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene(); 
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/BookSearch.fxml", null, "Book Search");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	@FXML
	private void inventoryClicked(ActionEvent event) {
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/InventoryManagementWindow.fxml", null, "Inventory Management");
			}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void borrowClick(ActionEvent event) throws Exception{
			
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		String userID = borrowingUserIDTextField.getText();
    	String bookID = borrowedBookIDTextField.getText();
    	if (userID.isEmpty() || bookID.isEmpty()) {
    		Screens.showErrorDialog("Error","Cannot be empty for book borrow", "Please check your info!");
    		return;
    	}
    	
    	   	
    	//set borrow & return dates
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.DATE, -1);
    	Calendar returnDay = today;
    	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    	for (int index = 1; index <= 15; index++) 	//
    	{
    		returnDay.add(Calendar.DATE, 1);
    		//System.out.println(dateFormat.format(returnDay.getTime()));
    	}
    	String borrowDate = dateFormat.format(new Date());
		Date day = Date.from(returnDay.toInstant());
    	String returnDate = dateFormat.format(day);
    	System.out.println("today is " + borrowDate);
    	System.out.println("return date is " + returnDate);
    	String borrowStatus = "ok";
    	//String prolongationRequest ="0";
    	
    	
   		ArrayList<String> SetParameters = new ArrayList<String>();		
   		SetParameters.add(bookID);
   		SetParameters.add(userID);
		SetParameters.add(borrowDate);
		SetParameters.add(returnDate);
		SetParameters.add(borrowStatus);
		//SetParameters.add(prolongationRequest);
		
		ArrayList<String> SetParameters2 = new ArrayList<String>();
		SetParameters2.add(userID);
		
		try {
			FXMLLoader loader= new FXMLLoader();
			client = ConnectionController.getConnectionController();
			Stage stage = client.getStage();
			client.clientUI = this;
			client.setPrevScene(curr);
			//ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_BORROWED_BOOK, SetParameters, "borrowedbook");		
		    ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.GET_STUDENT_NAME, SetParameters2, "user");		//"Student"		    
			//client.handleMessageFromClientUI(messageToSend); 
			client.handleMessageFromClientUI(messageToSend2);
			
			
			System.out.println("ninja3");
			
			
			ConfirmBookBorrowController controller = loader.getController();
    		controller.setBorrowedBooklDetais(borrowDate,returnDate);
        	Parent root = loader.load(Main.class.getResource("/client/ConfirmBookBorrow.fxml").openStream());
        	Scene scene = new Scene(root);	
        	
        	
        	System.out.println("ninja4");
        	
        	
			stage.setTitle("Confirm Book Borrow Order");
			stage.setScene(scene);
			stage.show(); 
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		/*try {
			client = ConnectionController.getConnectionController();
		    client.setPrevScene(curr);
		    Screens.showNewScreen("/client/ConfirmBookBorrow.fxml", null, "Confirm Book Borrow Order");
			}
		catch (IOException e) {
			e.printStackTrace();
		}*/
		
	}

	@FXML
	private void bookReturnClick(ActionEvent event) throws Exception{
		Scene curr = (Scene)((Node)event.getSource()).getScene();
		String returnedBookID = returnedBookIDTextField.getText();
    	if (returnedBookID.isEmpty() ) {
    		Screens.showErrorDialog("Error","Cannot be empty for book return", "Please check your book return ID input field!");
    		return;
    	}
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    	String returnDay = dateFormat.format(new Date());
    	System.out.println("The book was returned on the: " + returnDay);
    	
   		ArrayList<String> SetParameters = new ArrayList<String>();		
   		SetParameters.add(returnedBookID);
		SetParameters.add(returnDay);
		
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_STUDENT_NAME, SetParameters, "user");		//"Student"		    
		client.handleMessageFromClientUI(messageToSend); 
	}
	
	
	@FXML
	private void logoutClicked(ActionEvent event) {
		
		Screens.showPrevScreen("Main System Menu");	
	}
	
	
	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
}
