package common;

/**
 * Have to update initMap() and getQuery() in QueryFactory
 * when updating EQueryOption and vice versa.
 *
 */
public enum EQueryOption {

	GET_STUDENT_INFO,
	UPDATE_STATUS_MEMBERSHIP, 
	LOGIN_REQUEST,
	GET_BOOK_INFO, ADD_READER_CARD,
	GET_BORROWED_BOOK_INFO,
	GET_STUDENT_NAME,
	ADD_BORROWED_BOOK,
	SET_BOOK_AVAILABILITY_OFF,
	SET_BOOK_AVAILABILITY_ON,
	RETURN_BORROWED_BOOK,
	GET_BORROW_INFO
}
