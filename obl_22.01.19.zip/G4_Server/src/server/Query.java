package server;

	import java.util.HashMap;
	import java.util.List;

	import common.EQueryOption;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

	/**
	 * Class: Query
	 * Store all server queries related to our database.
	 *
	 */
	public class Query {

		/// Product related names as in the Database
		//Database user
		private final static String USER_TABLE = "obl.user";
		private final static String USER_ID	="UserID";
		private final static String USER_NAME = "UserName";
		private final static String PASSWORD = "Password";
		private final static String ACCOUNT_TYPE = "AccountType";
		private final static String STATUS_MEMBERSHIP = "StatusMembership";
		
		//Database student
		private final static String STUDENT_TABLE = "obl.student";
		private final static String STUDENT_ID = "StudentID";
		private final static String STUDENT_NAME = "StudentName";
		private final static String STUDENT_PASSWORD = "StudentPassword";
		private final static String STUDENT_PHONE_NUMBER = "PhoneNumber";
		private final static String STUDENT_EMAIL = "Email";
		private final static String STUDENT_STATUS_MEMBERSHIP = "StatusMembership";
		private final static String OPERATION = "Operation";
		private final static String FREEZE = "Freeze";
		
		//Database book
		private final static String BOOK_TABLE = "obl.book";
		private final static String BOOK_ID = "ISBN";
		private final static String BOOK_TITLE = "Headline";
		private final static String CATALOG_NUMBER = "CatalogNumber";
		private final static String NEXT_RETURN_DATE = "NextReturnDate";
		private final static String AVAILABLE_COPY = "Available";
		private final static String BOOK_AUTHOR = "Author";
		private final static String BOOK_SUBJECT = "Subject";
		private final static String BOOK_DESCRIPTION = "Description";
		private final static String BOOK_LOCATION = "ShelfLocation";
		private final static String BOOK_BORROW_PERIOD = "BorrowPeriod";
		private final static String BOOK_PURCHASE_DATE = "PurchaseDate";
		private final static String BOOK_PRINT_DATE = "PrintDate";
		private final static String BOOK_EDITION_NUMBER = "EditionNumber";
		private final static String BOOK_NUMBER_COPIES = "NumberCopies";
		private final static String BOOK_BORROW_COUNTER = "BorrowCounter";
		private final static String BOOK_BORROW_DURATION = "BorrowDuration";

		///
		
		//Database Borrowedbook
				private final static String BORROWED_BOOK_TABLE = "obl.borrowedbook";
				private final static String BORROWED_BOOK_ID = "ISBN";
				private final static String BORROWED_BOOK_USER_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_DATE = "borrowDate";
				private final static String BORROWED_BOOK_RETURN_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_STATUS = "borrowStatus";
				private final static String BORROWED_BOOK_PROLONGATION_REQUEST = "prolongationRequest";
				
		//Database borrowed_book_history
		private final static String BORROWED_BOOK_HISTORY_TABLE = "obl.borrowed_book_history";
		private final static String BORROWED_BOOK_HISTORY_BOOK_ID = "ISBN";
		private final static String BORROWED_BOOK_HISTORY_BORROWER_ID = "borrowerID";
		private final static String BORROWED_BOOK_HISTORY_BORROW_DATE = "borrowDate";
		private final static String BORROWED_BOOK_HISTORY_RETURN_DATE = "returnDate";
		private final static String BORROWED_BOOK_HISTORY_RETURN_STATUS = "returnStatus";
		private final static String BORROWED_BOOK_HISTORY_BORROWER_STATUS = "borrowerStatus";
		
		/**
		 * HashMap contains EQueryOption as key
		 * and number of parameters required as value.
		 */
		private static HashMap<EQueryOption, Integer> enumParamNum = startMap();
		
		/**
		 * Static initialization of enumParameterNumber
		 * @return initialized HashMap
		 */
		private static HashMap<EQueryOption, Integer> startMap()
	    {
			HashMap<EQueryOption, Integer> map = new HashMap<EQueryOption,Integer>();
			map.put(EQueryOption.LOGIN_REQUEST, 2); //Parameters: UserName, Password.
	        map.put(EQueryOption.GET_STUDENT_INFO, 1);		// Parameters: ID.
	        map.put(EQueryOption.UPDATE_STATUS_MEMBERSHIP, 2);	// Parameters:ID, StatusMembership.
	        map.put(EQueryOption.GET_BORROWED_BOOK_INFO, 1); // Parameters:,userId.
	        map.put(EQueryOption.GET_BOOK_INFO, 4); // Parameters: BookTitle, BookAuthor, BookSubject, BookDescription;
	        map.put(EQueryOption.ADD_READER_CARD, 5);// Parameters: StudentID, StudentName, StudentPassword, PhoneNumber, Email;
	        map.put(EQueryOption.GET_STUDENT_NAME, 1); // Parameters: StudentName.
	        map.put(EQueryOption.ADD_BORROWED_BOOK, 5);// Parameters: ISBN, userID, borrowDate, returnDate, borrowStatus, prolongationRequest;
	        map.put(EQueryOption.SET_BOOK_AVAILABILITY_ON, 3);// Parameters: bookID, userID, borrowDate, returnDate;
	        map.put(EQueryOption.RETURN_BORROWED_BOOK, 3);// Parameters: ISBN, returnDate, retutnStatus;
	        map.put(EQueryOption.GET_BORROW_INFO, 2);// Parameters: borrower_id,ISBN;
	        
	        return map;
	    }
		
		
		/**
		 * Get suitable query
		 * Parameters order must be as table columns
		 * @param queryOption 
		 * @return Query string
		 */
		public static String getQuery(EQueryOption queryOption, List<String> Parameters) throws Exception{
			//System.out.println(Parameters);
			//System.out.println("size: "+Parameters.size());
			if (Parameters.size() != enumParamNum.get(queryOption)) {
				//System.out.println("got you!!");
				return "";
				// TODO: add invalid parameters number error or Exception 
			}
			
			switch(queryOption) {
			case LOGIN_REQUEST:
				return LoginRequest(Parameters.get(0),Parameters.get(1));	
				
			case GET_BORROWED_BOOK_INFO:
				return getBorrowedBookInfo(Parameters.get(0));
				
			//case UPDATE_STATUS_MEMBERSHIP:
				//return updateStudentInfo(Parameters.get(0),Parameters.get(1));
			
			case GET_BOOK_INFO:
				//if(enumParamNum.get(queryOption)== 4) 
				return getBookInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3));
				//else 
					//return getBookInfo(Parameters.get(0));	
				
			case ADD_READER_CARD:
				return addReaderCard(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4));
				
			case GET_STUDENT_NAME:
				return getStudentName(Parameters.get(0));
				
			case ADD_BORROWED_BOOK:
				return addBorrowedBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4));
				
			/*case RETURN_BORROWED_BOOK:*/
				
			case GET_BORROW_INFO:
				return getBorrowInfo(Parameters.get(0),Parameters.get(1));
			
			case SET_BOOK_AVAILABILITY_OFF:
				return setBookAvailabilityZERO(Parameters.get(0),Parameters.get(1),Parameters.get(2));
				
			case SET_BOOK_AVAILABILITY_ON:
				return setBookAvailabilityON(Parameters.get(0),Parameters.get(1),Parameters.get(2));	
				
			default:
					return "";	// TODO: add error or exception (invalid enum option).
			}
		}





		/**
		 * Get query string for getting full product info from product table
		 * by productID.
		 * @param productID
		 * @return Product Info query string.
		 */
	/*	private static String getBookInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " + BOOK_ID + ","+ BOOK_TITLE  + " FROM " + BOOK_TABLE + " WHERE " +
					BOOK_ID + " = " + ID+";";
			return queryToReturn;
		}
		*/
		/**
		 * Get query string for getting full product info from product table
		 * by productID.
		 * @param productID
		 * @return Product Info query string.
		 */
		
		/*private static String getStudentInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " + STUDENT_ID + ","+ STUDENT_NAME +","+ STATUS_MEMBERSHIP + " FROM " + USER_TABLE + " WHERE " +
					STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}*/
		
		/** 
		 * Get query string for updating product info.
		 * @param productID new ProductID string
		 * @param productName new Product Name
		 * @param productType new Product Type
		 * @return product info update query string.
		 */
		
		/*private static String updateStudentInfo(String ID, String Status) {
			ID = "\'"+ ID+ "\'";
			Status = "\'"+ Status+ "\'";
				////////////////////////// TO BE CONTINUED.....
			String queryToReturn = "UPDATE " +USER_TABLE + " SET " +
					STATUS_MEMBERSHIP + " = " + Status + 
					" WHERE " + STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}*/
		
		//SELECT AccountType,UserName,StatusMebership FROM obl.user WHERE UserID = 325;
		private static String LoginRequest (String UserID, String UserPassword) {
			UserID = "\'"+ UserID+ "\'";
			UserPassword = "\'"+ UserPassword+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + ","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP + " FROM " + USER_TABLE + " WHERE " +
					USER_ID + " = " + UserID + " AND "+ PASSWORD + " = " + UserPassword+ " ;";	
		
			return queryToReturn;
		}
		
		private static String getBookInfo(String bookTitle, String bookAuthor,String bookSubject, String bookDescription) {
			bookTitle = "\'"+ bookTitle+ "\'";
			bookAuthor = "\'"+ bookAuthor+ "\'";
			bookSubject = "\'"+ bookSubject+ "\'";
			bookDescription = "\'"+ bookDescription+ "\'";
			String queryToReturn = "SELECT " + CATALOG_NUMBER + ","+ BOOK_TITLE +","+ BOOK_LOCATION + "," + AVAILABLE_COPY +
					" FROM " + BOOK_TABLE + " WHERE " + BOOK_TITLE + "=" + bookTitle +" OR "+
					BOOK_AUTHOR + " = " + bookAuthor + " OR " + BOOK_SUBJECT  + " = " + bookSubject + " OR " + BOOK_DESCRIPTION +"=" + bookDescription +" ;";
			return queryToReturn;		
		}
		
		
		private static String getBorrowedBookInfo(String userID) {
			userID = "\'"+ userID+ "\'";
			//bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "SELECT " + BORROWED_BOOK_ID  + ","+ BORROWED_BOOK_USER_ID +","+ BORROWED_BOOK_BORROW_DATE + "," + BORROWED_BOOK_RETURN_DATE +
					"," + BORROWED_BOOK_BORROW_STATUS+ ","+BORROWED_BOOK_PROLONGATION_REQUEST + " FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_USER_ID + "=" + userID + " ;";
			//+" OR "+ BORROWED_BOOK_ID + " = " + bookID + " ;";				
			return queryToReturn;
		}
	
		
		private static String addReaderCard(String studentID, String studentName, String studentPassword, String phoneNumber, String email) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			phoneNumber = "\'"+ phoneNumber+ "\'";
			email = "\'"+ email+ "\'";
			String queryToReturn = "INSERT INTO " + STUDENT_TABLE + "(" + STUDENT_ID +","+ STUDENT_NAME +","+ STUDENT_PASSWORD +","+ STUDENT_PHONE_NUMBER +","+ STUDENT_EMAIL + "," + STUDENT_STATUS_MEMBERSHIP + "," + FREEZE + ")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ phoneNumber +","+ email + "," + "\'" + "Active"+ "\'" + "," + 0 + ")" + ";";
			return queryToReturn;
		}

		/* 
		 * add new borrowed book
		 */
		/*private static String addBorrowedBook(String bookID, String userID, String borrowDate, String returnDate, String borrowStatus, String prolongationRequest) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			borrowStatus = "\'"+ borrowStatus+ "\'";
			prolongationRequest = "\'"+ prolongationRequest+ "\'";
			String queryToReturn = "INSERT INTO" + BORROWED_BOOK_TABLE + "(" + BORROWED_BOOK_ID +","+ BORROWED_BOOK_USER_ID +","+ BORROWED_BOOK_BORROW_DATE +","+ BORROWED_BOOK_RETURN_DATE +","+ BORROWED_BOOK_BORROW_STATUS +","+ BORROWED_BOOK_PROLONGATION_REQUEST + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +","+ returnDate +","+ borrowStatus +","+ prolongationRequest +"," + ")";
			return queryToReturn;
		}*/
		private static String addBorrowedBook(String bookID, String userID, String borrowDate, String returnDate, String borrowStatus) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			borrowStatus = "\'"+ borrowStatus+ "\'";
			/*String queryToReturn = "INSERT INTO" + BORROWED_BOOK_TABLE + "(" + BORROWED_BOOK_ID +","+ BORROWED_BOOK_USER_ID +","+ BORROWED_BOOK_BORROW_DATE +","+ BORROWED_BOOK_RETURN_DATE +","+ BORROWED_BOOK_BORROW_STATUS + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +","+ returnDate +","+ borrowStatus + ")";*/
			String queryToReturn = "INSERT INTO " + BORROWED_BOOK_TABLE + "(" + BORROWED_BOOK_ID +","+ BORROWED_BOOK_USER_ID +","+ BORROWED_BOOK_BORROW_DATE +","+ BORROWED_BOOK_RETURN_DATE +","+ BORROWED_BOOK_BORROW_STATUS +","+ BORROWED_BOOK_PROLONGATION_REQUEST + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +","+ returnDate +","+ borrowStatus +"," + false + ")" + ";";
			return queryToReturn;
		}
		
		
		/*
		 * set availability status of a book to not available
		 * */ 
		private static String setBookAvailabilityZERO(String bookName, String bookID, String bookCatalogNumber) {
			bookName = "\'"+ bookName+ "\'";
			bookID = "\'"+ bookID+ "\'";
			bookCatalogNumber = "\'"+ bookCatalogNumber+ "\'";
			String queryToReturn = "UPDATE" + BOOK_TABLE + "SET" + AVAILABLE_COPY + " = " + 0 + " WHERE " + BOOK_TITLE + " = " + bookName + " AND " + BOOK_ID + " = " + bookID + " AND " + CATALOG_NUMBER + " = " + bookCatalogNumber + " ;";
			return queryToReturn;
		}
		
		/*
		 * set availability status of a book to available
		 * */ 
		private static String setBookAvailabilityON(String bookName, String bookID, String bookCatalogNumber) {
			bookName = "\'"+ bookName+ "\'";
			bookID = "\'"+ bookID+ "\'";
			bookCatalogNumber = "\'"+ bookCatalogNumber+ "\'";
			String queryToReturn = "UPDATE" + BOOK_TABLE + "SET" + AVAILABLE_COPY + " = " + 1 + " WHERE " + BOOK_TITLE + " = " + bookName + " AND " + BOOK_ID + " = " + bookID + " AND " + CATALOG_NUMBER + " = " + bookCatalogNumber + " ;";
			return queryToReturn;
		}
		
		/* 
		 * when borrowing book get subscriber's name for confirm book borrow window
		 * */
		private static String getStudentName(String studentID) {
			studentID = "\'"+ studentID+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + " FROM " + USER_TABLE + " WHERE " +
					//USER_ID + " = " +  studentID + " AND "+ ACCOUNT_TYPE + " = " + "'Student'" + " AND "+ STATUS_MEMBERSHIP + " = " + "'Active'" + " ;";	
					USER_ID + " = " +  studentID + " AND " + STATUS_MEMBERSHIP + " = " + "'Active'" + " ;";
			return queryToReturn;		
		}
		
		/* 
		 * when borrowing book get subscriber's name and borrow duration for book borrow window
		 * 
		 * SELECT UserName ,BorrowPeriod 
		 * FROM obl.user , obl.book  
		 * WHERE obl.user.UserID = '325' AND obl.book.ISBN = '12345';
		 * */
		private static String getBorrowInfo(String studentID,String isbn) {
			studentID = "\'"+ studentID+ "\'";
			isbn = "\'"+ isbn+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + "," + BOOK_BORROW_PERIOD + " FROM " + USER_TABLE +","+BOOK_TABLE+ " WHERE " + USER_TABLE + "." +
					USER_ID + " = " +  studentID + " AND " + BOOK_TABLE + "." + BOOK_ID + " = " + isbn + " ;";
			return queryToReturn;		
		}
		
		/*
		 * UPDATE obl.borrowhistory,obl.borrowedbook SET obl.borrowhistory.returnDay = obl.borrowedbook.returnDate WHERE obl.borrowhistory.bookID = '12345';
		 * */
		private static String setReturnedBookInfo(String bookID, String returnDate, String retutnStatus) {
			bookID = "\'"+ bookID+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			retutnStatus = "\'"+ retutnStatus+ "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_HISTORY_TABLE + "SET" + BORROWED_BOOK_HISTORY_RETURN_DATE +"="+ returnDate+ "AND" + BORROWED_BOOK_HISTORY_RETURN_STATUS + "=" + retutnStatus + 
					"WHERE" + BORROWED_BOOK_HISTORY_BOOK_ID + "=" + bookID + "AND" +BORROWED_BOOK_HISTORY_RETURN_DATE +"=" +null+ ";";
			return queryToReturn;
		}
		
}
