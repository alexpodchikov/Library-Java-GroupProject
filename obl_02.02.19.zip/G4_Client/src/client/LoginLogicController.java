package client;


import java.io.IOException;
import java.util.ArrayList;
import common.User;
import common.ClientToServerMessage;
import common.ChatIF;
import common.EQueryOption;

public class LoginLogicController implements ChatIF{

	private static ConnectionController client;			// user database handler.
	private static final String lockedError = "Your account is LOCKED!";
	private static final String loggedInError = "You're already logged in!";
	private static final String invalidInputError = "Wrong input! No such account exists.";
    
    public static void handleLoginData(ChatIF clientUI, String userName,String Password)
    {
    	setClientConnection(clientUI);
    	ClientToServerMessage loginMessageToSend = setLoginMessage( userName, Password);
    	client.handleMessageFromClientUI(loginMessageToSend);
    	
    }
    
    public static void setClientConnection(ChatIF clientUI)
    {
		try 
		{
			client = ConnectionController.getConnectionController();
			client.clientUI = clientUI;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
   	
    }
    
    
    public static ClientToServerMessage setLoginMessage(String userName,String Password)
    {
    	ArrayList<String> loginParameters = new ArrayList<String>();
    	loginParameters.add(userName);
    	loginParameters.add(Password);
	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, loginParameters,"User");
	    return messageToSend;
    }
   
    
    public static boolean checkValidLoginInput(String userName, String Password)
    {
    	boolean isValidInput = true;
    	
    	if (userName.isEmpty() || Password.isEmpty()) 
    	{
    		 isValidInput = false;
    	} 
    	
    	return isValidInput;
    }
 
    //*******************************************************************************************
    

    /**
     * receive  the answer from server and open new screen according to the right user
     */
    	@Override
    	public void display(Object msg) 
    	{
    		User userInfo;
    		String errorMessage;
    		String userType;
    		
    		if(checkValidMessageFromServer(msg))
    		{
    			userInfo = (User)msg;
    		}
    		else
    		{
    			LoginScreenController.showLoginError(invalidInputError);
    			return;
    		}
    		   		
    		if (checkIfUserIsConnected(userInfo)) 
    		{
    			LoginScreenController.showLoginError(loggedInError);
    			return;
    		}
    		
    		if (checkIfUserIsLocked(userInfo)) 
    		{
    			LoginScreenController.showLoginError(lockedError);
    			return;
    		}
    		
    		setClientInfo(userInfo);
    		userType = checkUserType(userInfo);
    			
    		LoginScreenController loginScreenController = new LoginScreenController();
    		try {
				loginScreenController.showStage(userType);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
 
    	public static boolean checkValidMessageFromServer(Object msg)
    	{
    		boolean isValidMessage = false;
    		if (msg instanceof User)
    		{
    			isValidMessage = true;
    		}
    		
    		return isValidMessage;
    	}
    	 
    	public static boolean checkIfUserIsConnected(User userInfo)
    	{
    		boolean isUserConnected = true;
    		
    		if (userInfo.getIsConnected().equals("0"))
    		{
    			isUserConnected = false;
    		}
    		
    		return isUserConnected;
    		
    	}
    	
    	
    	public static boolean checkIfUserIsLocked(User userInfo)
    	{
    		boolean isUserLocked = true;
    		
    		if (!(userInfo.getStatusMembership().equalsIgnoreCase("Locked")))
    		{
    			isUserLocked = false;
    		}
    		
    		return isUserLocked;
    		
    	}
    	
    	public static void setClientInfo(User userInfo)
    	{
			client.setUserID(userInfo.getUserID());
			client.setUserKind(userInfo.getAccountType());
			client.setName(userInfo.getUserName());
			if(checkUserType(userInfo).equals("student"))
			{
				client.setStatus(userInfo.getStatusMembership());
			}
			
    	}
    	
    	public static String checkUserType(User userInfo)
    	{
    		String userType;
    		userType = userInfo.getAccountType().toLowerCase().trim();
    		
    		return userType;
    		
    	}
}
	

