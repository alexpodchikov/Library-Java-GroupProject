package client;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginScreenController {	
	 @FXML
	 private TextField UserNameTextField;
	 @FXML
	 private PasswordField PasswordTextField;
	 private ConnectionController client;			// user database handler.
	 private String userName= null;
	 private Stage curr;
	
	 /**
	  * going back to previous screen
	  * @param event back button clicked
	  */
    @FXML
    void BackToMainSystemMenuClick(ActionEvent event) {
    	Stage curr = (Stage)((Node)event.getSource()).getScene().getWindow(); 
    	curr.close();
    }
    
	/**
	 * Login button pressed. validate login info.
	 * @param event login button pressed.
	 */    
    @FXML	
    private void LoginClick(ActionEvent event) {
    	curr = (Stage)((Node)event.getSource()).getScene().getWindow();
    	userName = UserNameTextField.getText();
    	String password = PasswordTextField.getText();
    	
    	
    	if (!LoginLogicController.checkValidLoginInput(userName, password))
    	{
    		Screens.showErrorDialog("Error","Cannot be empty", "Please check your info!");
    		return;
    	}
    	
    	LoginLogicController loginLogicController = new LoginLogicController();
    	LoginLogicController.handleLoginData(loginLogicController, userName, password);
    	
	}
    
    
    public static void showLoginError(String errorMessage)
    {
		Platform.runLater(new Runnable() {                          
            @Override
            public void run() 
            {
            	Screens.showErrorDialog("Error","Login failed", errorMessage);	
            }
		});
   	
    }   
    
    /**
	 * Get suitable stage for suitable form by object type..
	 * @param object
	 * @return suitable stage
	 * @throws Exception
	 */
	public void showStage(String userType) throws Exception {
		Platform.runLater(new Runnable() {                          
            @Override
            public void run() 
            {
            	String mainMenuAccount = null;
        		String stylesheetPath = null; 
      		
        		// get user parent
        		
        			try 
        			{
        				client = ConnectionController.getConnectionController();       				
        			} 
        			catch (IOException e1) 
        			{
        				// TODO Auto-generated catch block
        				e1.printStackTrace();
        			}

        			FXMLLoader loader= new FXMLLoader();
        			Stage stage = client.getStage();
        			String name = client.getName();
        			
        			switch (userType) {
        			
        			case "student":
        				
        				try 
        				{
        					Parent root = loader.load(Main.class.getResource("/client/SubscriberSystemMenu.fxml").openStream());		        			
        					SubscriberMainScreenController controller = loader.getController();
        					controller.setUserBooksInfo(userName);
        					Scene scene = new Scene(root);	
        					scene.getStylesheets().add(Main.class.getResource("/client/Subscriber.css").toExternalForm());			        		
        					stage.setTitle("Subscriber System Menu");
        					stage.setScene(scene);
        					stage.show();

        				} 
        				catch(IOException e) 
        				{
                			e.printStackTrace();
        				}
        			
        				break;
        			case "librarian":	
        				Parent root;
        				try 
        				{
        					root = loader.load(Main.class.getResource("/client/LibrarianMainScreen.fxml").openStream());
        					LibraryMainScreenController controller = loader.getController();
        					controller.setUserName(name);
        					Scene scene = new Scene(root);	
        					scene.getStylesheets().add(Main.class.getResource("/client/LibraryMainScreen.css").toExternalForm());			        		
        					stage.setTitle("Librarian System Menu");
        					stage.setScene(scene);
        					stage.show();
        				} 
        				catch (IOException e) 
        				{        					
        					e.printStackTrace();
        				}		        			      				  
        				break;
        				
        			case "librarymanager":
        				Parent root2;
        				try 
        				{
        					root2 = loader.load(Main.class.getResource("/client/LibraryManagerMainScreen.fxml").openStream());
        					LibraryMainScreenController controller2 = loader.getController();
        					controller2.setUserName(name);
        					Scene scene2 = new Scene(root2);	
        					scene2.getStylesheets().add(Main.class.getResource("/client/LibraryMainScreen.css").toExternalForm());			        		
        					stage.setTitle("Library Manager System Menu");
        					stage.setScene(scene2);
        					stage.show();
        				} 
        				catch (IOException e) 
        				{       					
        					e.printStackTrace();
        				}		        			
        				break;
        			default: 
        				System.out.println("There is no such user");
        			}
        			System.out.println(mainMenuAccount);  		        			
        		 
        		
        		curr.close();
		

            }
		});
	}

}
	
