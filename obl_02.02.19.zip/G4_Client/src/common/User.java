package common;

import java.io.Serializable;

public class User implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String userID;

	public String password;
	public String userName;
	public String accountType;
	public String statusMembership;
	public String isConnected;
	
	public String getStatusMembership() {
		return statusMembership;
	}

	public void setStatusMembership(String statusMembership) {
		this.statusMembership = statusMembership;
	}
	public int freeze;
	

	public User(String UserName, String AccountType, String StatusMembership,String UserID,String IsConnected) {
		
		userName = UserName;
		accountType = AccountType;
		statusMembership = StatusMembership;
		userID =UserID; 
		isConnected = IsConnected;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}
	
	public void setUserID(String userID) {
		this.userID = userID;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}
	/**		
* @return the userName		
	*/		
	public String getUserName() {		
	return userName;
	}
	public String getIsConnected() {
		return isConnected;
	}

	public void setIsConnected(String isConnected) {
		this.isConnected = isConnected;
	}

	@Override
	public String toString() {
		return userName;
	}



}
