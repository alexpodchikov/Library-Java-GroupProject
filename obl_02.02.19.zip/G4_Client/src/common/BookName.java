package common;

import java.io.Serializable;

public class BookName implements Serializable {


	private static final long serialVersionUID = -4705567804509314316L;
	public String bookName;
	
	public BookName(String BookName) {
		this.bookName = BookName;
		
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	@Override
	public String toString() {
		return bookName;
	}
	
}
