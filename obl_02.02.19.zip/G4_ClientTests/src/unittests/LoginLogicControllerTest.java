
package unittests;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import client.ConnectionController;
import client.LoginLogicController;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.User;


public class LoginLogicControllerTest {
	private static LoginLogicController loginScreenController;
	private ConnectionController client;			// user database handler.
	String correctManagerUsername, correctManagerPassword, correctLibrarianUsername, correctLibrarianPassword, emptyUsername, emptyPassword;
	ArrayList<String> managerLoginParameters, librarianLoginParameters, emptyLoginParameters ;
	User librarianUser;
	/*
	private User activeUser = new User();
	private User frozenUser = new User();
	private User lockedUser = new User();
	private User caseSensitiveUser = new User();
	private User librarianUser = new User();
	private User managerUser = new User();
	*/	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//loginScreenController = new LoginLogicController();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		/*User(String UserName, String AccountType, String StatusMembership,String UserID);*/
		User activeUser = new User("Anton","Student","Active","325","0");
		User frozenUser = new User("Harel","Student","Frozen","111","0");
		User lockedUser = new User("Kim","Student","Locked","9999","0");
		User caseSensitiveUser = new User("Ben","Student","Frozen","888","0");
		librarianUser = new User("Michael","Librarian","Active","987","0");
		User managerUser = new User("Alex","Manager","Active","123","0");
		User emptyUser = new User("","","","","");	
		
		

		String wrongSubscriberUsername = "112";
		String wrongSubscriberPassword = "1512";
				
		String correctSubscriberUsername = "333";
		String correctSubscriberPassword = "111";
		String correctSubscriberName = "Gal";
				
		String caseSensitiveCorrectSubscriberUsername = "888";
		String caseSensitiveIncorrectPassword = "gta";
		String caseSensitiveCorrectPassword = "GTA";
		String incorrectCaseSensitiveSubscriberName = null;
		String correctCaseSensitiveSubscriberName = "Ben";
		
		correctLibrarianUsername = "987";
		correctLibrarianPassword = "456";
		librarianLoginParameters = new ArrayList<>(Arrays.asList("987", "456"));
		String correctLibrarianName = "Michael";
			
		correctManagerUsername = "123";
		correctManagerPassword = "321";
		managerLoginParameters = new ArrayList<>(Arrays.asList("123", "321"));
		String correctManagerName = "Alex";
		
		String frozenSubscriberUsername = "111";
		String frozenSubscriberPassword = "222";
		
		String lockedSubscriberUsername = "9999";
		String lockedSubscriberPassword = "111";
		
		//emptyUsername = "";
		//emptyPassword = "";
		emptyLoginParameters = new ArrayList<>(Arrays.asList("", ""));
		
	}

	@After
	public void tearDown() throws Exception {
	}
	
	
	/****************************************TEST*****************************************/
	@Test
	public void setCorrectManagerLoginMessageTest() {

		ArrayList<String> loginParameters = managerLoginParameters;
		ClientToServerMessage toCheck = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, loginParameters, "User");
		client.handleMessageFromClientUI(toCheck);
		//User toCheck2 = librarianUser;

		
		//FileInputStream fis = new FileInputStream(msg);
		//ObjectInputStream ois = new ObjectInputStream(fis);
		//toCheck2 = (User) ois.readObject();
		
		//ArrayList<String> SetParameters = new ArrayList<String>();
    	//SetParameters.add(correctManagerUsername);
    	//SetParameters.add(correctManagerPassword);
    	//ClientToServerMessage expected = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, SetParameters, "User");
    	//client.handleMessageFromClientUI(expected);
		
		User expected = librarianUser;
    	assertEquals(expected, toCheck);
	}
	
	@Test
	public void setEmptyLoginMessageTest() {
		//BufferedReader inFromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
    	ArrayList<String> loginParameters = emptyLoginParameters;
		ClientToServerMessage toCheck = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, loginParameters, "User");
    	ArrayList<String> SetParameters = new ArrayList<String>();
    	SetParameters.add("");
    	SetParameters.add("");
    	ClientToServerMessage expected = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, SetParameters, "User");
    	ArrayList<String> strServer;

    	assertEquals(expected, toCheck);
	}
	
	@Test
	public void correctStudentInputTest() {

	}
	
	@Test
	public void correctLibrarianInputTest() {
		
	}
	
	@Test
	public void correctManagerInputTest() {
		
	}	
	
	@Test
	public void wrongPasswordInputTest() {
		
	}
	
	@Test
	public void wrongUsernameInputTest() {
		
	}
	
	@Test
	public void lockedStudentBlockingTest() {
		
	}
	
	@Test
	public void frozenStudentAcceptanceTest() {
		
	}
	
	@Test
	public void emptyInputTest() {
		
	}
	
	@Test
	public void emptyPasswordTest() {
		
	}
	
	@Test
	public void emptyUsernameTest() {
		
	}
	
	@Test
	public void caseSensitivePasswordTest() {
		
	}

}
