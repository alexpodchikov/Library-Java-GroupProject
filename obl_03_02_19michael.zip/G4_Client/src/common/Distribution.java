package common;

import java.io.Serializable;


	

public class Distribution implements Serializable{


	private static final long serialVersionUID = 629876360866362518L;

	public String percent;



	public String count;
	
	
	public Distribution (String Percent, String Count) {
	this.percent = Percent;
	this.count = Count;
}
	
	public String getPercent() {
		return percent;
	}


	public void setPercent(String percent) {
		this.percent = percent;
	}


	public String getCount() {
		return count;
	}


	public void setCount(String count) {
		this.count = count;
	}
	

	@Override
	public String toString() {
		return percent + " " +count;
	}
	
}