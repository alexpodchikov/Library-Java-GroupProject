package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import common.Book;
import common.BorrowedBook;
import common.ChatIF;
import common.ClientToServerMessage;
import common.Distribution;
import common.EQueryOption;
import common.ProblematicStudent;
import common.Student;
import common.User;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ProblematicSubscriberController implements ChatIF,Initializable {
	
	@FXML
	private TextField unlockSubscriberIDTextFieldID;
	@FXML
	private TextField lockSubscriberIDTextFieldID;
	@FXML
    private TableView<ProblematicStudent> ProblematicSubscriberViewID;	
    @FXML
    private TableColumn<ProblematicStudent, String> SubscriberID;
    @FXML
    private TableColumn<ProblematicStudent, String> SubscriberName;   
    @FXML
    private TableColumn<ProblematicStudent, String> SubscriberStatus;
    
    
    private ConnectionController client;
    private ArrayList<ProblematicStudent> problematicUsers;
    private ObservableList<ProblematicStudent> observableProblematicUsers;


	@FXML
	void BackClick(ActionEvent event) {		 
		 Screens.showPrevScreen("Library Manager Window");	 
	}

	
	@FXML
	private void SubmitUnlockClicked(ActionEvent event) throws IOException {
	/*	String unlockSubscriberID = unlockSubscriberIDTextFieldID.getText();
	  	client = ConnectionController.getConnectionController();
	  	client.clientUI = null;
	  	//client.clientF = this;		
	  	ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(unlockSubscriberID);	
		if(unlockSubscriberID.isEmpty()) {
			Screens.showErrorDialog("Error","Cannot be empty for unlocking subscriber", "Please check your text field input!");
		   	return;
		}
		ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
		client.handleMessageFromClientUI(messageToSend3);*/
	}
	
	
	@FXML
	private void SubmitLockClicked(ActionEvent event) throws IOException {
	/*	String lockSubscriberID = lockSubscriberIDTextFieldID.getText(); 
	  	client = ConnectionController.getConnectionController();
	  	client.clientUI = null;
	  	//client.clientF = this;		
	  	ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(lockSubscriberID);	
		if(lockSubscriberID.isEmpty()) {
		    Screens.showErrorDialog("Error","Cannot be empty for locking subscriber", "Please check your text field input!");
		    return;
		}
		ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION, SetParameters, null);			    
		client.handleMessageFromClientUI(messageToSend3);*/
	}

	
	@Override
	public void display(Object message) {
		if (message == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned:2: "+message.toString());
		Platform.runLater(new Runnable() {                          
            @Override
            public void run() { 	
  
        	try {
				showStage(message);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

        }
    
    
    private void showStage(Object object) throws Exception {
		problematicUsers = (ArrayList<ProblematicStudent>)message;	
		System.out.println(problematicUsers.get(0).getSubscriberID());
				System.out.println(problematicUsers.get(0).getSubscriberName());
				System.out.println(problematicUsers.get(0).getSubscriberStatus());
		observableProblematicUsers = FXCollections.observableArrayList(problematicUsers); 
		ProblematicSubscriberViewID.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		SubscriberID.setCellValueFactory(new PropertyValueFactory<ProblematicStudent,String>("SubscribersID"));
		SubscriberName.setCellValueFactory(new PropertyValueFactory<ProblematicStudent,String>("SubscribersName"));	
		SubscriberStatus.setCellValueFactory(new PropertyValueFactory<ProblematicStudent,String>("SubscriberStatus"));
		ProblematicSubscriberViewID.setItems(observableProblematicUsers);
    }
		
	 });
	}
	


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
		
	  	ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add("vasya");	
	
		ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.GET_PROBLEMATIC_SUBSCRIBERS, SetParameters, "get_problematic_students");			    
		client.handleMessageFromClientUI(messageToSend3);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
}
