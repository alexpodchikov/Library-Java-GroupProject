package server;

	import java.util.HashMap;
	import java.util.List;

	import common.EQueryOption;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

	/**
	 * Class: Query
	 * Store all server queries related to our database.
	 *
	 */
	public class Query {

		/// Product related names as in the Database
		//Database user
		private final static String USER_TABLE = "obl.user";
		private final static String USER_ID	="UserID";
		private final static String USER_NAME = "UserName";
		private final static String PASSWORD = "Password";
		private final static String ACCOUNT_TYPE = "AccountType";
		private final static String STATUS_MEMBERSHIP = "StatusMembership";
		private final static String USER_FREEZE_COUNTER = "FreezeCounter";
		
		//Database student
		private final static String STUDENT_TABLE = "obl.student";
		private final static String STUDENT_ID = "StudentID";
		private final static String STUDENT_NAME = "StudentName";
		private final static String STUDENT_PASSWORD = "StudentPassword";
		private final static String STUDENT_PHONE_NUMBER = "PhoneNumber";
		private final static String STUDENT_EMAIL = "Email";
		private final static String STUDENT_STATUS_MEMBERSHIP = "StatusMembership";
		private final static String OPERATION = "Operation";
		private final static String FREEZE = "FreezeCounter";
		private final static String SUBSCRIBER_NUMBER = "StudentSubscriberNumber";

		
		//Database book
		private final static String BOOK_TABLE = "obl.book";
		private final static String BOOK_TITLE = "Headline";
		private final static String BOOK_AUTHOR = "Author";
		private final static String BOOK_ID = "ISBN";							//Key
		private final static String CATALOG_NUMBER = "CatalogNumber";
		private final static String BOOK_EDITION_NUMBER = "EditionNumber";
		private final static String BOOK_PRINT_DATE = "PrintDate";
		private final static String BOOK_SUBJECT = "Subject";
		private final static String BOOK_PURCHASE_DATE = "PurchaseDate";
		private final static String BOOK_NUMBER_COPIES = "NumberCopies";
		private final static String BOOK_NUMBER_WANTEDTAG = "WantedTag";
		private final static String BOOK_BORROW_PERIOD = "BorrowPeriod";
		private final static String BOOK_BORROW_COUNTER = "BorrowCounter";
		private final static String BOOK_BORROW_DURATION = "BorrowDuration";
		private final static String BOOK_RETURN_DELAY = "ReturnDelay";
		private final static String AVAILABLE_COPY = "Available";
		private final static String NEXT_RETURN_DATE = "NextReturnDate";
		private final static String BOOK_DESCRIPTION = "Description";
		private final static String BOOK_LOCATION = "ShelfLocation";
		///
		
		//Database BorrowedBook
				private final static String BORROWED_BOOK_TABLE = "obl.borrowedbook";
				private final static String BORROWED_BOOK_ISBN = "ISBN";
				private final static String BORROWED_BOOK_BORROWER_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_DATE = "borrowDate";
				private final static String BORROWED_BOOK_RETURN_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_STATUS = "borrowStatus";
		
				
				
		//Database BorrowedBookHistory
				private final static String BORROWED_BOOK_HISTORY_TABLE = "obl.borrowed_book_history";
				private final static String BORROWED_BOOK_HISTORY_ISBN = "ISBN";
				private final static String BORROWED_BOOK_USER_HISTORY_ID = "borrowerID";
				private final static String BORROWED_BOOK_BORROW_HISTORY_DATE = "borrowDate";
				private final static String BORROWED_BOOK_BORROW_HISTORY_TIME = "borrowTime";
				private final static String BORROWED_BOOK_RETURN_HISTORY_DATE = "returnDate";
				private final static String BORROWED_BOOK_BORROW_HISTORY_STATUS = "borrowStatus";
				
		//Database SubscriberStatusHistory
				private final static String SUBSCRIBER_STATUS_HISTORY_TABLE = "obl.subscriber_status_history";
				private final static String SUBSCRIBER_STATUS_HISTORY_ID = "subscribeID";			//Key
				private final static String SUBSCRIBER_STATUS_HISTORY_STATUS = "subscriberStatus";
				private final static String SUBSCRIBER_STATUS_HISTORY_START_DATE = "beginningDate";	//Key
				private final static String SUBSCRIBER_STATUS_HISTORY_END_DATE = "endDate";
				
		//Database ProlongationRequest
				private final static String PROLONGATION_REQUEST_TABLE = "obl.prolongationrequest";
				private final static String PROLONGATION_REQUEST_SUBSCRIBER_ID = "SubscriberID";	//Key
				private final static String PROLONGATION_REQUEST_DATE = "ProlongationDate";			//Key
				private final static String PROLONGATION_REQUEST_ISBN = "ISBN";						//Key
				private final static String PROLONGATION_REQUEST_DATE_CONFIRMATION = "RequestConfirmation";
				
		//Database ProblematicSubscribers
				private final static String PROBLEMATIC_SUBSCRIBERS_TABLE = "obl.problematicsubscribers";
				private final static String PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID = "SubscribersID";//Key
				private final static String PROBLEMATIC_SUBSCRIBERS_LOCK_DATE = "LockingDate";	
				private final static String PROBLEMATIC_SUBSCRIBERS_UNLOCK_DATE = "UnlockingDate";	
				
		//Database ManualProlongation
				private final static String MANUAL_PROLONGATION_TABLE = "obl.manualprolongation";
				private final static String MANUAL_PROLONGATION_LIBRARIAN_ID = "librarianID";		//Key
				private final static String MANUAL_PROLONGATION_ISBN = "ISBN";						//Key
				private final static String MANUAL_PROLONGATION_LIBRARIAN_NAME = "librarianName";	
				private final static String MANUAL_PROLONGATION_DATE = "prolongationDate";			//Key
				
		//Database ActivityReport
				private final static String ACTIVE_REPORT_TABLE = "obl.active_report";
				private final static String ACTIVE_REPORT_FROM_DATE = "FromDate";		//Key
				private final static String ACTIVE_REPORT_TO_DATE = "ToDate";						//Key
				private final static String ACTIVE_REPORT_ACTIVE_SUBSCRIBER_AMOUNT = "NumberofActiveSubscribers";	
				private final static String ACTIVE_REPORT_FROZEN_SUBSCRIBER_AMOUNT = "NumberofFrozenSubscribers";			//Key
				private final static String ACTIVE_REPORT_LOCKED_SUBSCRIBER_AMOUNT = "NumberofLockedSubscribers";						//Key
				private final static String ACTIVE_REPORT_NUMBER_OF_BORROWED_BOOKS = "NumberofBorrowedBooks";	
				private final static String ACTIVE_REPORT_NUMBER_OF_LATE_RETURN_SUBSCRIBER = "NumberofLateReturnSubscribers";			//Key				
					
		/**
		 * HashMap contains EQueryOption as key
		 * and number of parameters required as value.
		 */
		private static HashMap<EQueryOption, Integer> enumParamNum = startMap();
		
		/**
		 * Static initialization of enumParameterNumber
		 * @return initialized HashMap
		 */
		private static HashMap<EQueryOption, Integer> startMap()
	    {
			HashMap<EQueryOption, Integer> map = new HashMap<EQueryOption,Integer>();
			map.put(EQueryOption.LOGIN_REQUEST, 2); //Parameters: UserName, Password.
	        map.put(EQueryOption.GET_STUDENT_INFO, 1);		// Parameters: ID.
	        map.put(EQueryOption.SAVE_STUDENT_INFO, 3);      //userid , email,phone;
	        map.put(EQueryOption.UPDATE_STATUS_MEMBERSHIP, 2);	// Parameters:ID, StatusMembership.
	        map.put(EQueryOption.GET_BORROWED_BOOK_INFO, 1); // Parameters:,userId.
	        map.put(EQueryOption.GET_BOOK_INFO, 4); // Parameters: BookTitle, BookAuthor, BookSubject, BookDescription;
	        map.put(EQueryOption.ADD_READER_CARD, 6);// Parameters: StudentID, StudentName, StudentPassword, PhoneNumber, Email;
	        map.put(EQueryOption.GET_STUDENT_NAME, 1); // Parameters: StudentName.
	        map.put(EQueryOption.ADD_BORROWED_BOOK, 5);// Parameters: bookID, userID, borrowDate, returnDate, borrowStatus;
	        map.put(EQueryOption.ADD_BORROWED_BOOK_HISTORY,3);// Parameters: bookID, userID, borrowDate;
	        map.put(EQueryOption.DELETE_BORROWED_BOOK, 1);// Parameters: ISBN;	 
	        map.put(EQueryOption.SET_BOOK_AVAILABILITY_ON, 1);// Parameters: bookID;
	        map.put(EQueryOption.SET_BOOK_AVAILABILITY_OFF, 1);// Parameters: bookID;
	        map.put(EQueryOption.GET_BOOK_BORROW_HISTORY,1);// Parameters: userID;
	        map.put(EQueryOption.RETURN_BORROWED_BOOK, 3);// Parameters: ISBN, returnDate, retutnStatus;			      
	        map.put(EQueryOption.GET_BOOK_BORROW_HISTORY,1);// Parameters: userID;
	        map.put(EQueryOption.GET_BORROW_INFO, 2);// Parameters: borrower_id,ISBN;
	        map.put(EQueryOption.INCREASE_BORROW_DURATION, 0);
	        map.put(EQueryOption.INCREASE_RETURN_DELAY, 0);
	        map.put(EQueryOption.ADD_USER,3);
	        map.put(EQueryOption.NUM_OF_STUDENTS,1);

	        
	        map.put(EQueryOption.SUBSCRIBERS_COUNTER_IN_A_STATUS,3);	// Parameters: fromDate,toDate,status;
	        map.put(EQueryOption.BORROWED_BOOK_COUNTER_FROM_TO,2);	// Parameters: fromDate,toDate,status;
	        map.put(EQueryOption.DELAYING_BOOK_RETURN_SUBSCRIBER_COUNTER_FROM_TO,2);	// Parameters: fromDate,toDate,status;
	        map.put(EQueryOption.AVG_BORROW_DURATION, 1);
	        map.put(EQueryOption.MEDIAN_BORROW_DURATION, 1);	// Parameters: wantedStatus; ( Wanted OR Regular )
	        map.put(EQueryOption.AVG_LATE_RETURN_AMOUNT_AND_DURATION, 0);
	        map.put(EQueryOption.MEDIAN_DELAY_DURATION, 0);
	        map.put(EQueryOption.RETURN_BOOKS_THAT_CAN_BE_PROLONGED_ISBN_TABLE, 1);	// Parameters: today;	        
	        map.put(EQueryOption.UPDATE_BORROWED_BOOK_RETURN_DELAY, 1);	// Parameters: today; 
	        map.put(EQueryOption.INCREASE_BORROWED_BOOK_BORROW_DURATION, 0);
	        map.put(EQueryOption.SET_PROBLEMATIC_SUBSCRIBER_LOCKING_DURATION, 2);		// Parameters: subscriberID,lockingDuration;
	        map.put(EQueryOption.ADD_PROBLEMATIC_SUBSCRIBER, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.DELETE_SUBSCRIBER_FROM_PROBLEMATIC_SUBSCRIBER, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.SET_SUBSCRIBER_STATUS_ACTIVE, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.SET_RETURN_DATE_IN_BORROWED_BOOK_HISTORY, 1);	// Parameters: ISBN;
	        map.put(EQueryOption.UPDATE_SUBSCRIBER_STATUS_TO_ACTIVE, 1);	// Parameters: subscriberID;
	        map.put(EQueryOption.GET_BORROWER_ID, 1);	// Parameters: ISBN;
	        map.put(EQueryOption.UPDATE_RETURN_DATE_USER_STATUS, 1);	// Parameters: ISBN;
	        map.put(EQueryOption.SUBSCRIBER_MANUAL_PROLONGATION,1); //ISBN;
	        map.put(EQueryOption.LIBRARIAN_MANUAL_PROLONGATION,1); //ISBN;
	        map.put(EQueryOption.ADD_ACTIVITY_REPORT,7); //FromDate,ToDate,NumberofActiveSubscribers,NumberofFrozenSubscribers,NumberofLockedSubscribers,NumberofLateReturnSubscribers ,NumberofBorrowedBooks;
	        map.put(EQueryOption.FILL_ACTIVITY_REPORT_COMBO_BOX,1); 
	        map.put(EQueryOption.GET_ACTIVITY_REPORT_INFO,2); //FromDate
	        map.put(EQueryOption.MEDIAN_DELAY_AMOUNT,1);
	        map.put(EQueryOption.ALL_BOOKS_DELAY_DISTRIBUTION,1);
	        map.put(EQueryOption.UPDATE_SUBSCRIBER_AND_BOOK_DELAY_STATUS, 1);// Parameters: today;
	        map.put(EQueryOption.ALL_BOOKS_DELAY_AMOUNT_DISTRIBUTION,1);
	        map.put(EQueryOption.BOOK_DELAY_DISTRIBUTION,1);
	        map.put(EQueryOption.BOOK_DELAY_AMOUNT_DISTRIBUTION,1);
	        map.put(EQueryOption.BORROW_DURATION_DISTRIBUTION,1);
	        
	        return map;
	    }
		
		
		/**
		 * Get suitable query
		 * Parameters order must be as table columns
		 * @param queryOption 
		 * @return Query string
		 */
		public static String getQuery(EQueryOption queryOption, List<String> Parameters) throws Exception{
			//System.out.println(Parameters);
			/*//System.out.println("size: "+Parameters.size());
			if (Parameters.size() != enumParamNum.get(queryOption)) {
				//System.out.println("got you!!");
				return "";
				// TODO: add invalid parameters number error or Exception 
			}*/
			
			switch(queryOption) {
			case LOGIN_REQUEST:
				return LoginRequest(Parameters.get(0),Parameters.get(1));	
			case GET_STUDENT_INFO:
				return getStudentInfo(Parameters.get(0));
			case SAVE_STUDENT_INFO:
				return saveStudentInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2));
			case GET_BORROWED_BOOK_INFO:
				return getBorrowedBookInfo(Parameters.get(0));
			case GET_BOOK_BORROW_HISTORY:
				return getBookBorrowHistory(Parameters.get(0));	
			//case UPDATE_STATUS_MEMBERSHIP:GET_BOOK_BORROW_HISTORY
				//return updateStudentInfo(Parameters.get(0),Parameters.get(1));
			case NUM_OF_STUDENTS:

				return numOfStudents(Parameters.get(0));
			case GET_BOOK_INFO:
				//if(enumParamNum.get(queryOption)== 4) 
				return getBookInfo(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3));
				//else 
					//return getBookInfo(Parameters.get(0));	
			case ADD_USER:
				return addUser(Parameters.get(0),Parameters.get(1),Parameters.get(2));	
			case ADD_READER_CARD:
				return addReaderCard(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),Parameters.get(5));
				
			case GET_STUDENT_NAME:
				return getStudentName(Parameters.get(0));
				
			case ADD_BORROWED_BOOK:
				return addBorrowedBook(Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4));
				
			case ADD_BORROWED_BOOK_HISTORY:
				return addBorrowedBookHistory(Parameters.get(0),Parameters.get(1),Parameters.get(2));
				
			case DELETE_BORROWED_BOOK:
				return deleteBorrowedBook(Parameters.get(0));
				
			case RETURN_BORROWED_BOOK:
				return setReturnedBookInfo(Parameters.get(0),Parameters.get(1));
				
			case GET_BORROW_INFO:
				return getBorrowInfo(Parameters.get(0),Parameters.get(1));
			
			case SET_BOOK_AVAILABILITY_OFF:
				return setBookAvailabilityOFF(Parameters.get(0));
				
			case SET_BOOK_AVAILABILITY_ON:
				return setBookAvailabilityON(Parameters.get(0));	
				
			case INCREASE_BORROW_DURATION:
				return increaseBorrowDuration();
				
			case INCREASE_RETURN_DELAY:
				return increaseReturnDelay();
				
			case UPDATE_SUBSCRIBER_AND_BOOK_DELAY_STATUS:
				return updateSubscriberAndBookDelayStatus(Parameters.get(0));
			
			case SET_RETURN_DATE_IN_BORROWED_BOOK_HISTORY:
				return setReturnDateInBorrowedBookHistory(Parameters.get(0));
			
			case UPDATE_SUBSCRIBER_STATUS_TO_ACTIVE:
				return updateSubscriberStatusToActive (Parameters.get(0));
			
			case GET_BORROWER_ID:
				return getBorrowerID(Parameters.get(0));
				
			case UPDATE_RETURN_DATE_USER_STATUS:
				return updateReturnDateAndUserStatus(Parameters.get(0));
			
			/**
			 * system update
			 */
			case RETURN_BOOKS_THAT_CAN_BE_PROLONGED_ISBN_TABLE:
				return findBooksThatCanBeProlonged(Parameters.get(0));
			case UPDATE_BORROWED_BOOK_RETURN_DELAY:
				return updateBorrowedBookReturnDelay(Parameters.get(0)); 
			case INCREASE_BORROWED_BOOK_BORROW_DURATION:
				return increaseBorrowedBookBorrowDuration();
			case SET_PROBLEMATIC_SUBSCRIBER_LOCKING_DURATION:
				return setProblematicSubscriberLockingDuration(Parameters.get(0),Parameters.get(1)); 
			case ADD_PROBLEMATIC_SUBSCRIBER:
				return addProblematicSubscriber(Parameters.get(0)); 
			case DELETE_SUBSCRIBER_FROM_PROBLEMATIC_SUBSCRIBER:
				return deleteProblematicSubscriber(Parameters.get(0));
			case SET_SUBSCRIBER_STATUS_ACTIVE:
				return setSubscriberStatusActive(Parameters.get(0));			
			/**
			 * Activity report	
			 */
			case SUBSCRIBERS_COUNTER_IN_A_STATUS:
				return subscriberCounterInSpecificStatus(Parameters.get(0),Parameters.get(1),Parameters.get(2));				
			case BORROWED_BOOK_COUNTER_FROM_TO:
				return borrowedBookCounter(Parameters.get(0),Parameters.get(1));
			case DELAYING_BOOK_RETURN_SUBSCRIBER_COUNTER_FROM_TO:
				return notReturnBookCounter(Parameters.get(0),Parameters.get(1));
			case ADD_ACTIVITY_REPORT:
				return addActivityReport (Parameters.get(0),Parameters.get(1),Parameters.get(2),Parameters.get(3),Parameters.get(4),Parameters.get(5),Parameters.get(6));
			case FILL_ACTIVITY_REPORT_COMBO_BOX:
				return fillActivityReportComboBox(Parameters.get(0));
			case GET_ACTIVITY_REPORT_INFO:
				return getActivityReportInfo(Parameters.get(0),Parameters.get(1));
				
			/**
			 * Borrow report 
	    	 */
			case AVG_BORROW_DURATION:
				return avgBorrowDuration(Parameters.get(0));
			case MEDIAN_BORROW_DURATION:
				return medianBorrowDuration(Parameters.get(0));
				
			/**
			 * Return Delay report 
			 */	
			case AVG_LATE_RETURN_AMOUNT_AND_DURATION:
				return avgNumberOfLateReturnsAndAvgDelayDuration();
			case MEDIAN_DELAY_DURATION:
				return medianDelayDuration();
			case LIBRARIAN_MANUAL_PROLONGATION:
				return librarianManualProlongation(Parameters.get(0));
			case SUBSCRIBER_MANUAL_PROLONGATION:
				return subscriberManualProlongation(Parameters.get(0));
			case MEDIAN_DELAY_AMOUNT:
				return medianDelayAmount(Parameters.get(0));
			case ALL_BOOKS_DELAY_DISTRIBUTION:
				return allBooksDelayDistribution(Parameters.get(0));
			case BOOK_DELAY_DISTRIBUTION:
				return bookDelayDistribution(Parameters.get(0));
			case ALL_BOOKS_DELAY_AMOUNT_DISTRIBUTION:
				return allBooksDelayAmountDistribution(Parameters.get(0));
			case BOOK_DELAY_AMOUNT_DISTRIBUTION:
				return bookDelayAmountDistribution(Parameters.get(0));
			case BORROW_DURATION_DISTRIBUTION:
				return borrowDurationDistribution(Parameters.get(0)); 
				
				
					
				
				
				
			default:
					return "";	// TODO: add error or exception (invalid enum option).
			}
		}


		private static String getBookBorrowHistory(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn =  "SELECT " + BORROWED_BOOK_HISTORY_ISBN + ","+ BORROWED_BOOK_USER_HISTORY_ID +","+ BORROWED_BOOK_BORROW_HISTORY_DATE + " , " + BORROWED_BOOK_RETURN_HISTORY_DATE + " , " + BORROWED_BOOK_BORROW_HISTORY_STATUS + " FROM " + BORROWED_BOOK_HISTORY_TABLE + " WHERE " +
					BORROWED_BOOK_USER_HISTORY_ID + " = " + ID+";";
			return queryToReturn;
		}


		private static String saveStudentInfo(String ID, String email, String phone) {
			ID = "\'"+ ID+ "\'";
			email = "\'"+ email+ "\'";
			phone = "\'"+ phone+ "\'";
			String queryToReturn = "UPDATE " + STUDENT_TABLE + " SET " + STUDENT_EMAIL + " = " + email +" , " + STUDENT_PHONE_NUMBER + "=" + phone + " WHERE " + STUDENT_ID + " = " + ID +  " ;";
			return queryToReturn;
			
		}


		/**
		 * Get query string for getting full product info from student table
		 * by studentID.
		 * @param studentID
		 * @return Student Info query string.
		 */
		
		private static String getStudentInfo(String ID) {
			ID = "\'"+ ID+ "\'";
			String queryToReturn = "SELECT " +  STUDENT_NAME+ ","+ STUDENT_ID +","+ SUBSCRIBER_NUMBER + " , " + STUDENT_EMAIL + " , " + STUDENT_PHONE_NUMBER + " , " + STUDENT_PASSWORD + " FROM " + STUDENT_TABLE + " WHERE " +
					STUDENT_ID + " = " + ID+";";
			return queryToReturn;
		}
		
		//SELECT StudentName,StudentID,StudentSubscriberNumber,Email,PhoneNumber FROM obl.student WHERE StudentID = 325;
		


		/** 
		 * Get query string for updating product info.
		 * @param productID new ProductID string
		 * @param productName new Product Name
		 * @param productType new Product Type
		 * @return product info update query string.
		 */
		
		
		//SELECT AccountType,UserName,StatusMebership FROM obl.user WHERE UserID = 325;
		private static String LoginRequest (String UserID, String UserPassword) {
			UserID = "\'"+ UserID+ "\'";
			UserPassword = "\'"+ UserPassword+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + ","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP + "," + USER_ID +  " FROM " + USER_TABLE + " WHERE " +
					USER_ID + " = " + UserID + " AND "+ PASSWORD + " = " + UserPassword+ " ;";	
		
			return queryToReturn;
		}
		
		private static String getBookInfo(String bookTitle, String bookAuthor,String bookSubject, String bookDescription) {
			bookTitle = "\'"+ bookTitle+ "\'";
			bookAuthor = "\'"+ bookAuthor+ "\'";
			bookSubject = "\'"+ bookSubject+ "\'";
			String	bookDescription2 = bookDescription;
			bookDescription = "\'"+ bookDescription+ "\'";

			String queryToReturn = "SELECT " + CATALOG_NUMBER + ","+ BOOK_TITLE +","+ BOOK_LOCATION + "," + AVAILABLE_COPY +
					" FROM " + BOOK_TABLE + " WHERE " + BOOK_TITLE + "=" + bookTitle +" OR "+
					BOOK_AUTHOR + " = " + bookAuthor + " OR " + BOOK_SUBJECT  + " = " + bookSubject + " OR (" + BOOK_DESCRIPTION +" LIKE "+ "'%"+ bookDescription2+"%' "+ "AND "+bookDescription + " != "+ "''"+");";
			return queryToReturn;		
		}
		
		
		private static String getBorrowedBookInfo(String borrowerID) {
			borrowerID = "\'"+ borrowerID+ "\'";
			//bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "SELECT " + BORROWED_BOOK_ISBN  + ","+ BORROWED_BOOK_BORROWER_ID +","+ BORROWED_BOOK_BORROW_DATE + "," + BORROWED_BOOK_RETURN_DATE +
					"," + BORROWED_BOOK_BORROW_STATUS + " FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_BORROWER_ID + "=" + borrowerID + " ;";				
			return queryToReturn;
		}

		/* 
		 * 	Add new borrowed book
		 * 
		 *  INSERT INTO  obl.borrowedbook (ISBN, borrowerID, borrowDate, returnDate)
		 *	VALUE ('0001','325','28.01.2019', '11.02.2019');
		 */
		private static String addBorrowedBook(String bookID, String userID, String borrowDate, String returnDate, String borrowStatus) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			borrowStatus = "\'"+ borrowStatus+ "\'";
			String queryToReturn = "INSERT INTO " + BORROWED_BOOK_TABLE + "(" + BORROWED_BOOK_ISBN +","+ BORROWED_BOOK_BORROWER_ID +","+ BORROWED_BOOK_BORROW_DATE +","+ BORROWED_BOOK_RETURN_DATE +","+ BORROWED_BOOK_BORROW_STATUS + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +","+ returnDate +","+ borrowStatus + ")" + ";";
			return queryToReturn;
		}
		
		/* 
		 * 	Add borrowed book to history
		 * 
		 *  INSERT INTO  obl.borrowed_book_history (ISBN, borrowerID, borrowDate, borrowTime)
		 *	VALUE ('0001','325','28.01.2019', CURRENT_TIME());
		 */
		private static String addBorrowedBookHistory(String bookID, String userID, String borrowDate) {
			bookID = "\'"+ bookID+ "\'";
			userID = "\'"+ userID+ "\'";
			borrowDate = "\'"+ borrowDate+ "\'";
			
			String queryToReturn = "INSERT INTO " + BORROWED_BOOK_HISTORY_TABLE + "(" + BORROWED_BOOK_HISTORY_ISBN +","+ BORROWED_BOOK_USER_HISTORY_ID + "," + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + BORROWED_BOOK_BORROW_HISTORY_TIME + ")" + 
					"VALUE" + "(" + bookID +","+ userID +","+ borrowDate +", CURRENT_TIME()"+ ")" + ";";
			return queryToReturn;
		}
		
		
		/*
		 * when the book is returned delete book from "borrowed book" table
		 * 
		 * DELETE FROM obl.borrowedbook WHERE ISBN='0002';
		 */
		private static String deleteBorrowedBook(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "DELETE FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_ISBN +"=" + bookID + ";";
			return queryToReturn;
		}
		
		/*
		 * set book availability status to "not available" + update next return date
		 * 
		 * 	UPDATE obl.book 
    	 *	SET Available = 0,  NextReturnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y')      
    	 *	WHERE obl.book.ISBN = '0001';
		 * 
		 */ 
		private static String setBookAvailabilityOFF(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + " SET " + AVAILABLE_COPY + " = 0, " +
					NEXT_RETURN_DATE + " = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL "+ BOOK_TABLE +"."+ BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y') "+
					" WHERE "+ BOOK_TABLE +"."+ BOOK_ID + " = " + bookID + " ;";
			return queryToReturn;
		}
		
		/*
		 * set availability status of a book to available + update next return date (null)
		 * 
		 * UPDATE obl.book SET Available = 1, NextReturnDate = NULL
		 * WHERE obl.book.ISBN = '1001';
		 * 
		 */ 
		private static String setBookAvailabilityON(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + " SET " + AVAILABLE_COPY + " = 1, " + NEXT_RETURN_DATE + " = NULL " +
			" WHERE " + BOOK_TABLE +"."+ BOOK_ID + " = " + bookID + " ;";
			return queryToReturn;
		}
		
		
		
		/*
		 *set return date
		 * 
		 * UPDATE obl.borrowed_book_history 
		 * SET returnDate = DATE_FORMAT( CURRENT_DATE() , '%d.%m.%Y')  
		 * WHERE obl.borrowed_book_history.ISBN = '12345' 
		 * AND obl.borrowed_book_history.returnDate IS NULL;
		 */
		private static String setReturnDateInBorrowedBookHistory(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_HISTORY_TABLE + 
					" SET " + BORROWED_BOOK_RETURN_HISTORY_DATE + " = DATE_FORMAT( CURRENT_DATE() , '%d.%m.%Y') " +
					" WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " = " + bookID + 
					" AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL;";
			return queryToReturn;
		}
		
		/*
		 *update subscriber status to Active if returned book was his only one that in delayed return status
		 *
		 * 	UPDATE obl.user SET
		 *	obl.user.StatusMembership = IF ((SELECT SUM(IF(obl.borrowedbook.borrowerID = '222' 
		 *			AND obl.borrowedbook.borrowStatus ='late',1,0)) AS SubscriberNumberOfNotReturnedBooks
         *			FROM obl.borrowedbook) = 0 ,'Active','Frozen')
         *	WHERE obl.user.UserID ='222';
		 */
		private static String updateSubscriberStatusToActive(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "UPDATE " + USER_TABLE + " SET "+
					USER_TABLE + "." + STATUS_MEMBERSHIP + " = IF ((SELECT SUM(IF(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + " = " + subscriberID + 
					" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "='late',1,0)) AS SubscriberNumberOfNotReturnedBooks "+
			        " FROM " + BORROWED_BOOK_TABLE + " ) = 0 ,'Active','Frozen') " +
			        " WHERE " + USER_TABLE + "." + USER_ID + " =" + subscriberID +";";
			return queryToReturn;
		}
		
		/*
		 *get borrower ID
		 *SELECT borrowerID FROM obl.borrowedBook WHERE obl.borrowedBook.ISBN = '12345';
		 */
		private static String getBorrowerID(String bookID) {
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = "SELECT " + BORROWED_BOOK_BORROWER_ID + " FROM " + BORROWED_BOOK_TABLE + " WHERE " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + "=" + bookID +";";
			return queryToReturn;
		}
		
		
		
		/*
		 * 
		 * 	SET SQL_SAFE_UPDATES = 0;
		 * 	UPDATE obl.borrowed_book_history, obl.user 
		 * 	SET obl.borrowed_book_history.returnDate = DATE_FORMAT( CURRENT_DATE() , '%d.%m.%Y'),
		 * 		obl.user.StatusMembership = IF ((SELECT SUM(IF(obl.borrowedbook.borrowerID = obl.borrowed_book_history.borrowerID 
		 *		AND obl.borrowedbook.borrowStatus ='late',1,0)) AS SubscriberNumberOfNotReturnedBooks
		 *		FROM obl.borrowedbook) = 0 ,'Active','Frozen')	
		 *	WHERE obl.borrowed_book_history.ISBN = '12345' 
		 *		AND obl.user.UserID = obl.borrowed_book_history.borrowerID
		 *		AND obl.borrowed_book_history.returnDate='';
		 * 
		 */
		//////////////////////////////problem////////////////////////
		private static String updateReturnDateAndUserStatus(String bookID)
		{
			bookID = "\'"+ bookID+ "\'";
			String queryToReturn = /*"SET SQL_SAFE_UPDATES = 0; " + */
			"UPDATE " + BORROWED_BOOK_HISTORY_TABLE + " , " + USER_TABLE +		
			" SET " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " = DATE_FORMAT( CURRENT_DATE() , \'%d.%m.%Y\'), " +
			USER_TABLE + "." + STATUS_MEMBERSHIP + " = IF ((SELECT SUM(IF(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + " = " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_USER_HISTORY_ID + 
				" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + " =\'late\',1,0)) AS SubscriberNumberOfNotReturnedBooks " +
				"FROM " + BORROWED_BOOK_TABLE + " ) = 0 ,\'Active\',\'Frozen\') " +	
			"WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " = " + bookID +
				" AND " + USER_TABLE + "." + USER_ID + " = " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_USER_HISTORY_ID +
				" AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL;";
			
			return queryToReturn;
		}

		
		
		/* 
		 * when borrowing book get subscriber's name for confirm book borrow window
		 * */
		private static String getStudentName(String studentID) {
			studentID = "\'"+ studentID+ "\'";
			String queryToReturn = "SELECT " + USER_NAME + " FROM " + USER_TABLE + " WHERE " + USER_ID + " = " +  studentID + " AND " + STATUS_MEMBERSHIP + " = " + "'Active'" + " ;";
			return queryToReturn;		
		}
		
		
		/* 
		 * when borrowing book get subscriber's name and borrow duration for book borrow window
		 * 
		 * SELECT UserName, StatusMembership, BorrowPeriod 
		 * FROM obl.user , obl.book  
		 * WHERE obl.user.UserID = '325' AND obl.book.ISBN = '12345';
		 * */
		private static String getBorrowInfo(String studentID, String isbn) {
			studentID = "\'"+ studentID + "\'";
			isbn = "\'"+ isbn + "\'";			
			String queryToReturn = "SELECT " + USER_NAME + " , " + STATUS_MEMBERSHIP + " , " + BOOK_BORROW_PERIOD + " FROM " +
					USER_TABLE + " , " + BOOK_TABLE + " WHERE " + 
					USER_TABLE + "." + USER_ID + " = " +  studentID + " AND " + BOOK_TABLE + "." + BOOK_ID + " = " + isbn + " ;";
			return queryToReturn;		
		}
		
		
		/*	
		 *  when book return clicked update "book" data base ( copy is available ) and "borrowed book history" data base ( the date of the return and the status of the return was it on time or late )
		 * 
		 *	UPDATE obl.borrowed_book_history,obl.book 
		 *  	SET obl.borrowed_book_history.returnDate='02.02.2019' , obl.borrowed_book_history.returnStatus = ( 
		 *   		SELECT borrowStatus 
		 *  			FROM obl.borrowedbook 
		 *  				WHERE obl.borrowedbook.ISBN = obl.borrowed_book_history.ISBN  ) ,
		 *	    obl.book.Available='1' 
		 *			WHERE obl.book.ISBN = obl.borrowed_book_history.ISBN AND 
		 *				obl.book.ISBN = '0003' AND obl.borrowed_book_history.returnDate IS NULL;
		 * */
		/////////////////////////////////problem//////////////////////////////////
		private static String setReturnedBookInfo(String bookID, String returnDate) {
			bookID = "\'"+ bookID+ "\'";
			returnDate = "\'"+ returnDate+ "\'";
			String one = "\'"+ 1+ "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_HISTORY_TABLE +","+ BOOK_TABLE + 
					" SET " + BORROWED_BOOK_HISTORY_TABLE +"."+ BORROWED_BOOK_RETURN_HISTORY_DATE +"="+ returnDate + "," + BORROWED_BOOK_HISTORY_TABLE + "," + BORROWED_BOOK_BORROW_HISTORY_STATUS + "=" + "(" +
						" SELECT " + BORROWED_BOOK_BORROW_STATUS +
							" FROM " + BORROWED_BOOK_TABLE +
								" WHERE " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + "=" +BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + ")" + "," +
					BOOK_TABLE + "." + AVAILABLE_COPY + "=" + one +	
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + " AND " 
							+ BOOK_TABLE + "." + BOOK_ID + "=" + bookID + " AND " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NULL " + ";";
			return queryToReturn;
		}
		
		private static String addReaderCard(String studentName, String studentID, String email, String phoneNumber, String studentPassword, String numOfStudents  ) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			phoneNumber = "\'"+ phoneNumber+ "\'";
			email = "\'"+ email+ "\'";
			numOfStudents = "\'"+ numOfStudents+ "\'";
			String queryToReturn = "INSERT INTO " + STUDENT_TABLE + "(" + STUDENT_ID +","+ STUDENT_NAME +","+ STUDENT_PASSWORD +","+ STUDENT_PHONE_NUMBER +","+ STUDENT_EMAIL + "," + STUDENT_STATUS_MEMBERSHIP + "," + FREEZE +","+  SUBSCRIBER_NUMBER +")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ phoneNumber +","+ email + "," + "\'" + "Active"+ "\'" + "," + 0 +", "+ numOfStudents  +");";
			return queryToReturn;
		}
		
		
		private static String addUser(String studentID, String studentName, String studentPassword) {
			studentID = "\'"+ studentID+ "\'";
			studentName = "\'"+ studentName+ "\'";
			studentPassword = "\'"+ studentPassword+ "\'";
			String queryToReturn = "INSERT INTO " + USER_TABLE + "(" + USER_ID +","+ USER_NAME +","+ PASSWORD +","+ ACCOUNT_TYPE +","+ STATUS_MEMBERSHIP +","+ FREEZE + ")" + 
					"VALUE" + "(" + studentID +","+ studentName +","+ studentPassword +","+ "\'" + "Student"+ "\'" + "," + "\'" + "Active"+ "\'"+ "," + 0 + ")"+";";
			return queryToReturn;
		}
		
		
		
		
		
		/*
		 * daily update of borrowed books borrow duration
		 * 
		 * 	UPDATE obl.book,obl.borrowedbook 
		 * 		SET obl.book.BorrowDuration = (BorrowDuration + 1) 
		 *			WHERE obl.book.ISBN = obl.borrowedbook.ISBN;
		 */
		private static String increaseBorrowDuration() {
			String queryToReturn = "UPDATE " + BOOK_TABLE +","+ BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE +"."+ BOOK_BORROW_DURATION + "=" + "(" + BOOK_BORROW_DURATION + "+" + 1 + ")" +
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + ";";
			return queryToReturn;
		}
		
		
		/*
		 * daily update of not returned return delay
		 * 
		 *	UPDATE obl.book,obl.borrowedbook 
		 *		SET obl.book.ReturnDelay = (ReturnDelay + 1) 
		 *			WHERE obl.book.ISBN = obl.borrowedbook.ISBN 
		 *				AND obl.borrowedbook.borrowStatus='late';
		 */
		private static String increaseReturnDelay() {
			String queryToReturn = "UPDATE " + BOOK_TABLE +","+ BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE +"."+ BOOK_RETURN_DELAY + "=" + "(" + BOOK_RETURN_DELAY + "+" + 1 + ")" +
						" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
						" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "=" + "'late'" + ";";
			return queryToReturn;
		}
		
		
		/*
		 * update borrowStatus and subscriber status when book return delay
		 * 
		 *	UPDATE obl.borrowedbook ,obl.user
		 *	SET borrowStatus='late' ,obl.user.StatusMembership='Frozen',obl.user.FreezeCounter = (FreezeCounter+1)
		 *	WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < 
		 *	STR_TO_DATE('25.01.2019', "%d.%m.%Y") 
		 *	AND obl.user.UserID = obl.borrowedbook.borrowerID 
		 *	AND obl.borrowedbook.borrowStatus='ok';
		 */
		private static String updateSubscriberAndBookDelayStatus(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "UPDATE " + BORROWED_BOOK_TABLE +","+ USER_TABLE + 
					" SET " + BORROWED_BOOK_BORROW_STATUS +"='late' ," + USER_TABLE + "." + STATUS_MEMBERSHIP + "=" + "'Frozen'," + USER_TABLE + "." + USER_FREEZE_COUNTER + "=" + "(" + USER_FREEZE_COUNTER + "+1) "+
					" WHERE " + " STR_TO_DATE " + "(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "," + format + ")" + "<" + 
					" STR_TO_DATE " + "(" + today + "," + format + ")" + 
					" AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + 
					" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + "='ok';";					
			return queryToReturn;
		}
		
		/*
		 * update borrowed book return delay
		 * 
		 * 	UPDATE obl.book,obl.borrowedbook 
		 *	SET obl.book.ReturnDelay = (ReturnDelay + 1) 
		 *	WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < 	
		 *	STR_TO_DATE('25.01.2019', "%d.%m.%Y") 
		 *	AND obl.book.ISBN = obl.borrowedbook.ISBN;
		 */
		private static String updateBorrowedBookReturnDelay(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "UPDATE " + BOOK_TABLE + "," + BORROWED_BOOK_TABLE +  
					" SET " + BOOK_TABLE + "." + BOOK_RETURN_DELAY + "= (" + BOOK_RETURN_DELAY + " + 1) "+ 
					" WHERE " + " STR_TO_DATE " + "(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "," + format + ")" + "<" + 
					" STR_TO_DATE " + "(" + today + "," + format + ")" + 
					" AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN +";";					
			return queryToReturn;
		}
		
		/*
		 * increase borrowed book borrow duration
		 * 
		 * 	UPDATE obl.book,obl.borrowedbook 
		 *	SET obl.book.BorrowDuration = (BorrowDuration + 1) 
		 *	WHERE obl.book.ISBN = obl.borrowedbook.ISBN;
		 */
		private static String increaseBorrowedBookBorrowDuration() {
			String queryToReturn = "UPDATE " + BOOK_TABLE + "," + BORROWED_BOOK_TABLE + 
					" SET " + BOOK_TABLE + "." + BOOK_BORROW_DURATION + "= (" + BOOK_BORROW_DURATION + " +1) "+
					" WHERE " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN +";";					
			return queryToReturn;
		}

		
		
		private static String numOfStudents( String Mock ) {
			
			String queryToReturn = "SELECT " + " COUNT(*) FROM " + STUDENT_TABLE + ";" ; 
			return queryToReturn;
		}
		//SELECT COUNT(*) FROM obl.student;
		
		
		/**
		 * Problematic Subscribers
		 */
		
		/*
		 * add new problematic subscriber
		 * 
		 * INSERT INTO obl.problematicsubscribers ( SubscribersID )
		 * SELECT obl.user.UserID
    	 * FROM obl.user WHERE obl.user.FreezeCounter >= 3;
		 */
		/////////////////////////////problem//////////////////////////////////////
		private static String addProblematicSubscriber(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "INSERT INTO " + PROBLEMATIC_SUBSCRIBERS_TABLE +"("+ subscriberID +")"+
						" SELECT " + USER_TABLE +"."+USER_ID +
						" FROM " + USER_TABLE + " WHERE " + USER_TABLE + "." + USER_FREEZE_COUNTER + " >= 3;";
			return queryToReturn;
		}
		
		
		/*
		 * delete problematic subscriber
		 * 
		 * 	DELETE FROM obl.problematicsubscribers 
		 *	WHERE obl.problematicsubscribers.SubscribersID = '111'; 
    	 *	*****AND EXISTS (SELECT 1 FROM obl.user WHERE obl.user.UserID = '111');*****
		 */
		private static String deleteProblematicSubscriber(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "DELETE FROM " + PROBLEMATIC_SUBSCRIBERS_TABLE +
						" WHERE " + PROBLEMATIC_SUBSCRIBERS_TABLE + "." + PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID + "=" + subscriberID + ";";
			return queryToReturn;
		}
		
		/*
		 * set subscribers status Active
		 * 
		 * 	UPDATE obl.user SET StatusMembership = 'Active' WHERE obl.user.UserID = '111';
		 */
		private static String setSubscriberStatusActive(String subscriberID) {
			subscriberID = "\'"+ subscriberID+ "\'";
			String queryToReturn = "UPDATE " + USER_TABLE + " SET " + STATUS_MEMBERSHIP + "= 'Active'" +
					 " WHERE " + USER_TABLE +"." + USER_ID + "=" + subscriberID +");";
			return queryToReturn;
		}
		

		/*
		 * set problematic subscriber locking day as today and set unlocking date 14(num of days can be modified) days from today
		 * 
		 * 	SET SQL_SAFE_UPDATES=0;		//error code 1175
		 *	UPDATE obl.problematicsubscribers 
		 *	SET LockingDate = CURRENT_DATE(), UnlockingDate = DATE_ADD(LockingDate, INTERVAL 14 DAY)
		 *	WHERE obl.problematicsubscribers.SubscribersID = 222;
		 */		
		private static String setProblematicSubscriberLockingDuration(String subscriberID,String lockingDuration) {
			subscriberID = "\'"+ subscriberID+ "\'";
			lockingDuration = "\'"+ lockingDuration+ "\'";
			String queryToReturn = "SET SQL_SAFE_UPDATES=0; " +
					" UPDATE " + PROBLEMATIC_SUBSCRIBERS_TABLE +
					" SET " + PROBLEMATIC_SUBSCRIBERS_LOCK_DATE + " = CURRENT_DATE()," + 
					PROBLEMATIC_SUBSCRIBERS_UNLOCK_DATE +" = DATE_ADD("+ PROBLEMATIC_SUBSCRIBERS_LOCK_DATE +", INTERVAL " + lockingDuration + " DAY) " +
					" WHERE " + PROBLEMATIC_SUBSCRIBERS_TABLE +"."+ PROBLEMATIC_SUBSCRIBERS_SUBSCRIBER_ID + "=" + subscriberID +";";
			return queryToReturn;
		}

		
		/**
		 * System daily check
		 */
		/*
		 * return ISBNs of books that can be prolonged
		 * 
		 * 	SELECT obl.borrowedbook.ISBN FROM obl.borrowedbook ,obl.book
		 *		WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < DATE_ADD('25.01.2019', INTERVAL 7 DAY) // 25.01.2019=today
		 *		AND obl.book.BorrowPeriod = 14 AND obl.book.ISBN = obl.borrowedbook.ISBN 
		 *		AND obl.borrowedbook.borrowStatus='ok' AND obl.book.WantedTag = 'Regular';
		 */
		private static String findBooksThatCanBeProlonged(String today) {
			today = "\'"+ today+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT "+ BORROWED_BOOK_TABLE +"." + BORROWED_BOOK_ISBN + " FROM " + BORROWED_BOOK_TABLE + "," + BOOK_TABLE + 
					" WHERE STR_TO_DATE(" + BORROWED_BOOK_TABLE + "."+BORROWED_BOOK_RETURN_DATE+","+format+") < DATE_ADD(" + today + ", INTERVAL 7 DAY) "+ 
					" AND "+ BOOK_TABLE +"." + BOOK_BORROW_PERIOD + " = 14 AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN +
					" AND "+ BORROWED_BOOK_TABLE + "."+BORROWED_BOOK_BORROW_STATUS+"='ok' AND "+BOOK_TABLE+"." + BOOK_NUMBER_WANTEDTAG + "= 'Regular';";
			return queryToReturn;
		}
		


		
		
		
		
		
		
		
		/**
		 * Activity report queries
		 */
		
		/*
		 *return number of ACTIVE/LOCKED/FROZEN subscribers 
		 * 
		 * 	SELECT SUM(IF(STR_TO_DATE('01.01.2019', "%d.%m.%Y") 
		 *		BETWEEN STR_TO_DATE(obl.subscriber_status_history.beginningDate, "%d.%m.%Y")
		 *		AND STR_TO_DATE(obl.subscriber_status_history.endDate, "%d.%m.%Y") 
         *  	OR STR_TO_DATE('14.01.2019', "%d.%m.%Y")
		 *		BETWEEN STR_TO_DATE(obl.subscriber_status_history.beginningDate, "%d.%m.%Y")
		 *		AND STR_TO_DATE(obl.subscriber_status_history.endDate, "%d.%m.%Y") 
         *   
         *  	OR STR_TO_DATE(obl.subscriber_status_history.beginningDate, "%d.%m.%Y") 
		 *		BETWEEN STR_TO_DATE('01.01.2019', "%d.%m.%Y")
		 *		AND STR_TO_DATE('14.01.2019', "%d.%m.%Y") 
         *   
         *  	OR STR_TO_DATE(obl.subscriber_status_history.endDate, "%d.%m.%Y")
		 *		BETWEEN STR_TO_DATE('01.01.2019', "%d.%m.%Y")
		 *		AND STR_TO_DATE('14.01.2019', "%d.%m.%Y")
         *  , 1 , 0 )) AS NumberOfFrozenSubscribers
		 *	FROM obl.subscriber_status_history WHERE 
		 *	obl.subscriber_status_history.subscriberStatus='Frozen';
		 */
		private static String subscriberCounterInSpecificStatus(String fromDate, String toDate, String status) {
		//	fromDate = "\'"+ fromDate+ "\'";
			//toDate = "\'"+ toDate+ "\'";
			//status = "\'"+ status+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT SUM(IF(STR_TO_DATE(" + "'" + fromDate + "'" + "," + format + ")" + 
					" BETWEEN STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_START_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_END_DATE + "," + format + ")" + 
		            
		            " OR STR_TO_DATE( " + "'" + toDate + "'" + "," + format + ")" +
					" BETWEEN STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_START_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_END_DATE + "," + format + ")" +  
		            
		            " OR STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_START_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            
					" OR STR_TO_DATE( " + SUBSCRIBER_STATUS_HISTORY_TABLE+ "." + SUBSCRIBER_STATUS_HISTORY_END_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            ", 1 , 0 )) AS NumberOfFrozenSubscribers " +
		            " FROM " + SUBSCRIBER_STATUS_HISTORY_TABLE + " WHERE " + 
		            SUBSCRIBER_STATUS_HISTORY_TABLE +"."+ SUBSCRIBER_STATUS_HISTORY_STATUS + "='" + status + "';";
			return queryToReturn;
		}
		
		/*
		 *return number of not returned books  
		 * 
		 *  SELECT SUM(IF(STR_TO_DATE('01.01.2019', "%d.%m.%Y") 
		 *		BETWEEN STR_TO_DATE(obl.borrowed_book_history.borrowDate, "%d.%m.%Y")
		 *		AND STR_TO_DATE(obl.borrowed_book_history.returnDate, "%d.%m.%Y") 
         *  	OR STR_TO_DATE('14.01.2019', "%d.%m.%Y")
		 *		BETWEEN STR_TO_DATE(obl.borrowed_book_history.borrowDate, "%d.%m.%Y")
		 *		AND STR_TO_DATE(obl.borrowed_book_history.returnDate, "%d.%m.%Y") 
         *   
         *  	OR STR_TO_DATE(obl.borrowed_book_history.borrowDate, "%d.%m.%Y") 
		 *		BETWEEN STR_TO_DATE('01.01.2019', "%d.%m.%Y")
		 *		AND STR_TO_DATE('14.01.2019', "%d.%m.%Y") 
         *  	OR STR_TO_DATE(obl.borrowed_book_history.returnDate, "%d.%m.%Y")
		 *		BETWEEN STR_TO_DATE('01.01.2019', "%d.%m.%Y")
		 *		AND STR_TO_DATE('14.01.2019', "%d.%m.%Y")
         *  , 1 , 0 )) AS NumberOfDelayedReturn
		 *  FROM obl.borrowed_book_history WHERE 
		 *  obl.borrowed_book_history.borrowStatus ='late';
		 */
		private static String notReturnBookCounter(String fromDate, String toDate) {	
		//	fromDate = "\'"+ fromDate+ "\'";
			//toDate = "\'"+ toDate+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT SUM(IF(STR_TO_DATE(" + "'" + fromDate + "'" + "," + format + ")" + 
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
		            
		            " OR STR_TO_DATE( " + "'" + toDate + "'" + "," + format + ")" +
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" +  
		            
		            " OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            
					" OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            ", 1 , 0 )) AS NumberOfDelayedReturn " +
		            " FROM " + BORROWED_BOOK_HISTORY_TABLE + " WHERE " + 
		            BORROWED_BOOK_HISTORY_TABLE +"."+ BORROWED_BOOK_BORROW_HISTORY_STATUS + "=" + "'late'" + ";";
			return queryToReturn;
		}
		/*
		 *return number of borrowed books 
		 *
		 *	SELECT SUM(IF(STR_TO_DATE('01.01.2019', "%d.%m.%Y") 
		 *		BETWEEN STR_TO_DATE(obl.borrowed_book_history.borrowDate, "%d.%m.%Y")
		 *		AND STR_TO_DATE(obl.borrowed_book_history.returnDate, "%d.%m.%Y") 
	     *      OR STR_TO_DATE('14.01.2019', "%d.%m.%Y")
		 *		BETWEEN STR_TO_DATE(obl.borrowed_book_history.borrowDate, "%d.%m.%Y")
		 *		AND STR_TO_DATE(obl.borrowed_book_history.returnDate, "%d.%m.%Y") 
	     *        
	     *      OR STR_TO_DATE(obl.borrowed_book_history.borrowDate, "%d.%m.%Y") 
		 *		BETWEEN STR_TO_DATE('01.01.2019', "%d.%m.%Y")
		 *		AND STR_TO_DATE('14.01.2019', "%d.%m.%Y") 
	     *      OR STR_TO_DATE(obl.borrowed_book_history.returnDate, "%d.%m.%Y")
		 *		BETWEEN STR_TO_DATE('01.01.2019', "%d.%m.%Y")
		 *		AND STR_TO_DATE('14.01.2019', "%d.%m.%Y")
         *      , 1 , 0 )) AS NumberOfBorrowedBooks
		 *	FROM obl.borrowed_book_history;
		 */
		private static String borrowedBookCounter(String fromDate, String toDate) {	
		//	fromDate = "\'"+ fromDate+ "\'";
			//toDate = "\'"+ toDate+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = "SELECT SUM(IF(STR_TO_DATE(" + "'" + fromDate + "'" + "," + format + ")" + 
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
		            
		            " OR STR_TO_DATE( " + "'" + toDate + "'" + "," + format + ")" +
					" BETWEEN STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" +
					" AND STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" +  
		            
		            " OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_BORROW_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            
					" OR STR_TO_DATE( " + BORROWED_BOOK_HISTORY_TABLE+ "." + BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + ")" + 
					" BETWEEN STR_TO_DATE(" + "'" + fromDate + "'," + format + ")" +
					" AND STR_TO_DATE(" + "'" + toDate +"'," + format + ")" +
		            ", 1 , 0 )) AS NumberOfBorrowedBooks " +
		            " FROM " + BORROWED_BOOK_HISTORY_TABLE + ";";
			return queryToReturn;
		}
		
		/*
		 * 
		 *  INSERT INTO obl.active_report (FromDate,ToDate,NumberofActiveSubscribers,NumberofFrozenSubscribers,NumberofLockedSubscribers,NumberofLateReturnSubscribers ,NumberofBorrowedBooks)
		 *	SELECT '01.01.2019','14.01.2019',5,2,0,3,5
    	 *	WHERE NOT EXISTS (SELECT FromDate,ToDate FROM obl.active_report WHERE FromDate='01.01.2019' AND ToDate ='14.01.2019');
		 */
		private static String addActivityReport(String FromDate, String ToDate, String NumberofActiveSubscribers, String NumberofFrozenSubscribers, String NumberofLockedSubscribers, String NumberofLateReturnSubscribers, String NumberofBorrowedBooks) {
			FromDate = "\'"+ FromDate+ "\'";
			ToDate = "\'"+ ToDate+ "\'";
			NumberofActiveSubscribers = "\'"+ NumberofActiveSubscribers+ "\'";
			NumberofFrozenSubscribers = "\'"+ NumberofFrozenSubscribers+ "\'";
			NumberofLockedSubscribers = "\'"+ NumberofLockedSubscribers+ "\'";
			NumberofLateReturnSubscribers = "\'"+ NumberofLateReturnSubscribers+ "\'";
			NumberofBorrowedBooks = "\'"+ NumberofBorrowedBooks+ "\'";
			String queryToReturn = "INSERT INTO " + ACTIVE_REPORT_TABLE + " (" + ACTIVE_REPORT_FROM_DATE +","+ ACTIVE_REPORT_TO_DATE +","+ ACTIVE_REPORT_ACTIVE_SUBSCRIBER_AMOUNT + ","+ ACTIVE_REPORT_FROZEN_SUBSCRIBER_AMOUNT +","+ ACTIVE_REPORT_LOCKED_SUBSCRIBER_AMOUNT + "," + ACTIVE_REPORT_NUMBER_OF_LATE_RETURN_SUBSCRIBER +","+ ACTIVE_REPORT_NUMBER_OF_BORROWED_BOOKS +")" + 
					" SELECT " + FromDate +","+ ToDate +","+ NumberofActiveSubscribers +","+ NumberofFrozenSubscribers +","+ NumberofLockedSubscribers + ","+ NumberofLateReturnSubscribers +","+ NumberofBorrowedBooks +
					" WHERE NOT EXISTS (SELECT " + ACTIVE_REPORT_FROM_DATE +","+ ACTIVE_REPORT_TO_DATE + " FROM " + ACTIVE_REPORT_TABLE + " WHERE " + ACTIVE_REPORT_FROM_DATE + "=" + FromDate + " AND " + ACTIVE_REPORT_TO_DATE + "=" + ToDate + ");"; 
			return queryToReturn;
		}
		 
		/*
		 * SELECT FromDate,ToDate FROM obl.active_report;
		 */
		private static String fillActivityReportComboBox(String mock) {
			String queryToReturn = "SELECT "+ ACTIVE_REPORT_FROM_DATE +","+ ACTIVE_REPORT_TO_DATE+" FROM " + ACTIVE_REPORT_TABLE +";";	
					return queryToReturn;
		}
		
		/*
		 * SELECT * FROM obl.active_report WHERE FromDate='01.01.2019';
		 */
		private static String getActivityReportInfo(String FromDate,String ToDate) {
			FromDate = "\'"+ FromDate+ "\'";
			ToDate = "\'"+ ToDate+ "\'";
			String queryToReturn = "SELECT  * FROM " + ACTIVE_REPORT_TABLE + " WHERE " + ACTIVE_REPORT_FROM_DATE +"="+FromDate+ " AND "+ACTIVE_REPORT_TO_DATE +" = " +  ToDate + ";";
					return queryToReturn;
		}
		
		

		/**
		 * Borrow report queries
		 */
		
		/*
		 *return AVG borrow duration for Wanted and Regular books
		 * 
		 * SELECT BorrowDuration FROM(
		 *		SELECT t1.WantedTag, AVG(t1.BorrowDuration) AS BorrowDuration 
		 *		FROM ( SELECT WantedTag, SUM(BorrowDuration) AS BorrowDuration
		 *			FROM obl.book GROUP BY CatalogNumber) AS t1
		 *		GROUP BY t1.WantedTag) AS t2
		 * WHERE t2.WantedTag = 'Wanted';
		 */
		private static String avgBorrowDuration(String wantedStatus) {
			wantedStatus = "\'"+ wantedStatus+ "\'";
			String queryToReturn = "SELECT BorrowDuration FROM("+
					" SELECT t1." + BOOK_NUMBER_WANTEDTAG +", AVG(t1." + BOOK_BORROW_DURATION + ") AS BorrowDuration " + 
			 	 " FROM (SELECT " + BOOK_NUMBER_WANTEDTAG +", SUM("+ BOOK_BORROW_DURATION +") AS BorrowDuration " +
	    	 		" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER +") AS t1 " +
			 " GROUP BY t1."+ BOOK_NUMBER_WANTEDTAG +") AS t2 " +
			 " WHERE t2."+ BOOK_NUMBER_WANTEDTAG + "=" + wantedStatus +";";
			return queryToReturn;
		}
		/*
		 *return median of book borrow duration
		 * 
		 * 	SELECT AVG(dd.BorrowDuration) as median_val
		 *	FROM (
		 *		SELECT t1.BorrowDuration , @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum
		 *		FROM (SELECT @rownum:=0) r 
		 *		,(SELECT WantedTag, SUM(BorrowDuration) AS BorrowDuration
		 *				FROM obl.book GROUP BY CatalogNumber) AS t1 
		 *		WHERE t1.BorrowDuration is NOT NULL AND t1.WantedTag = 'Regular'
		 *		ORDER BY t1.BorrowDuration
		 *	) as dd
		 *	WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );
		 */
		private static String medianBorrowDuration(String wantedStatus) {
			wantedStatus = "\'"+ wantedStatus+ "\'";
			String queryToReturn = "SELECT AVG(dd.BorrowDuration) as median_val "+
			 	" FROM ( " +
			 		" SELECT t1.BorrowDuration , @rownum:=@rownum+1 AS `row_number`, @total_rows:=@rownum "+
			 		" FROM (SELECT @rownum:=0) r "+
			 		",(SELECT "+ BOOK_NUMBER_WANTEDTAG +", SUM("+BOOK_BORROW_DURATION+") AS BorrowDuration"+
			 			" FROM " + BOOK_TABLE +" GROUP BY "+ CATALOG_NUMBER+") AS t1 "+
			 		" WHERE t1.BorrowDuration is NOT NULL AND t1.WantedTag = " + wantedStatus +
			 		" ORDER BY t1.BorrowDuration "+
			 	") as dd "+
			 " WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		/**
		 * Return Delay report queries
		 */
		
		/*
		 *return AVG number of late returns and the AVG return delay duration
		 * 
		 * 	SELECT (t2.ReturnDelayCounter)/count(*) AS ReturnDelayCounter, AVG(t1.ReturnDelayDuration) AS ReturnDelayDuration
		 *		FROM (
    	 *		SELECT SUM(ReturnDelay) AS ReturnDelayDuration
    	 *		FROM obl.book GROUP BY CatalogNumber) AS t1,
    	 *		(
    	 *		SELECT SUM(IF(obl.borrowed_book_history.borrowStatus = 'late', 1 , 0 )) AS ReturnDelayCounter
    	 *	FROM obl.borrowed_book_history ) AS t2;
		 */
		private static String avgNumberOfLateReturnsAndAvgDelayDuration() {
			String queryToReturn = "SELECT " + "(t2.ReturnDelayCounter)/count(*) AS ReturnDelayCounter, AVG(t1.ReturnDelayDuration) AS ReturnDelayDuration " +
					 		" FROM ( "+
					    	 	" SELECT SUM(" + BOOK_RETURN_DELAY +") AS ReturnDelayDuration "+
					    	 	" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER +") AS t1, "+
					    	 	"(SELECT SUM(IF( " + BORROWED_BOOK_HISTORY_TABLE + "."+ BORROWED_BOOK_BORROW_HISTORY_STATUS + " = 'late', 1 , 0 )) AS ReturnDelayCounter "+
					    	" FROM " + BORROWED_BOOK_HISTORY_TABLE + " ) AS t2;";
			return queryToReturn;
		}
		/*
		 *return median of return delay duration
		 * 
		 *	SELECT AVG(dd.ReturnDelayDuration) as median_val
		 *	FROM (
		 *		SELECT t1.ReturnDelayDuration , @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum
		 *		FROM (SELECT @rownum:=0) r 
		 *			,(SELECT SUM(ReturnDelay) AS ReturnDelayDuration
		 *			FROM obl.book GROUP BY CatalogNumber) AS t1
		 *		WHERE t1.ReturnDelayDuration is NOT NULL
		 *		ORDER BY t1.ReturnDelayDuration
		 *	) as dd
		 *	WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );
		 */
		private static String medianDelayDuration() {
			String queryToReturn = "SELECT AVG(dd.ReturnDelayDuration) as median_val "+
					 	"FROM ( "+
					 		" SELECT t1.ReturnDelayDuration , @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum "+
					 		" FROM (SELECT @rownum:=0) r "+ 
					 			" ,(SELECT SUM(" + BOOK_RETURN_DELAY + ") AS ReturnDelayDuration"+
					 			" FROM " + BOOK_TABLE + " GROUP BY " + CATALOG_NUMBER + ") AS t1 "+
					 		" WHERE t1.ReturnDelayDuration IS NOT NULL "+
					 		" ORDER BY t1.ReturnDelayDuration "+
					 	" ) as dd "+
					 	" WHERE dd.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		//////////from here///////////////
		/**
		 * 
		 * *************************************************************************************************************************************************/
		
		/*
		 * SELECT AVG(dd2.ReturnDelayAmount) as median_val
		 *	FROM (
		 *		SELECT COUNT(*) AS ReturnDelayAmount, @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum
		 *		FROM (SELECT @rownum:=0) r
		 *	        ,(SELECT obl.book.CatalogNumber,obl.book.ReturnDelay 
		 *			FROM obl.borrowed_book_history,	obl.book
		 *	        WHERE obl.borrowed_book_history.ISBN=obl.book.ISBN AND
		 *	        obl.borrowed_book_history.borrowStatus = 'late') AS t1
		 *	        GROUP BY t1.ReturnDelay ORDER BY COUNT(*) DESC
		 *	        ) as dd2
		 *	WHERE dd2.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) ) 
		 */
		private static String medianDelayAmount(String Mock) {
			String queryToReturn = "SELECT AVG(dd2.ReturnDelayAmount) as median_val " +
					 " FROM ( "+
							" SELECT COUNT(*) AS ReturnDelayAmount, @rownum:=@rownum+1 as `row_number`, @total_rows:=@rownum " +
							" FROM (SELECT @rownum:=0) r "+
						        ",(SELECT " + BOOK_TABLE + "." + CATALOG_NUMBER + ","+ BOOK_TABLE + "." + BOOK_RETURN_DELAY +
								" FROM " + BORROWED_BOOK_HISTORY_TABLE + "," + BOOK_TABLE +
						        " WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + "=" + BOOK_TABLE +"." + BOOK_ID +" AND "+
						        BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_BORROW_HISTORY_STATUS + "= 'late') AS t1 " +
						        " GROUP BY t1.ReturnDelay ORDER BY COUNT(*) DESC "+
						        ") as dd2 " +
						" WHERE dd2.row_number IN ( FLOOR((@total_rows+1)/2), FLOOR((@total_rows+2)/2) );";
			return queryToReturn;
		}
		
		/*
		 * 	SELECT t1.CatalogNumber,t1.ReturnDelay ,COUNT(*)
		 *	FROM (SELECT obl.book.CatalogNumber,obl.book.ReturnDelay 
		 *	FROM obl.borrowed_book_history,	obl.book
         *	WHERE obl.borrowed_book_history.ISBN=obl.book.ISBN AND
         *	obl.borrowed_book_history.borrowStatus = 'late') AS t1
         *	GROUP BY t1.ReturnDelay ORDER BY COUNT(*) DESC;
		 */
		private static String allBooksDelayDistribution(String Mock) {
			String queryToReturn = "SELECT t1." + CATALOG_NUMBER + ",t1." + BOOK_RETURN_DELAY + " ,COUNT(*) "+
					 " FROM (SELECT "+ BOOK_TABLE +"." + CATALOG_NUMBER +","+ BOOK_TABLE +"."+BOOK_RETURN_DELAY+ 
							 " FROM " + BORROWED_BOOK_HISTORY_TABLE + "," + BOOK_TABLE +
					         " WHERE " + BORROWED_BOOK_HISTORY_TABLE + "."+BORROWED_BOOK_HISTORY_ISBN +"=" +BOOK_TABLE+"."+BOOK_ID + " AND "+
					         BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late') AS t1 "+
					         " GROUP BY t1."+BOOK_RETURN_DELAY + " ORDER BY COUNT(*) DESC ;";
			return queryToReturn;
		}
		
		
		/*
		 * 	SELECT t1.ReturnDelay ,COUNT(*)
		 *	FROM (SELECT obl.book.ISBN,obl.book.ReturnDelay 
		 *	FROM obl.borrowed_book_history,	obl.book
         *	WHERE obl.borrowed_book_history.ISBN=obl.book.ISBN AND
         *	obl.book.CatalogNumber='01' AND
         *	obl.borrowed_book_history.borrowStatus = 'late') AS t1
         *	GROUP BY t1.ReturnDelay ORDER BY COUNT(*) DESC;
		 */
		private static String bookDelayDistribution(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String queryToReturn = "SELECT t1." + BOOK_RETURN_DELAY +",COUNT(*) "+
					 " FROM (SELECT "+ BOOK_TABLE+"."+BOOK_ID +" ,"+BOOK_TABLE+"."+BOOK_RETURN_DELAY +
							 " FROM " +BORROWED_BOOK_HISTORY_TABLE+","+BOOK_TABLE+
					         " WHERE "+BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE+"."+ BOOK_ID + " AND "+
					         BOOK_TABLE+"."+BOOK_TITLE +"="+ bookName +" AND "+
					         BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late') AS t1 "+
					         " GROUP BY t1."+BOOK_RETURN_DELAY+ " ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		/*
		 *	SELECT t1.CatalogNumber,COUNT(*)
		 *	FROM (SELECT obl.book.CatalogNumber,obl.book.ReturnDelay 
		 *			FROM obl.borrowed_book_history,	obl.book
		 *	        WHERE obl.borrowed_book_history.ISBN=obl.book.ISBN AND
		 *	        obl.borrowed_book_history.borrowStatus = 'late') AS t1
		 *	        GROUP BY t1.CatalogNumber ORDER BY COUNT(*) DESC;
		 */
		private static String allBooksDelayAmountDistribution(String Mock) {
			String queryToReturn = "SELECT t1."+CATALOG_NUMBER+" ,COUNT(*) " + 
					" FROM (SELECT " + BOOK_TABLE + "." + CATALOG_NUMBER + ","+BOOK_TABLE+"."+BOOK_RETURN_DELAY + 
					" FROM " + BORROWED_BOOK_HISTORY_TABLE + ", "+ BOOK_TABLE + 
					" WHERE " + BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_HISTORY_ISBN + "=" +BOOK_TABLE + "." + BOOK_ID + " AND " + 
					BORROWED_BOOK_HISTORY_TABLE + "." + BORROWED_BOOK_BORROW_HISTORY_STATUS + " = 'late') AS t1 " + 
					" GROUP BY t1." + CATALOG_NUMBER + " ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		
		/*
		 * 	SELECT t1.ReturnDelay ,COUNT(*)
		 *	FROM (SELECT obl.book.ISBN,obl.book.ReturnDelay 
		 *	FROM obl.borrowed_book_history,	obl.book
         *	WHERE obl.borrowed_book_history.ISBN=obl.book.ISBN AND
         *  obl.book.Headline='Algebra' 															//obl.book.CatalogNumber='01' AND
         *	obl.borrowed_book_history.borrowStatus = 'late') AS t1
         *	GROUP BY t1.ReturnDelay ORDER BY COUNT(*) DESC;
		 */
		private static String bookDelayAmountDistribution(String bookName) {
			bookName = "\'"+ bookName+ "\'";
			String queryToReturn = "SELECT t1."+BOOK_RETURN_DELAY + " ,COUNT(*) "+
					  " FROM (SELECT "+BOOK_TABLE+"."+CATALOG_NUMBER +","+BOOK_TABLE+"."+BOOK_RETURN_DELAY +
							 " FROM " + BORROWED_BOOK_HISTORY_TABLE + "," + BOOK_TABLE +
					         " WHERE " +BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+ "="+BOOK_TABLE + "."+ BOOK_ID + " AND "+
					         BOOK_TABLE+"."+ BOOK_TITLE +"=" + bookName + " AND "+
					         BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_STATUS +" = 'late') AS t1 "+
					         " GROUP BY t1."+ BOOK_RETURN_DELAY + " ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		
		/*
		 * 	SELECT BorrowDuration, COUNT(*) FROM
         *	(SELECT DATEDIFF( IF(returnDate IS NOT NULL	,STR_TO_DATE( returnDate,"%d.%m.%Y"),CURRENT_DATE()),STR_TO_DATE( borrowDate,"%d.%m.%Y")) AS BorrowDuration
		 *	FROM (SELECT obl.borrowed_book_history.borrowDate,obl.borrowed_book_history.returnDate 
		 *		FROM obl.borrowed_book_history ,obl.book 
		 *		WHERE obl.borrowed_book_history.ISBN=obl.book.ISBN 
		 *		AND obl.book.WantedTag = 'Wanted') AS WantedBooks) AS maxWantedBook
		 *		GROUP BY BorrowDuration ORDER BY COUNT(*) DESC;
		 */
		private static String borrowDurationDistribution(String status) {
			status = "\'"+ status+ "\'";
			String format = "\'"+ "%d.%m.%Y" + "\'";
			String queryToReturn = 	"SELECT BorrowDuration , COUNT(*) FROM "+
			         " (SELECT DATEDIFF( IF(" + BORROWED_BOOK_RETURN_HISTORY_DATE + " IS NOT NULL	,STR_TO_DATE( "+ BORROWED_BOOK_RETURN_HISTORY_DATE + "," + format + "),CURRENT_DATE()),STR_TO_DATE( "+ BORROWED_BOOK_BORROW_HISTORY_DATE + ","+format+")) AS BorrowDuration "+
			        		 " FROM (SELECT "+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_BORROW_HISTORY_DATE +" ,"+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_RETURN_HISTORY_DATE + 
			        		 " FROM "+ BORROWED_BOOK_HISTORY_TABLE +","+BOOK_TABLE+ 
			        		 " WHERE "+BORROWED_BOOK_HISTORY_TABLE+"."+BORROWED_BOOK_HISTORY_ISBN+"="+BOOK_TABLE +"."+ BOOK_ID +
			        		 " AND " + BOOK_TABLE+"."+ BOOK_NUMBER_WANTEDTAG +"="+ status +") AS WantedBooks) AS maxWantedBook "+
			        		 " GROUP BY BorrowDuration ORDER BY COUNT(*) DESC;";
			return queryToReturn;
		}
		
		/*
		SET SQL_SAFE_UPDATES = 0;
		UPDATE obl.book 
		INNER JOIN obl.borrowedbook ON obl.book.ISBN = obl.borrowedbook.ISBN
		INNER JOIN obl.user ON obl.borrowedbook.borrowerID = obl.user.UserID
		SET obl.book.NextReturnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y'),
			obl.borrowedbook.returnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y')
		    	WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < DATE_ADD( CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) 
					AND obl.book.BorrowPeriod = 14 
					AND obl.book.ISBN = '2346' 
		            AND obl.book.ISBN = obl.borrowedbook.ISBN 
					AND obl.borrowedbook.borrowStatus='ok' 
					AND obl.book.WantedTag = 'Regular' 
					AND obl.user.UserID=obl.borrowedbook.borrowerID 
					AND obl.user.StatusMembership = 'Active';*/
		private static String librarianManualProlongation(String isbn) {
			isbn = "\'"+ isbn+ "\'";
			/*String queryToReturn = "SET SQL_SAFE_UPDATES = 0;\r\n" + 
					"		UPDATE obl.book \r\n" + 
					"		 JOIN obl.borrowedbook ON obl.book.ISBN = obl.borrowedbook.ISBN\r\n" + 
					"		 JOIN obl.user ON obl.borrowedbook.borrowerID = obl.user.UserID\r\n" + 
					"		SET obl.book.NextReturnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y'),\r\n" + 
					"			obl.borrowedbook.returnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y')\r\n" + 
					"		    	WHERE STR_TO_DATE(obl.borrowedbook.returnDate, \"%d.%m.%Y\") < DATE_ADD( CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) \r\n" + 
					"					AND obl.book.BorrowPeriod = 14 \r\n" + 
					"					AND obl.book.ISBN = " + isbn + " AND obl.book.ISBN = obl.borrowedbook.ISBN \r\n" + 
							"					AND obl.borrowedbook.borrowStatus='ok' \r\n" + 
							"					AND obl.book.WantedTag = 'Regular' \r\n" + 
							"					AND obl.user.UserID=obl.borrowedbook.borrowerID \r\n" + 
							"					AND obl.user.StatusMembership = 'Active';";*/
					/*
					 * UPDATE obl.book
					 * 		JOIN obl.borrowedbook ON obl.book.ISBN = obl.borrowedbook.ISBN
					 *		JOIN obl.user ON obl.borrowedbook.borrowerID = obl.user.UserID
					 *		SET obl.book.NextReturnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y'),
					 *		obl.borrowedbook.returnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y')
		    		 *		WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < DATE_ADD( CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) 
					 *			AND obl.book.BorrowPeriod = 14 
					 *			AND obl.book.ISBN = '0001' AND obl.book.ISBN = obl.borrowedbook.ISBN 
					 *			AND obl.borrowedbook.borrowStatus='ok' 
					 *			AND obl.book.WantedTag = 'Regular' 
					 *			AND obl.user.UserID=obl.borrowedbook.borrowerID 
					 *			AND obl.user.StatusMembership = 'Active';
					 */
					String queryToReturn ="UPDATE " + BOOK_TABLE + 
					" JOIN " + BORROWED_BOOK_TABLE + " ON " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE +"."+ BORROWED_BOOK_ISBN +
					" JOIN " + USER_TABLE + " ON " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + "=" + USER_TABLE +"." + USER_ID +
					" SET " + BOOK_TABLE + "." + NEXT_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y')," +
					BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y') " +
					    	"WHERE STR_TO_DATE(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + ", \"%d.%m.%Y\") < DATE_ADD( CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD +" DAY)"+ 
								" AND " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + "= 14 " + 
								" AND " + BOOK_TABLE + "." + BOOK_ID + "=" + isbn + " AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
								" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + " ='ok' " +
								" AND " + BOOK_TABLE + "." + BOOK_NUMBER_WANTEDTAG + " = 'Regular' "+ 
								" AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + 
								" AND " + USER_TABLE + "." + STATUS_MEMBERSHIP + " = 'Active';";
			return queryToReturn;
			
		}
		
		/*SET SQL_SAFE_UPDATES = 0;
UPDATE obl.book 
INNER JOIN obl.borrowedbook ON obl.book.ISBN = obl.borrowedbook.ISBN
INNER JOIN obl.user ON obl.borrowedbook.borrowerID = obl.user.UserID
SET obl.book.NextReturnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y'),
	obl.borrowedbook.returnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y')
    	WHERE STR_TO_DATE(obl.borrowedbook.returnDate, "%d.%m.%Y") < DATE_ADD( CURRENT_DATE(), INTERVAL 8 DAY) 
			AND obl.book.BorrowPeriod = 14 
			AND obl.book.ISBN = '0003' 
            AND obl.book.ISBN = obl.borrowedbook.ISBN 
			AND obl.borrowedbook.borrowStatus='ok' 
			AND obl.book.WantedTag = 'Regular' 
			AND obl.user.UserID=obl.borrowedbook.borrowerID 
			AND obl.user.StatusMembership = 'Active';*/
		private static String subscriberManualProlongation(String isbn) {
			isbn = "\'"+ isbn+ "\'";
			/*String queryToReturn = "SET SQL_SAFE_UPDATES = 0;\r\n" +
					"UPDATE obl.book \r\n" + 
					" JOIN obl.borrowedbook ON obl.book.ISBN = obl.borrowedbook.ISBN " + 
					" JOIN obl.user ON obl.borrowedbook.borrowerID = obl.user.UserID " + 
					" SET obl.book.NextReturnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y'), " + 
					"	obl.borrowedbook.returnDate = DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL obl.book.BorrowPeriod DAY) , '%d.%m.%Y') " + 
					"    	WHERE STR_TO_DATE(obl.borrowedbook.returnDate, \"%d.%m.%Y\") < DATE_ADD( CURRENT_DATE(), INTERVAL 8 DAY)  " + 
					"			AND obl.book.BorrowPeriod = 14  " + 
					"			AND obl.book.ISBN = " + isbn + "AND obl.book.ISBN = obl.borrowedbook.ISBN  " + 
							"			AND obl.borrowedbook.borrowStatus='ok'  " + 
							"			AND obl.book.WantedTag = 'Regular'  " + 
							"			AND obl.user.UserID=obl.borrowedbook.borrowerID  " + 
							"			AND obl.user.StatusMembership = 'Active';";*/
			String queryToReturn = "UPDATE " + BOOK_TABLE + 
					" JOIN " + BORROWED_BOOK_TABLE + " ON " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE +"."+ BORROWED_BOOK_ISBN +
					" JOIN " + USER_TABLE + " ON " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + "=" + USER_TABLE +"." + USER_ID +
					" SET " + BOOK_TABLE + "." + NEXT_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y')," +
					BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + "= DATE_FORMAT(DATE_ADD(CURRENT_DATE(), INTERVAL " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + " DAY) , '%d.%m.%Y') " +
					    	"WHERE STR_TO_DATE(" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_RETURN_DATE + ", \"%d.%m.%Y\") < DATE_ADD( CURRENT_DATE(), INTERVAL 8 DAY)"+ 
								" AND " + BOOK_TABLE + "." + BOOK_BORROW_PERIOD + "= 14 " + 
								" AND " + BOOK_TABLE + "." + BOOK_ID + "=" + isbn + " AND " + BOOK_TABLE + "." + BOOK_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_ISBN + 
								" AND " + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROW_STATUS + " ='ok' " +
								" AND " + BOOK_TABLE + "." + BOOK_NUMBER_WANTEDTAG + " = 'Regular' "+ 
								" AND " + USER_TABLE + "." + USER_ID + "=" + BORROWED_BOOK_TABLE + "." + BORROWED_BOOK_BORROWER_ID + 
								" AND " + USER_TABLE + "." + STATUS_MEMBERSHIP + " = 'Active';";
			return queryToReturn;
		}
}
