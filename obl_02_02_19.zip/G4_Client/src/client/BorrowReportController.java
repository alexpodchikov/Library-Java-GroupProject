package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.Book;
import common.ChatIF;
import common.ClientToServerMessage;
import common.Distribution;
import common.EQueryOption;
import common.Student;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;



public class BorrowReportController implements ChatIF,Initializable  {		
	@FXML
	private TextField AverageWantedTextField;
	@FXML
	private TextField AverageRegularTextField;
	@FXML
	private TextField MedianWantedTextField;
	@FXML
	private TextField MedianRegularTextField;
	@FXML
	private Label Amount1ID;
	@FXML
	private Label Amount2ID;
	@FXML
	private Label Amount3ID;
	@FXML
	private Label Amount4ID;
	@FXML
	private Label Amount5ID;
	@FXML
	private Label Amount6ID;
	@FXML
	private Label Amount7ID;
	@FXML
	private Label Amount8ID;
	@FXML
	private Label Amount9ID;
	@FXML
	private Label Amount10ID;
	@FXML
	private Label Amount11ID;
	@FXML
	private Label Amount12ID;
	@FXML
	private Label Amount13ID;
	@FXML
	private Label Amount14ID;
	@FXML
	private Label Amount15ID;
	@FXML
	private Label Amount16ID;
	@FXML
	private Label Amount17ID;
	@FXML
	private Label Amount18ID;
	@FXML
	private Label Amount19ID;
	@FXML
	private Label Amount20ID;


	private ConnectionController client;
	int counter = 1;
	boolean wantedCounter= false;

	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Report Window");	 
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			init();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	 public void init() throws IOException {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			ArrayList<String> SetParameters = new ArrayList<String>();
		
			SetParameters.add("Wanted");
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.AVG_BORROW_DURATION, SetParameters, "average_wanted_book_borrow_amount");
			client.handleMessageFromClientUI(messageToSend);	
			ClientToServerMessage messageToSend1 = new ClientToServerMessage(EQueryOption.MEDIAN_BORROW_DURATION, SetParameters, "median_wanted_book_borrow_amount");			    
			client.handleMessageFromClientUI(messageToSend1);
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.BORROW_DURATION_DISTRIBUTION, SetParameters, "borrow_duration_distribution");			    
			client.handleMessageFromClientUI(messageToSend2);
			SetParameters.add("Regular");
			SetParameters.remove(0);

			ClientToServerMessage messageToSend3 = new ClientToServerMessage(EQueryOption.AVG_BORROW_DURATION, SetParameters, "average_regular_book_borrow_amount");
			client.handleMessageFromClientUI(messageToSend3);	
			ClientToServerMessage messageToSend4 = new ClientToServerMessage(EQueryOption.MEDIAN_BORROW_DURATION, SetParameters, "median_regular_book_borrow_amount");			    
			client.handleMessageFromClientUI(messageToSend4);
			ClientToServerMessage messageToSend5 = new ClientToServerMessage(EQueryOption.BORROW_DURATION_DISTRIBUTION, SetParameters, "borrow_duration_distribution");			    
			client.handleMessageFromClientUI(messageToSend5);
		
		}
	@Override
	public void display(Object message) {
		if (message == null) {
			System.out.println("> Server returned null");
		}
		
		if( message instanceof ArrayList<?>) {
			
			ArrayList<Distribution> distribution = (ArrayList<Distribution>)message;
			for (int i = 0; i < distribution.size(); i++) {
				
				String temp=null;
				Integer sum=0,num=0;
				String percent = distribution.get(i).getPercent();
				String count = distribution.get(i).getCount();
				System.out.println("counter state : " + wantedCounter);
				switch(percent){ 
				case "0" :
				case "1":
				case "2":
					if(!wantedCounter ) { 
						System.out.println("kova");
						temp = Amount1ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount1ID.setText(temp);
					}	
					else { 
					
						temp = Amount11ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						System.out.println(temp + "ninjas123");
						Amount11ID.setText(temp);
					}
				break;
				
				case "3" :
				case "4":
				case "5":
					if(!wantedCounter ) { 
						temp = Amount2ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount2ID.setText(temp);
					}	
					else { 
						temp = Amount12ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount12ID.setText(temp);
					}				
				break;
				case "6" :
				case "7":
				case "8":
					if(!wantedCounter ) { 
						temp = Amount3ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount3ID.setText(temp);
					}	
					else { 
						temp = Amount13ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount13ID.setText(temp);
					}				
				break;
				case "9" :
				case "10":
				case "11":
					if(!wantedCounter ) { 
						temp = Amount4ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount4ID.setText(temp);
					}	
					else { 
						temp = Amount14ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount14ID.setText(temp);
					}				
				break;
				case "12" :
				case "13":
				case "14":
					if(!wantedCounter ) { 
						temp = Amount5ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount5ID.setText(temp);
					}	
					else { 
						temp = Amount15ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount15ID.setText(temp);
					}				
				break;
				case "15" :
				case "16":
				case "17":
					if(!wantedCounter ){ 
						temp = Amount6ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount6ID.setText(temp);
					}	
					else { 
						temp = Amount16ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount16ID.setText(temp);
					}				
				break;
				case "18" :
				case "19":
				case "20":
					if(!wantedCounter ) { 
						temp = Amount7ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount7ID.setText(temp);
					}	
					else { 
						temp = Amount17ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount17ID.setText(temp);
					}				
				break;
				case "21" :
				case "22":
				case "23":
					if(!wantedCounter ) { 
						temp = Amount8ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount8ID.setText(temp);
					}	
					else { 
						temp = Amount18ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount18ID.setText(temp);
					}
					break;
				case "24" :
				case "25":
				case "26":
					if(!wantedCounter ) { 
						temp = Amount9ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount9ID.setText(temp);
					}	
					else { 
						temp = Amount19ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount19ID.setText(temp);
					}				break;
				case "27" :
				case "28":
				case "29":
					if(!wantedCounter ) { 
						temp = Amount10ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount10ID.setText(temp);
					}	
					else { 
						temp = Amount20ID.getText();
						sum = Integer.parseInt(temp);
						num = Integer.parseInt(count);
						sum+=num;
						temp = sum.toString();
						Amount20ID.setText(temp);
					}				
					break;
					
				default:
					 System.out.println("youre gone too far");
				}

			
		}
			
		wantedCounter = !wantedCounter;
		}
 		else {
 			System.out.println(message.toString()  + "cheetah");
			switch (counter) {
			case 1:	
				AverageWantedTextField.setText((String)message);
				counter++;
			break;
			case 2:
				MedianWantedTextField.setText((String)message);
				counter++;
			break;	
			
			case 3:
				AverageRegularTextField.setText((String)message);
				counter++;
			break;
			case 4:	
				MedianRegularTextField.setText((String)message);
				counter++;
			break;
			default: System.out.println("youre gone too far");
			}		
		}
	}

	}