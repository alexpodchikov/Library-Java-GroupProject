package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.Student;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class BookReturnReportController implements ChatIF {
	
	@FXML
	private TextField AverageAmountTextField;
	@FXML
	private TextField AverageDurationTextField;
	@FXML
	private TextField MedianAmountTextField;
	@FXML
	private TextField MedianDurationTextField;
	@FXML
    private BarChart<String,Number > mBarChartAmount;
    @FXML
    private BarChart<String,Number > mBarChartDuration;
	private ConnectionController client;
	int counter = 1;
	@FXML
	private Label Amount1ID;
	@FXML
	private Label Amount2ID;
	@FXML
	private Label Amount3ID;
	@FXML
	private Label Amount4ID;
	@FXML
	private Label Amount5ID;
	@FXML
	private Label Amount6ID;
	@FXML
	private Label Amount7ID;
	@FXML
	private Label Amount8ID;
	@FXML
	private Label Amount9ID;
	@FXML
	private Label Amount10ID;
	@FXML
	private Label Amount11ID;
	@FXML
	private Label Amount12ID;
	@FXML
	private Label Amount13ID;
	@FXML
	private Label Amount14ID;
	@FXML
	private Label Amount15ID;
	@FXML
	private Label Amount16ID;
	@FXML
	private Label Amount17ID;
	@FXML
	private Label Amount18ID;
	@FXML
	private Label Amount19ID;
	@FXML
	private Label Amount20ID;
	
	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Report Window");	 
	}

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
	

}
