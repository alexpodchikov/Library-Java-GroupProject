
package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.ChatIF;
import common.ClientToServerMessage;
import common.EQueryOption;
import common.Student;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class LateReturnReportController implements ChatIF,Initializable {
	
	@FXML
	private TextField AverageAmountTextField;
	@FXML
	private TextField AverageDurationTextField;
	@FXML
	private TextField MedianAmountTextField;
	@FXML
	private TextField MedianDurationTextField;
	@FXML
    private BarChart<String,Number > mBarChartAmount;
    @FXML
    private BarChart<String,Number > mBarChartDuration;
	private ConnectionController client;
	int counter = 1;
	@FXML
	private Label Amount1ID;
	@FXML
	private Label Amount2ID;
	@FXML
	private Label Amount3ID;
	@FXML
	private Label Amount4ID;
	@FXML
	private Label Amount5ID;
	@FXML
	private Label Amount6ID;
	@FXML
	private Label Amount7ID;
	@FXML
	private Label Amount8ID;
	@FXML
	private Label Amount9ID;
	@FXML
	private Label Amount10ID;
	@FXML
	private Label Amount11ID;
	@FXML
	private Label Amount12ID;
	@FXML
	private Label Amount13ID;
	@FXML
	private Label Amount14ID;
	@FXML
	private Label Amount15ID;
	@FXML
	private Label Amount16ID;
	@FXML
	private Label Amount17ID;
	@FXML
	private Label Amount18ID;
	@FXML
	private Label Amount19ID;
	@FXML
	private Label Amount20ID;
	
	 @FXML
	 void backClicked(ActionEvent event) {
		 
		 Screens.showPrevScreen("Report Window");	 
	}
	 @FXML
	 void submitClicked(ActionEvent event) {
		 
		// Screens.showPrevScreen("Report Window");	 
	}
	 

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	try {
		init();
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	 
	 public void init() throws IOException {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add("vasya");
			ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.AVG_LATE_RETURN_AMOUNT_AND_DURATION, SetParameters, "avg_number_of_late_returns_and_avg_delay_duration");			    
			client.handleMessageFromClientUI(messageToSend);
			ClientToServerMessage messageToSend2 = new ClientToServerMessage(EQueryOption.MEDIAN_DELAY_DURATION, SetParameters, "median_delay_duration");			    
			client.handleMessageFromClientUI(messageToSend2);
	
		}


	@Override
	public void display(Object message) {
		ArrayList<String> SetAnswerFromServer = new ArrayList<String>();
	SetAnswerFromServer = (ArrayList<String>)message;
		switch (counter) {
		case 1:			
			AverageAmountTextField.setText(SetAnswerFromServer.get(0));
			AverageDurationTextField.setText(SetAnswerFromServer.get(1));
			counter++;
		break;
		case 2:
			MedianDurationTextField.setText(SetAnswerFromServer.get(0));
			counter=1;
			
		break;
		default: System.out.println("youre gone too far");
		
	}
	}
	
}