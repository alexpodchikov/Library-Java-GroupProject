package common;

import java.io.Serializable;

public class User implements Serializable {
	
	private static final long serialVersionUID = -1133128363482085515L;
	public String userID;

	public String password;
	public String userName;
	public String accountType;
	public String statusMembership;
	public int freeze;
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public User(String UserName, String AccountType, String StatusMembership,String UserID) {
		
		userName = UserName;
		accountType = AccountType;
		statusMembership = StatusMembership;
		userID =UserID; 
		
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}
	
	public void setUserID(String userID) {
		this.userID = userID;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}
	/**		
* @return the userName		
	*/		
	public String getUserName() {		
	return userName;
	}
	@Override
	public String toString() {
		return userName;
	}



}
