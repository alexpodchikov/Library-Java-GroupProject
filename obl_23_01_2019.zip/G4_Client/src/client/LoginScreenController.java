package client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import common.User;
import common.ClientToServerMessage;
import common.ChatIF;
import common.EQueryOption;
import common.IClient;
import common.Student;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LoginScreenController implements ChatIF  {	
	 @FXML
	 private TextField UserNameTextField;
	 @FXML
	 private PasswordField PasswordTextField;
	 private ConnectionController client;			// user database handler.
	 private String connectedUserID= null;
	 private String userName= null;
	 private Stage curr;
	
	 	
    @FXML
    void BackToMainSystemMenuClick(ActionEvent event) {
    	Stage curr = (Stage)((Node)event.getSource()).getScene().getWindow();
    	curr.close();
    }
    
	/**
	 * Login button pressed. validate login info.
	 * @param event login button pressed.
	 */
    @FXML	
    private void LoginClick(ActionEvent event) {
    	curr = (Stage)((Node)event.getSource()).getScene().getWindow();
    	userName = UserNameTextField.getText();
    	String Password = PasswordTextField.getText();
    	if (userName.isEmpty() || Password.isEmpty()) {
    		Screens.showErrorDialog("Error","Cannot be empty", "Please check your info!");
    		return;
    	}
	
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(userName);
		SetParameters.add(Password);

		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			}
		catch (IOException e) {
			e.printStackTrace();
		}

	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.LOGIN_REQUEST, SetParameters,"User");
	    client.handleMessageFromClientUI(messageToSend); 
	    connectedUserID = userName;
	}
    
   

	@Override
	public void display(Object msg) {
		if (msg == null) {
			System.out.println("> Server returned null");
		}
		else System.out.println("> Server returned: "+msg.toString());
		
		/**
		 * Display error dialog is server returned null.
		 * TODO: make stage factory.
		 */
		 Platform.runLater(new Runnable() {                          
	            @Override
	            public void run() {
	                try{
	                	if (msg == null) {
	                		Screens.showErrorDialog("Error","Entry not found", "Username or password is incorrect!");
	                		return;
	                	}
	                	
	                	showStage(msg); 
	                }
	                catch(Exception e) {
	                	System.out.println("Invoke later failed..");
	                	e.printStackTrace();
	                }
	            }
	            
	        	
	        	/**
	        	 * Get suitable stage for suitable form by object type..
	        	 * @param object
	        	 * @return suitable stage
	        	 * @throws Exception
	        	 */
	        	private void showStage(Object object) throws Exception {
	        		String mainMenuAccount = null;
	        		String stylesheetPath = null;
	        		User loginInfo = (User)object;
	        		 
	        		String string1 = loginInfo.getAccountType().toLowerCase().trim();
	        		System.out.println(string1);
	        		
	        		// get user parent
	        		if (object instanceof User) {
	        			client = ConnectionController.getConnectionController();
	        			client.setUserID(loginInfo.getUserID());
	        			switch (loginInfo.getAccountType().toLowerCase().trim()) {
	        			case "student":
	        				try {
	    		        	FXMLLoader loader= new FXMLLoader();	        			
		        			Stage stage = client.getStage();
		                	Parent root = loader.load(Main.class.getResource("/client/SubscriberSystemMenu.fxml").openStream());	        				
	        				SubscriberMainScreenController controller = loader.getController();
			        		controller.setUserId(userName);
			        		Scene scene = new Scene(root);	
			        		scene.getStylesheets().add(Main.class.getResource("/client/Subscriber.css").toExternalForm());
		        			stage.setTitle("SubscriberSystemMenu");
		        			stage.setScene(scene);
		        			stage.show();
	        				} catch(IOException e) {
			        			e.printStackTrace();
	        				}
	        				//mainMenuAccount = "/client/SubscriberSystemMenu.fxml";
	        				break;
	        			case "librarian":	
	        				mainMenuAccount = "/client/LibrarianMainScreen.fxml";
	        				stylesheetPath = "/client/LibraryMainScreen.css";
	        				break;
	        			case "librarymanager":
	        				mainMenuAccount = "/client/LibraryManagerMainScreen.fxml";
	        				stylesheetPath = "/client/LibraryMainScreen.css";
	        				break;
	        				default:
	        					System.out.println("There is no such user");
	        				}
	        			System.out.println(mainMenuAccount);  		        			
	        		} 
	        		
	        		curr.close();
	        		if (mainMenuAccount != null) {
	        		Screens.showNewScreen(mainMenuAccount, stylesheetPath, "User System Menu");
	        		}
	        	}
	        });
		}
	}
	
