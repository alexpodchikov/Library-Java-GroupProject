package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class SubscriberAddingFormController implements ChatIF {
	
	 @FXML
	 private TextField studentNameTextField;
	 @FXML
	 private TextField studentIDTextField;
	 @FXML
	 private TextField studentEmailAddressTextField;
	 @FXML
	 private TextField studentPhoneNumberTextField;
	 @FXML
	 private TextField SubscriberIDTextField;	 
	 @FXML
	 private TextField studentPasswordTextField;
	 
	 private ConnectionController client;
	 
	 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Library Main Screen ");	 
	}
	 
	 @FXML	
	    private void SaveClick(ActionEvent event) throws IOException {
		    //studentSubscriberNumberTextField.setText(studentSubscriberNumber.toString());
			String studentName = studentNameTextField.getText();
	    	String studentID = studentIDTextField.getText();
	    	String studentEmailAddress = studentEmailAddressTextField.getText();
	    	String studentPhoneNumber = studentPhoneNumberTextField.getText();
	    	String studentPassword = studentPasswordTextField.getText();
	    	//System.out.println("ninja "+studentName);
	    	if (studentName.isEmpty() || studentID.isEmpty() || studentEmailAddress.isEmpty() || studentPhoneNumber.isEmpty() || studentPassword.isEmpty()) {
	    		Screens.showErrorDialog("Invalid information","Text Field cannot be empty", "Please check info");
	    		return;
	    	}
			ArrayList<String> SetParameters = new ArrayList<String>();
			SetParameters.add(studentName);
			SetParameters.add(studentID);
			SetParameters.add(studentEmailAddress);
			SetParameters.add(studentPhoneNumber);
			SetParameters.add(studentPassword);
			
		    Alert alert = new Alert(AlertType.CONFIRMATION);
		    alert.setTitle("Confirmation Dialog");
		    alert.setHeaderText("!!!!!!!");
		    alert.setContentText("Add the Reader Card?");
		    Optional<ButtonType> result = alert.showAndWait();
		   if (result.get() == ButtonType.OK){
			    client = ConnectionController.getConnectionController();
				client.clientUI = this;
				//client.setPrevScene(curr);
			    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.ADD_READER_CARD, SetParameters, "Student");
			    client.handleMessageFromClientUI(messageToSend);	    
		   }
		
		}

	@Override
	public void display(Object message) {
		// TODO Auto-generated method stub
		
	}
}
