package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import common.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class UserProfileController implements ChatIF {
	
	 private ConnectionController client;	
		@FXML
		private TextField emailID;
		@FXML
		private TextField phoneID;
		@FXML
		private TextField SubscriberNumID;
		@FXML
		private TextField StudentID;
		@FXML
		private TextField StudentNameID;


	 	 
	 @FXML
	 void BackClick(ActionEvent event) {
		 
		 Screens.showPrevScreen("Subscriber Main Menu");	 
	}
	 
	 @FXML
	 void SaveClick(ActionEvent event) throws Exception  {
		 String email = emailID.getText();
		 String phone = phoneID.getText();
			ArrayList<String> SetParameters = new ArrayList<String>();

			try {
				client = ConnectionController.getConnectionController();
				client.clientUI = this;
			
				SetParameters.add(client.getUserID());
				SetParameters.add(email);
				SetParameters.add(phone);
				}
			catch (IOException e) {
				e.printStackTrace();
			}

		    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.SAVE_STUDENT_INFO, SetParameters,null);
		    client.handleMessageFromClientUI(messageToSend); 
		 
	}
	 
	 @FXML
	 void viewHistoryClicked(ActionEvent event) throws Exception  {
			
		 Scene curr = (Scene)((Node)event.getSource()).getScene();
		try {
	        	FXMLLoader loader= new FXMLLoader();	
	        	client = ConnectionController.getConnectionController();
		    	client.setPrevScene(curr);
    			Stage stage = client.getStage();
            	Parent root = loader.load(Main.class.getResource("/client/ReaderBorrowHistoryWindow.fxml").openStream());	        				
            	ReaderBorrowHistoryWindowController controller = loader.getController();
        		controller.setUserId(client.getUserID());
        		Scene scene = new Scene(root);	
    			stage.setTitle("Borrow History");
    			stage.setScene(scene);
    			stage.show();
				} catch(IOException e) {
        			e.printStackTrace();
				}
		 
	}

	public void setUserId(String userID) {
		ArrayList<String> SetParameters = new ArrayList<String>();
		SetParameters.add(userID);

		try {
			client = ConnectionController.getConnectionController();
			client.clientUI = this;
			}
		catch (IOException e) {
			e.printStackTrace();
		}

	    ClientToServerMessage messageToSend = new ClientToServerMessage(EQueryOption.GET_STUDENT_INFO, SetParameters,"student");
	    client.handleMessageFromClientUI(messageToSend); 
	}
	
	
	@Override
	public void display(Object message) {
		
	
		 String status = "";
		 
		 if (message instanceof Student) {
		 Student student = (Student) message;
      	emailID.setText(student.getStudentEmail());
      	phoneID.setText(student.getStudentPhone());
      	SubscriberNumID.setText(student.getStudentSubscriberNumber());
      	StudentID.setText(student.getStudentID());
      	StudentNameID.setText(student.getStudentName());  
		 }
		 
		if (message == null) {
			System.out.println("> Server returned null");
		}
		else {
		System.out.println("> Server returned: "+message.toString());

		}
		
		
		
		
		Platform.runLater(new Runnable() {  
		 
         @Override
         public void run() {
             try{
             	if (message == null) {
             		Screens.showErrorDialog("Error","Entry not found", "Username or password is incorrect!");
             		return;
             	}
            	if (message.toString().contains("Success")) {
        			Screens.showSuccessDialog("Information Dialog", "Success", "The new details were saved successfully");
        		}
           	
             }
             catch(Exception e) {
             	System.out.println("Invoke later failed..");
             	e.printStackTrace();
             }
         }
	 });
	}
}
